/*
Navicat MySQL Data Transfer

Source Server         : MySql
Source Server Version : 50623
Source Host           : 192.168.10.63:3306
Source Database       : dbo

Target Server Type    : MYSQL
Target Server Version : 50623
File Encoding         : 65001

Date: 2015-06-05 15:37:10
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for Himall_AccountDetails
-- ----------------------------
DROP TABLE IF EXISTS `Himall_AccountDetails`;
CREATE TABLE `Himall_AccountDetails` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AccountId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `Date` datetime NOT NULL COMMENT '完成日期',
  `OrderDate` datetime NOT NULL,
  `OrderType` int(11) NOT NULL COMMENT '枚举 完成订单1，退订单0',
  `OrderId` bigint(20) NOT NULL,
  `ProductActualPaidAmount` decimal(8,2) NOT NULL COMMENT '商品实付总额',
  `FreightAmount` decimal(8,2) NOT NULL COMMENT '运费金额',
  `CommissionAmount` decimal(8,2) NOT NULL COMMENT '佣金',
  `RefundTotalAmount` decimal(8,2) NOT NULL COMMENT '退款金额',
  `RefundCommisAmount` decimal(8,2) NOT NULL COMMENT '退还佣金',
  `OrderRefundsDates` varchar(300) NOT NULL COMMENT '退单的日期集合以;分隔',
  PRIMARY KEY (`Id`),
  KEY `himall_accountdetails_ibfk_1` (`AccountId`) USING BTREE,
  CONSTRAINT `himall_accountdetails_ibfk_1` FOREIGN KEY (`AccountId`) REFERENCES `Himall_Accounts` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_AccountMeta
-- ----------------------------
DROP TABLE IF EXISTS `Himall_AccountMeta`;
CREATE TABLE `Himall_AccountMeta` (
  `Id` bigint(20) NOT NULL,
  `AccountId` bigint(20) NOT NULL,
  `MetaKey` varchar(100) NOT NULL,
  `MetaValue` text NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_AccountPurchaseAgreement
-- ----------------------------
DROP TABLE IF EXISTS `Himall_AccountPurchaseAgreement`;
CREATE TABLE `Himall_AccountPurchaseAgreement` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AccountId` bigint(20) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL,
  `Date` datetime NOT NULL,
  `PurchaseAgreementId` bigint(20) NOT NULL,
  `AdvancePayment` decimal(8,2) NOT NULL COMMENT '预付款金额',
  `FinishDate` datetime NOT NULL COMMENT '平台审核时间',
  `ApplyDate` datetime DEFAULT NULL COMMENT '申请',
  PRIMARY KEY (`Id`),
  KEY `AccountId` (`AccountId`) USING BTREE,
  CONSTRAINT `himall_accountpurchaseagreement_ibfk_1` FOREIGN KEY (`AccountId`) REFERENCES `Himall_Accounts` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='结算预付款';

-- ----------------------------
-- Table structure for Himall_Accounts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Accounts`;
CREATE TABLE `Himall_Accounts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `AccountDate` datetime NOT NULL COMMENT '出账日期',
  `StartDate` datetime NOT NULL COMMENT '开始时间',
  `EndDate` datetime NOT NULL COMMENT '结束时间',
  `Status` int(11) NOT NULL COMMENT '枚举 0未结账，1已结账',
  `ProductActualPaidAmount` decimal(8,2) NOT NULL COMMENT '商品实付总额',
  `FreightAmount` decimal(8,2) NOT NULL COMMENT '运费',
  `CommissionAmount` decimal(8,2) NOT NULL COMMENT '佣金',
  `RefundCommissionAmount` decimal(8,2) NOT NULL COMMENT '退还佣金',
  `RefundAmount` decimal(8,2) NOT NULL COMMENT '退款金额',
  `AdvancePaymentAmount` decimal(8,2) NOT NULL COMMENT '预付款总额',
  `PeriodSettlement` decimal(8,2) NOT NULL COMMENT '本期应结',
  `Remark` text,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ActiveMarketService
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ActiveMarketService`;
CREATE TABLE `Himall_ActiveMarketService` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TypeId` int(11) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Agreement
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Agreement`;
CREATE TABLE `Himall_Agreement` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AgreementType` int(4) NOT NULL COMMENT '协议类型 枚举 AgreementType：0买家注册协议，1卖家入驻协议',
  `AgreementContent` text NOT NULL COMMENT '协议内容',
  `LastUpdateTime` datetime DEFAULT NULL COMMENT '最后修改日期',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for Himall_ArticleCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ArticleCategories`;
CREATE TABLE `Himall_ArticleCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParentCategoryId` bigint(20) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `IsDefault` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Articles
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Articles`;
CREATE TABLE `Himall_Articles` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `CategoryId` bigint(20) NOT NULL DEFAULT '0',
  `Title` varchar(100) NOT NULL,
  `IconUrl` varchar(100) DEFAULT NULL,
  `Content` text NOT NULL,
  `AddDate` datetime NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `Meta_Title` text,
  `Meta_Description` text,
  `Meta_Keywords` text,
  `IsRelease` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_ArticleCategory_Article` (`CategoryId`) USING BTREE,
  CONSTRAINT `himall_articles_ibfk_1` FOREIGN KEY (`CategoryId`) REFERENCES `Himall_ArticleCategories` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Attributes
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Attributes`;
CREATE TABLE `Himall_Attributes` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TypeId` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `IsMust` tinyint(1) NOT NULL,
  `IsMulti` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Type_Attribute` (`TypeId`) USING BTREE,
  CONSTRAINT `himall_attributes_ibfk_1` FOREIGN KEY (`TypeId`) REFERENCES `Himall_Types` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_AttributeValues
-- ----------------------------
DROP TABLE IF EXISTS `Himall_AttributeValues`;
CREATE TABLE `Himall_AttributeValues` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AttributeId` bigint(20) NOT NULL,
  `Value` varchar(100) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Attribute_AttributeValue` (`AttributeId`) USING BTREE,
  CONSTRAINT `himall_attributevalues_ibfk_1` FOREIGN KEY (`AttributeId`) REFERENCES `Himall_Attributes` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=726 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Banners
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Banners`;
CREATE TABLE `Himall_Banners` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Position` int(11) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `Url` varchar(1000) NOT NULL,
  `Platform` int(11) NOT NULL DEFAULT '0',
  `UrlType` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Brands
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Brands`;
CREATE TABLE `Himall_Brands` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `Logo` varchar(1000) DEFAULT NULL,
  `RewriteName` varchar(50) DEFAULT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `Meta_Title` varchar(1000) DEFAULT NULL,
  `Meta_Description` varchar(1000) DEFAULT NULL,
  `Meta_Keywords` varchar(1000) DEFAULT NULL,
  `IsRecommend` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_BrowsingHistory
-- ----------------------------
DROP TABLE IF EXISTS `Himall_BrowsingHistory`;
CREATE TABLE `Himall_BrowsingHistory` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MemberId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `BrowseTime` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_BrowsingHistory_Himall_BrowsingHistory` (`MemberId`) USING BTREE,
  KEY `FK_Himall_BrowsingHistory_Himall_Products` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_browsinghistory_ibfk_1` FOREIGN KEY (`MemberId`) REFERENCES `Himall_Members` (`Id`),
  CONSTRAINT `himall_browsinghistory_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1302 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_BusinessCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_BusinessCategories`;
CREATE TABLE `Himall_BusinessCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `CategoryId` bigint(20) NOT NULL,
  `CommisRate` decimal(8,2) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Category_BusinessCategory` (`CategoryId`) USING BTREE,
  CONSTRAINT `himall_businesscategories_ibfk_1` FOREIGN KEY (`CategoryId`) REFERENCES `Himall_Categories` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1540 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_CashDeposit
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CashDeposit`;
CREATE TABLE `Himall_CashDeposit` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ShopId` bigint(20) NOT NULL COMMENT 'Shop表外键',
  `CurrentBalance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '可用金额',
  `TotalBalance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '已缴纳金额',
  `Date` datetime DEFAULT NULL COMMENT '最后一次缴纳时间',
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_CashDeposit_Himall_Shops` (`ShopId`) USING BTREE,
  CONSTRAINT `Himall_cashdeposit_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for Himall_CashDepositDetail
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CashDepositDetail`;
CREATE TABLE `Himall_CashDepositDetail` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `CashDepositId` bigint(20) NOT NULL DEFAULT '0',
  `AddDate` datetime NOT NULL,
  `Balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Operator` varchar(50) NOT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `RechargeWay` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `KF_Himall_CashDeposit_Himall_CashDepositDetail` (`CashDepositId`) USING BTREE,
  CONSTRAINT `Himall_cashdepositdetail_ibfk_1` FOREIGN KEY (`CashDepositId`) REFERENCES `Himall_CashDeposit` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for Himall_Categories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Categories`;
CREATE TABLE `Himall_Categories` (
  `Id` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Icon` varchar(1000) DEFAULT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `ParentCategoryId` bigint(20) NOT NULL,
  `Depth` int(11) NOT NULL,
  `Path` varchar(100) NOT NULL,
  `RewriteName` varchar(50) DEFAULT NULL,
  `HasChildren` tinyint(1) NOT NULL,
  `TypeId` bigint(20) NOT NULL DEFAULT '0',
  `CommisRate` decimal(8,2) NOT NULL,
  `Meta_Title` varchar(1000) DEFAULT NULL,
  `Meta_Description` varchar(1000) DEFAULT NULL,
  `Meta_Keywords` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Type_Category` (`TypeId`) USING BTREE,
  CONSTRAINT `himall_categories_ibfk_1` FOREIGN KEY (`TypeId`) REFERENCES `Himall_Types` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Coupon
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Coupon`;
CREATE TABLE `Himall_Coupon` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) DEFAULT NULL,
  `Price` decimal(18,0) NOT NULL,
  `PerMax` int(11) NOT NULL,
  `OrderAmount` decimal(18,0) NOT NULL,
  `Num` int(11) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  `CouponName` varchar(100) NOT NULL,
  `CreateTime` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_Coupon_Himall_Shops` (`ShopId`) USING BTREE,
  CONSTRAINT `himall_coupon_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_CouponRecord
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CouponRecord`;
CREATE TABLE `Himall_CouponRecord` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `CouponId` bigint(20) NOT NULL,
  `CounponSN` varchar(50) NOT NULL,
  `CounponTime` datetime NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `UserId` bigint(20) NOT NULL,
  `UsedTime` datetime DEFAULT NULL,
  `OrderId` bigint(20) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `CounponStatus` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_couponrecord_couponid` (`CouponId`) USING BTREE,
  KEY `FK_couponrecord_shopid` (`ShopId`) USING BTREE,
  CONSTRAINT `himall_couponrecord_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`),
  CONSTRAINT `himall_couponrecord_ibfk_2` FOREIGN KEY (`CouponId`) REFERENCES `Himall_Coupon` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_CouponSetting
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CouponSetting`;
CREATE TABLE `Himall_CouponSetting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PlatForm` int(11) NOT NULL,
  `CouponID` bigint(20) NOT NULL,
  `Display` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_CustomerServices
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CustomerServices`;
CREATE TABLE `Himall_CustomerServices` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Tool` int(11) NOT NULL,
  `Type` int(11) NOT NULL,
  `Name` varchar(1000) NOT NULL,
  `AccountCode` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Favorites
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Favorites`;
CREATE TABLE `Himall_Favorites` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `Tags` varchar(100) DEFAULT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_Favorite` (`UserId`) USING BTREE,
  KEY `FK_Product_Favorite` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_favorites_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_favorites_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=368 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_FavoriteShops
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FavoriteShops`;
CREATE TABLE `Himall_FavoriteShops` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `Tags` varchar(100) DEFAULT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_FloorBrands
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FloorBrands`;
CREATE TABLE `Himall_FloorBrands` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorId` bigint(20) NOT NULL,
  `BrandId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Brand_FloorBrand` (`BrandId`) USING BTREE,
  KEY `FK_HomeFloor_FloorBrand` (`FloorId`) USING BTREE,
  CONSTRAINT `himall_floorbrands_ibfk_1` FOREIGN KEY (`BrandId`) REFERENCES `Himall_Brands` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_floorbrands_ibfk_2` FOREIGN KEY (`FloorId`) REFERENCES `Himall_HomeFloors` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_FloorCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FloorCategories`;
CREATE TABLE `Himall_FloorCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorId` bigint(20) NOT NULL,
  `CategoryId` bigint(20) NOT NULL,
  `Depth` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Category_FloorCategory` (`CategoryId`) USING BTREE,
  KEY `FK_HomeFloor_FloorCategory` (`FloorId`) USING BTREE,
  CONSTRAINT `himall_floorcategories_ibfk_1` FOREIGN KEY (`CategoryId`) REFERENCES `Himall_Categories` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_floorcategories_ibfk_2` FOREIGN KEY (`FloorId`) REFERENCES `Himall_HomeFloors` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_FloorProducts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FloorProducts`;
CREATE TABLE `Himall_FloorProducts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorId` bigint(20) NOT NULL,
  `Tab` int(11) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_HomeFloor_FloorProduct` (`FloorId`) USING BTREE,
  KEY `FK_Product_FloorProduct` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_floorproducts_ibfk_1` FOREIGN KEY (`FloorId`) REFERENCES `Himall_HomeFloors` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_floorproducts_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_FloorTopics
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FloorTopics`;
CREATE TABLE `Himall_FloorTopics` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorId` bigint(20) NOT NULL,
  `TopicType` int(11) NOT NULL,
  `TopicImage` varchar(100) NOT NULL,
  `TopicName` varchar(100) NOT NULL,
  `Url` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_HomeFloor_FloorTopic` (`FloorId`) USING BTREE,
  CONSTRAINT `himall_floortopics_ibfk_1` FOREIGN KEY (`FloorId`) REFERENCES `Himall_HomeFloors` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1721 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_FreightAreaContent
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FreightAreaContent`;
CREATE TABLE `Himall_FreightAreaContent` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FreightTemplateId` bigint(20) NOT NULL,
  `AreaContent` varchar(4000) DEFAULT NULL,
  `FirstUnit` int(11) DEFAULT NULL,
  `FirstUnitMonry` float DEFAULT NULL,
  `AccumulationUnit` int(11) DEFAULT NULL,
  `AccumulationUnitMoney` float DEFAULT NULL,
  `IsDefault` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Freighttemalate_FreightAreaContent` (`FreightTemplateId`) USING BTREE,
  CONSTRAINT `himall_freightareacontent_ibfk_1` FOREIGN KEY (`FreightTemplateId`) REFERENCES `Himall_FreightTemplate` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_FreightTemplate
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FreightTemplate`;
CREATE TABLE `Himall_FreightTemplate` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `SourceAddress` int(11) DEFAULT NULL,
  `SendTime` varchar(100) DEFAULT NULL,
  `IsFree` int(11) NOT NULL,
  `ValuationMethod` int(11) NOT NULL,
  `ShippingMethod` int(11) DEFAULT NULL,
  `ShopID` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_HandSlideAds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_HandSlideAds`;
CREATE TABLE `Himall_HandSlideAds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ImageUrl` varchar(100) NOT NULL,
  `Url` varchar(1000) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_HomeCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_HomeCategories`;
CREATE TABLE `Himall_HomeCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `RowId` int(11) NOT NULL,
  `CategoryId` bigint(20) NOT NULL,
  `Depth` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Category_HomeCategory` (`CategoryId`) USING BTREE,
  CONSTRAINT `himall_homecategories_ibfk_1` FOREIGN KEY (`CategoryId`) REFERENCES `Himall_Categories` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1672 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_HomeCategoryRows
-- ----------------------------
DROP TABLE IF EXISTS `Himall_HomeCategoryRows`;
CREATE TABLE `Himall_HomeCategoryRows` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `RowId` int(11) NOT NULL,
  `Image1` varchar(100) NOT NULL,
  `Url1` varchar(100) NOT NULL,
  `Image2` varchar(100) NOT NULL,
  `Url2` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_HomeFloors
-- ----------------------------
DROP TABLE IF EXISTS `Himall_HomeFloors`;
CREATE TABLE `Himall_HomeFloors` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorName` varchar(100) NOT NULL,
  `SubName` varchar(100) DEFAULT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `IsShow` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ImageAds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ImageAds`;
CREATE TABLE `Himall_ImageAds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ImageUrl` varchar(100) NOT NULL,
  `Url` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_LimitTimeMarket
-- ----------------------------
DROP TABLE IF EXISTS `Himall_LimitTimeMarket`;
CREATE TABLE `Himall_LimitTimeMarket` (
  `Id` bigint(20) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `CategoryName` varchar(100) NOT NULL,
  `AuditStatus` smallint(6) NOT NULL,
  `AuditTime` datetime NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `Price` decimal(18,0) NOT NULL,
  `RecentMonthPrice` decimal(18,0) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  `Stock` int(11) NOT NULL,
  `SaleCount` int(11) NOT NULL,
  `CancelReson` text NOT NULL,
  `MaxSaleCount` int(11) NOT NULL,
  `ProductAd` varchar(100) NOT NULL,
  `MinPrice` decimal(18,0) NOT NULL,
  `ImagePath` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Logs
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Logs`;
CREATE TABLE `Himall_Logs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `PageUrl` varchar(1000) NOT NULL,
  `Date` datetime NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `IPAddress` varchar(100) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=1965 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Managers
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Managers`;
CREATE TABLE `Himall_Managers` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `RoleId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `PasswordSalt` varchar(100) NOT NULL,
  `CreateDate` datetime NOT NULL,
  `Remark` varchar(1000) DEFAULT NULL,
  `RealName` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MarketServiceRecord
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MarketServiceRecord`;
CREATE TABLE `Himall_MarketServiceRecord` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MarketServiceId` bigint(20) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_MarketServiceRecord_Himall_ActiveMarketService` (`MarketServiceId`),
  CONSTRAINT `FK_Himall_MarketServiceRecord_Himall_ActiveMarketService` FOREIGN KEY (`MarketServiceId`) REFERENCES `Himall_ActiveMarketService` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MarketSetting
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MarketSetting`;
CREATE TABLE `Himall_MarketSetting` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TypeId` int(11) NOT NULL,
  `Price` decimal(18,0) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MarketSettingMeta
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MarketSettingMeta`;
CREATE TABLE `Himall_MarketSettingMeta` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `MarketId` int(11) NOT NULL,
  `MetaKey` varchar(100) NOT NULL,
  `MetaValue` text,
  PRIMARY KEY (`Id`),
  KEY `FK_Hiamll_MarketSettingMeta_ToSetting` (`MarketId`),
  CONSTRAINT `FK_Hiamll_MarketSettingMeta_ToSetting` FOREIGN KEY (`MarketId`) REFERENCES `Himall_MarketSetting` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MemberContacts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberContacts`;
CREATE TABLE `Himall_MemberContacts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `UserType` int(11) NOT NULL,
  `ServiceProvider` varchar(40) NOT NULL,
  `Contact` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MemberGrade
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberGrade`;
CREATE TABLE `Himall_MemberGrade` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `GradeName` varchar(100) NOT NULL,
  `Integral` int(11) NOT NULL,
  `Remark` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MemberIntegral
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegral`;
CREATE TABLE `Himall_MemberIntegral` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MemberId` bigint(20) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `HistoryIntegrals` int(11) NOT NULL,
  `AvailableIntegrals` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_MemberIntegral` (`MemberId`),
  CONSTRAINT `FK_Member_MemberIntegral` FOREIGN KEY (`MemberId`) REFERENCES `Himall_Members` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MemberIntegralExchangeRules
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegralExchangeRules`;
CREATE TABLE `Himall_MemberIntegralExchangeRules` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `IntegralPerMoney` int(11) NOT NULL,
  `MoneyPerIntegral` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MemberIntegralRecord
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegralRecord`;
CREATE TABLE `Himall_MemberIntegralRecord` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MemberId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `TypeId` int(11) NOT NULL,
  `Integral` int(11) NOT NULL,
  `RecordDate` datetime DEFAULT NULL,
  `ReMark` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_MemberId_Members` (`MemberId`) USING BTREE,
  CONSTRAINT `himall_memberintegralrecord_ibfk_1` FOREIGN KEY (`MemberId`) REFERENCES `Himall_Members` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MemberIntegralRecordAction
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegralRecordAction`;
CREATE TABLE `Himall_MemberIntegralRecordAction` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `IntegralRecordId` bigint(20) NOT NULL,
  `VirtualItemTypeId` int(11) DEFAULT NULL,
  `VirtualItemId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_IntegralRecordId_MemberIntegralRecord` (`IntegralRecordId`) USING BTREE,
  CONSTRAINT `himall_memberintegralrecordaction_ibfk_1` FOREIGN KEY (`IntegralRecordId`) REFERENCES `Himall_MemberIntegralRecord` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MemberIntegralRule
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegralRule`;
CREATE TABLE `Himall_MemberIntegralRule` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TypeId` int(11) NOT NULL,
  `Integral` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MemberOpenIds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberOpenIds`;
CREATE TABLE `Himall_MemberOpenIds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `OpenId` varchar(100) NOT NULL,
  `ServiceProvider` varchar(40) NOT NULL,
  `AppIdType` int(255) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_MemberOpenId` (`UserId`) USING BTREE,
  CONSTRAINT `himall_memberopenids_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Members
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Members`;
CREATE TABLE `Himall_Members` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `PasswordSalt` varchar(100) NOT NULL,
  `Nick` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `CreateDate` datetime NOT NULL,
  `TopRegionId` int(11) NOT NULL,
  `RegionId` int(11) NOT NULL,
  `RealName` varchar(100) DEFAULT NULL,
  `CellPhone` varchar(100) DEFAULT NULL,
  `QQ` varchar(100) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Disabled` tinyint(1) NOT NULL,
  `LastLoginDate` datetime NOT NULL,
  `OrderNumber` int(11) NOT NULL,
  `Expenditure` decimal(8,2) NOT NULL,
  `Points` int(11) NOT NULL,
  `Photo` varchar(100) DEFAULT NULL,
  `ParentSellerId` bigint(20) NOT NULL DEFAULT '0',
  `Remark` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Menus
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Menus`;
CREATE TABLE `Himall_Menus` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParentId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `Title` varchar(10) NOT NULL,
  `Url` varchar(200) DEFAULT NULL,
  `Depth` smallint(6) NOT NULL,
  `Sequence` smallint(6) NOT NULL,
  `FullIdPath` varchar(100) NOT NULL,
  `Platform` int(11) NOT NULL,
  `UrlType` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MessageLog
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MessageLog`;
CREATE TABLE `Himall_MessageLog` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) DEFAULT NULL,
  `TypeId` varchar(100) DEFAULT NULL,
  `MessageContent` char(1) DEFAULT NULL,
  `SendTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=718 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MobileHomeProducts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MobileHomeProducts`;
CREATE TABLE `Himall_MobileHomeProducts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `PlatFormType` int(11) NOT NULL,
  `Sequence` smallint(6) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_MobileHomeProducts_Himall_Products` (`ProductId`),
  CONSTRAINT `FK_Himall_MobileHomeProducts_Himall_Products` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_MobileHomeTopics
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MobileHomeTopics`;
CREATE TABLE `Himall_MobileHomeTopics` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL DEFAULT '0',
  `Platform` int(11) NOT NULL,
  `TopicId` bigint(20) NOT NULL,
  `Sequence` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `FK__Himall_Mo__Topic__02C769E9` (`TopicId`),
  CONSTRAINT `FK__Himall_Mo__Topic__02C769E9` FOREIGN KEY (`TopicId`) REFERENCES `Himall_Topics` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ModuleProducts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ModuleProducts`;
CREATE TABLE `Himall_ModuleProducts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ModuleId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ModuleProduct` (`ProductId`) USING BTREE,
  KEY `FK_TopicModule_ModuleProduct` (`ModuleId`) USING BTREE,
  CONSTRAINT `himall_moduleproducts_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_moduleproducts_ibfk_2` FOREIGN KEY (`ModuleId`) REFERENCES `Himall_TopicModules` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_OrderComments
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderComments`;
CREATE TABLE `Himall_OrderComments` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `CommentDate` datetime NOT NULL,
  `PackMark` int(11) NOT NULL,
  `DeliveryMark` int(11) NOT NULL,
  `ServiceMark` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Order_OrderComment` (`OrderId`) USING BTREE,
  CONSTRAINT `himall_ordercomments_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `Himall_Orders` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_OrderComplaints
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderComplaints`;
CREATE TABLE `Himall_OrderComplaints` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `Status` int(11) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `ShopPhone` varchar(20) NOT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `UserPhone` varchar(20) DEFAULT NULL,
  `ComplaintDate` datetime NOT NULL,
  `ComplaintReason` varchar(1000) NOT NULL,
  `SellerReply` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Order_OrderComplaint` (`OrderId`) USING BTREE,
  CONSTRAINT `himall_ordercomplaints_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `Himall_Orders` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_OrderItems
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderItems`;
CREATE TABLE `Himall_OrderItems` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `SkuId` varchar(100) DEFAULT NULL,
  `SKU` varchar(20) DEFAULT NULL,
  `Quantity` bigint(20) NOT NULL,
  `ReturnQuantity` bigint(20) NOT NULL,
  `CostPrice` decimal(8,2) NOT NULL,
  `SalePrice` decimal(8,2) NOT NULL,
  `DiscountAmount` decimal(8,2) NOT NULL,
  `RealTotalPrice` decimal(8,2) NOT NULL,
  `RefundPrice` decimal(8,2) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `Color` varchar(100) DEFAULT NULL,
  `Size` varchar(100) DEFAULT NULL,
  `Version` varchar(100) DEFAULT NULL,
  `ThumbnailsUrl` varchar(100) DEFAULT NULL,
  `CommisRate` decimal(8,2) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Order_OrderItem` (`OrderId`) USING BTREE,
  CONSTRAINT `himall_orderitems_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `Himall_Orders` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1344 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_OrderOperationLogs
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderOperationLogs`;
CREATE TABLE `Himall_OrderOperationLogs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `Operator` varchar(100) NOT NULL,
  `OperateDate` datetime NOT NULL,
  `OperateContent` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Order_OrderOperationLog` (`OrderId`) USING BTREE,
  CONSTRAINT `himall_orderoperationlogs_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `Himall_Orders` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=884 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_OrderRefunds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderRefunds`;
CREATE TABLE `Himall_OrderRefunds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `OrderItemId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `UserId` bigint(20) NOT NULL,
  `Applicant` varchar(100) NOT NULL,
  `ContactPerson` varchar(100) DEFAULT NULL,
  `ContactCellPhone` varchar(100) DEFAULT NULL,
  `RefundAccount` varchar(100) DEFAULT NULL,
  `ApplyDate` datetime NOT NULL,
  `Amount` decimal(8,2) NOT NULL,
  `Reason` varchar(1000) NOT NULL,
  `SellerAuditStatus` int(11) NOT NULL,
  `SellerAuditDate` datetime NOT NULL,
  `SellerRemark` varchar(1000) DEFAULT NULL,
  `ManagerConfirmStatus` int(11) NOT NULL,
  `ManagerConfirmDate` datetime NOT NULL,
  `ManagerRemark` varchar(1000) DEFAULT NULL,
  `IsReturn` tinyint(1) NOT NULL,
  `ExpressCompanyName` varchar(100) DEFAULT NULL,
  `ShipOrderNumber` varchar(100) DEFAULT NULL,
  `Payee` varchar(200) DEFAULT NULL,
  `PayeeAccount` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_OrderItem_OrderRefund` (`OrderItemId`) USING BTREE,
  CONSTRAINT `himall_orderrefunds_ibfk_1` FOREIGN KEY (`OrderItemId`) REFERENCES `Himall_OrderItems` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Orders
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Orders`;
CREATE TABLE `Himall_Orders` (
  `Id` bigint(20) NOT NULL,
  `OrderStatus` int(11) NOT NULL,
  `OrderDate` datetime NOT NULL,
  `CloseReason` varchar(1000) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `SellerPhone` varchar(20) DEFAULT NULL,
  `SellerAddress` varchar(100) DEFAULT NULL,
  `SellerRemark` varchar(1000) DEFAULT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `UserRemark` varchar(1000) DEFAULT NULL,
  `ShipTo` varchar(100) NOT NULL,
  `CellPhone` varchar(20) DEFAULT NULL,
  `TopRegionId` int(11) NOT NULL,
  `RegionId` int(11) NOT NULL,
  `RegionFullName` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `ExpressCompanyName` varchar(100) DEFAULT NULL,
  `Freight` decimal(8,2) NOT NULL,
  `ShipOrderNumber` varchar(100) DEFAULT NULL,
  `ShippingDate` datetime DEFAULT NULL,
  `IsPrinted` tinyint(1) NOT NULL,
  `PaymentTypeName` varchar(100) DEFAULT NULL,
  `PaymentTypeGateway` varchar(100) DEFAULT NULL,
  `GatewayOrderId` varchar(100) DEFAULT NULL,
  `PayRemark` varchar(1000) DEFAULT NULL,
  `PayDate` datetime DEFAULT NULL,
  `InvoiceType` int(11) NOT NULL,
  `InvoiceTitle` varchar(100) DEFAULT NULL,
  `Tax` decimal(8,2) NOT NULL,
  `FinishDate` datetime DEFAULT NULL,
  `ProductTotalAmount` decimal(8,2) NOT NULL,
  `RefundTotalAmount` decimal(8,2) NOT NULL,
  `CommisTotalAmount` decimal(8,2) NOT NULL,
  `RefundCommisAmount` decimal(8,2) NOT NULL,
  `ActiveType` int(11) NOT NULL DEFAULT '0',
  `Platform` int(11) NOT NULL DEFAULT '0',
  `DiscountAmount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `IntegralDiscount` decimal(18,2) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ProductAttributes
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductAttributes`;
CREATE TABLE `Himall_ProductAttributes` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProductId` bigint(20) NOT NULL,
  `AttributeId` bigint(20) NOT NULL,
  `ValueId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Attribute_ProductAttribute` (`AttributeId`) USING BTREE,
  KEY `FK_Product_ProductAttribute` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_productattributes_ibfk_1` FOREIGN KEY (`AttributeId`) REFERENCES `Himall_Attributes` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_productattributes_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4392 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ProductComments
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductComments`;
CREATE TABLE `Himall_ProductComments` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `SubOrderId` bigint(20) DEFAULT NULL,
  `ProductId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) DEFAULT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `Email` varchar(1000) DEFAULT NULL,
  `ReviewContent` varchar(1000) DEFAULT NULL,
  `ReviewDate` datetime NOT NULL,
  `ReviewMark` int(11) NOT NULL,
  `ReplyContent` varchar(1000) DEFAULT NULL,
  `ReplyDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ProductComment` (`ProductId`) USING BTREE,
  KEY `SubOrderId` (`SubOrderId`) USING BTREE,
  KEY `ShopId` (`ShopId`) USING BTREE,
  KEY `UserId` (`UserId`) USING BTREE,
  CONSTRAINT `himall_productcomments_ibfk_1` FOREIGN KEY (`SubOrderId`) REFERENCES `Himall_OrderItems` (`Id`),
  CONSTRAINT `himall_productcomments_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`),
  CONSTRAINT `himall_productcomments_ibfk_3` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`),
  CONSTRAINT `himall_productcomments_ibfk_4` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=359 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ProductConsultations
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductConsultations`;
CREATE TABLE `Himall_ProductConsultations` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProductId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) DEFAULT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `Email` varchar(1000) DEFAULT NULL,
  `ConsultationContent` varchar(1000) DEFAULT NULL,
  `ConsultationDate` datetime NOT NULL,
  `ReplyContent` varchar(1000) DEFAULT NULL,
  `ReplyDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ProductConsultation` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_productconsultations_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ProductDescriptions
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductDescriptions`;
CREATE TABLE `Himall_ProductDescriptions` (
  `Id` bigint(20) DEFAULT NULL,
  `ProductId` bigint(20) NOT NULL,
  `AuditReason` varchar(1000) DEFAULT NULL,
  `Description` text,
  `DescriptionPrefixId` bigint(20) NOT NULL,
  `DescriptiondSuffixId` bigint(20) NOT NULL,
  `Meta_Title` varchar(1000) DEFAULT NULL,
  `Meta_Description` varchar(1000) DEFAULT NULL,
  `Meta_Keywords` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ProductId`),
  KEY `FK_Product_ProductDescription` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_productdescriptions_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ProductDescriptionTemplates
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductDescriptionTemplates`;
CREATE TABLE `Himall_ProductDescriptionTemplates` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Position` int(11) NOT NULL,
  `Content` varchar(4000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Products
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Products`;
CREATE TABLE `Himall_Products` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `CategoryId` bigint(20) NOT NULL,
  `CategoryPath` varchar(100) NOT NULL,
  `TypeId` bigint(20) NOT NULL,
  `BrandId` bigint(20) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `ProductCode` varchar(100) DEFAULT NULL,
  `ShortDescription` varchar(4000) DEFAULT NULL,
  `SaleStatus` int(11) NOT NULL,
  `AuditStatus` int(11) NOT NULL,
  `AddedDate` datetime NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `ImagePath` varchar(100) DEFAULT NULL,
  `MarketPrice` decimal(8,2) NOT NULL,
  `MinSalePrice` decimal(8,2) NOT NULL,
  `HasSKU` tinyint(1) NOT NULL,
  `VistiCounts` bigint(20) NOT NULL,
  `SaleCounts` bigint(20) NOT NULL,
  `FreightTemplateId` bigint(20) NOT NULL,
  `Weight` decimal(18,2) DEFAULT NULL,
  `Volume` decimal(18,2) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `MeasureUnit` varchar(20) DEFAULT NULL COMMENT '计量单位',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ProductShopCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductShopCategories`;
CREATE TABLE `Himall_ProductShopCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProductId` bigint(20) NOT NULL,
  `ShopCategoryId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ProductShopCategory` (`ProductId`) USING BTREE,
  KEY `FK_ShopCategory_ProductShopCategory` (`ShopCategoryId`) USING BTREE,
  CONSTRAINT `himall_productshopcategories_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_productshopcategories_ibfk_2` FOREIGN KEY (`ShopCategoryId`) REFERENCES `Himall_ShopCategories` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1305 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ProductVistis
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductVistis`;
CREATE TABLE `Himall_ProductVistis` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProductId` bigint(20) NOT NULL,
  `Date` datetime NOT NULL,
  `VistiCounts` bigint(20) NOT NULL,
  `SaleCounts` bigint(20) NOT NULL,
  `SaleAmounts` decimal(8,2) NOT NULL,
  `OrderCounts` bigint(20) unsigned DEFAULT '0' COMMENT '订单总数',
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ProductVisti` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_productvistis_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1336 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_RolePrivileges
-- ----------------------------
DROP TABLE IF EXISTS `Himall_RolePrivileges`;
CREATE TABLE `Himall_RolePrivileges` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Privilege` int(11) NOT NULL,
  `RoleId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Role_RolePrivilege` (`RoleId`) USING BTREE,
  CONSTRAINT `himall_roleprivileges_ibfk_1` FOREIGN KEY (`RoleId`) REFERENCES `Himall_Roles` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=424 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Roles
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Roles`;
CREATE TABLE `Himall_Roles` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `RoleName` varchar(100) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_SellerSpecificationValues
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SellerSpecificationValues`;
CREATE TABLE `Himall_SellerSpecificationValues` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ValueId` bigint(20) NOT NULL,
  `Specification` int(11) NOT NULL,
  `TypeId` bigint(20) NOT NULL,
  `Value` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_SpecificationValue_SellerSpecificationValue` (`ValueId`) USING BTREE,
  CONSTRAINT `himall_sellerspecificationvalues_ibfk_1` FOREIGN KEY (`ValueId`) REFERENCES `Himall_SpecificationValues` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_SensitiveWords
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SensitiveWords`;
CREATE TABLE `Himall_SensitiveWords` (
  `Id` int(4) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `SensitiveWord` varchar(100) DEFAULT NULL COMMENT '敏感词',
  `CategoryName` varchar(100) DEFAULT NULL COMMENT '敏感词类别',
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ShippingAddresses
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShippingAddresses`;
CREATE TABLE `Himall_ShippingAddresses` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `RegionId` int(11) NOT NULL,
  `ShipTo` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `IsDefault` tinyint(1) NOT NULL,
  `IsQuick` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_ShippingAddress` (`UserId`) USING BTREE,
  CONSTRAINT `himall_shippingaddresses_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ShopBrandApplys
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopBrandApplys`;
CREATE TABLE `Himall_ShopBrandApplys` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `ShopId` bigint(20) NOT NULL COMMENT '商家Id',
  `BrandId` bigint(20) DEFAULT NULL COMMENT '品牌Id',
  `BrandName` varchar(100) DEFAULT NULL COMMENT '品牌名称',
  `Logo` varchar(1000) DEFAULT NULL COMMENT '品牌Logo',
  `Description` varchar(1000) DEFAULT NULL COMMENT '描述',
  `AuthCertificate` varchar(4000) DEFAULT NULL COMMENT '品牌授权证书',
  `ApplyMode` int(11) NOT NULL COMMENT '申请类型 枚举 BrandApplyMode',
  `Remark` varchar(1000) DEFAULT NULL COMMENT '备注',
  `AuditStatus` int(11) NOT NULL COMMENT '审核状态 枚举 BrandAuditStatus',
  `ApplyTime` datetime NOT NULL COMMENT '操作时间',
  PRIMARY KEY (`Id`),
  KEY `FK_ShopId` (`ShopId`) USING BTREE,
  KEY `FK_BrandId` (`BrandId`) USING BTREE,
  KEY `Id` (`Id`) USING BTREE,
  CONSTRAINT `himall_shopbrandapplys_ibfk_1` FOREIGN KEY (`BrandId`) REFERENCES `Himall_Brands` (`Id`),
  CONSTRAINT `himall_shopbrandapplys_ibfk_2` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for Himall_ShopBrands
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopBrands`;
CREATE TABLE `Himall_ShopBrands` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `ShopId` bigint(20) NOT NULL COMMENT '商家Id',
  `BrandId` bigint(20) NOT NULL COMMENT '品牌Id',
  PRIMARY KEY (`Id`),
  KEY `ShopId` (`ShopId`) USING BTREE,
  KEY `BrandId` (`BrandId`) USING BTREE,
  KEY `Id` (`Id`) USING BTREE,
  CONSTRAINT `himall_shopbrands_ibfk_1` FOREIGN KEY (`BrandId`) REFERENCES `Himall_Brands` (`Id`),
  CONSTRAINT `himall_shopbrands_ibfk_2` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for Himall_ShopCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopCategories`;
CREATE TABLE `Himall_ShopCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ParentCategoryId` bigint(20) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `IsShow` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=274 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ShopGrades
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopGrades`;
CREATE TABLE `Himall_ShopGrades` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `ProductLimit` int(11) NOT NULL,
  `ImageLimit` int(11) NOT NULL,
  `TemplateLimit` int(11) NOT NULL,
  `ChargeStandard` decimal(8,2) NOT NULL,
  `Remark` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ShopHomeModuleProducts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopHomeModuleProducts`;
CREATE TABLE `Himall_ShopHomeModuleProducts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `HomeModuleId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ShopHomeModuleProduct` (`ProductId`) USING BTREE,
  KEY `FK_ShopHomeModule_ShopHomeModuleProduct` (`HomeModuleId`) USING BTREE,
  CONSTRAINT `himall_shophomemoduleproducts_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_shophomemoduleproducts_ibfk_2` FOREIGN KEY (`HomeModuleId`) REFERENCES `Himall_ShopHomeModules` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ShopHomeModules
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopHomeModules`;
CREATE TABLE `Himall_ShopHomeModules` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ShoppingCarts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShoppingCarts`;
CREATE TABLE `Himall_ShoppingCarts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `SkuId` varchar(100) DEFAULT NULL,
  `Quantity` bigint(20) NOT NULL,
  `AddTime` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_ShoppingCart` (`UserId`) USING BTREE,
  KEY `FK_Product_ShoppingCart` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_shoppingcarts_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_shoppingcarts_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Shops
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Shops`;
CREATE TABLE `Himall_Shops` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `GradeId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `Logo` varchar(100) DEFAULT NULL,
  `SubDomains` varchar(100) DEFAULT NULL,
  `Theme` varchar(100) DEFAULT NULL,
  `IsSelf` tinyint(1) NOT NULL,
  `ShopStatus` int(11) NOT NULL,
  `RefuseReason` varchar(1000) DEFAULT NULL,
  `CreateDate` datetime NOT NULL,
  `EndDate` datetime DEFAULT NULL,
  `CompanyName` varchar(100) DEFAULT NULL,
  `CompanyRegionId` int(11) NOT NULL,
  `CompanyAddress` varchar(100) DEFAULT NULL,
  `CompanyPhone` varchar(20) DEFAULT NULL,
  `CompanyEmployeeCount` int(11) NOT NULL,
  `CompanyRegisteredCapital` decimal(8,2) NOT NULL,
  `ContactsName` varchar(100) DEFAULT NULL,
  `ContactsPhone` varchar(20) DEFAULT NULL,
  `ContactsEmail` varchar(100) DEFAULT NULL,
  `BusinessLicenceNumber` varchar(100) DEFAULT NULL,
  `BusinessLicenceNumberPhoto` varchar(100) NOT NULL,
  `BusinessLicenceRegionId` int(11) NOT NULL,
  `BusinessLicenceStart` datetime DEFAULT NULL,
  `BusinessLicenceEnd` datetime DEFAULT NULL,
  `BusinessSphere` varchar(100) DEFAULT NULL,
  `OrganizationCode` varchar(100) DEFAULT NULL,
  `OrganizationCodePhoto` varchar(100) DEFAULT NULL,
  `GeneralTaxpayerPhot` varchar(100) DEFAULT NULL,
  `BankAccountName` varchar(100) DEFAULT NULL,
  `BankAccountNumber` varchar(100) DEFAULT NULL,
  `BankName` varchar(100) DEFAULT NULL,
  `BankCode` varchar(100) DEFAULT NULL,
  `BankRegionId` int(11) NOT NULL,
  `BankPhoto` varchar(100) DEFAULT NULL,
  `TaxRegistrationCertificate` varchar(100) DEFAULT NULL,
  `TaxpayerId` varchar(100) DEFAULT NULL,
  `TaxRegistrationCertificatePhoto` varchar(100) DEFAULT NULL,
  `PayPhoto` varchar(100) DEFAULT NULL,
  `PayRemark` varchar(1000) DEFAULT NULL,
  `SenderName` varchar(100) DEFAULT NULL,
  `SenderAddress` varchar(100) DEFAULT NULL,
  `SenderPhone` varchar(100) DEFAULT NULL,
  `Freight` decimal(18,2) NOT NULL,
  `FreeFreight` decimal(18,2) NOT NULL,
  `Stage` int(11) DEFAULT '0',
  `SenderRegionId` int(11) DEFAULT NULL,
  `BusinessLicenseCert` varchar(120) DEFAULT NULL,
  `ProductCert` varchar(120) DEFAULT NULL,
  `OtherCert` varchar(120) DEFAULT NULL,
  `legalPerson` varchar(50) DEFAULT NULL COMMENT '法人代表',
  `CompanyFoundingDate` datetime DEFAULT NULL COMMENT '公司成立日期',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_ShopVistis
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopVistis`;
CREATE TABLE `Himall_ShopVistis` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Date` datetime NOT NULL,
  `VistiCounts` bigint(20) NOT NULL,
  `SaleCounts` bigint(20) NOT NULL,
  `SaleAmounts` decimal(8,2) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_SiteSettings
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SiteSettings`;
CREATE TABLE `Himall_SiteSettings` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Key` varchar(100) NOT NULL,
  `Value` varchar(4000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_SKUs
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SKUs`;
CREATE TABLE `Himall_SKUs` (
  `Id` varchar(100) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `Color` varchar(100) DEFAULT NULL,
  `Size` varchar(100) DEFAULT NULL,
  `Version` varchar(100) DEFAULT NULL,
  `Sku` varchar(100) DEFAULT NULL,
  `Stock` bigint(20) NOT NULL,
  `CostPrice` decimal(8,2) NOT NULL,
  `SalePrice` decimal(8,2) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_Sku` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_skus_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_SlideAds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SlideAds`;
CREATE TABLE `Himall_SlideAds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ImageUrl` varchar(100) NOT NULL,
  `Url` varchar(1000) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `TypeId` int(11) NOT NULL DEFAULT '0',
  `Description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_SpecificationValues
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SpecificationValues`;
CREATE TABLE `Himall_SpecificationValues` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Specification` int(11) NOT NULL,
  `TypeId` bigint(20) NOT NULL,
  `Value` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Type_SpecificationValue` (`TypeId`) USING BTREE,
  CONSTRAINT `himall_specificationvalues_ibfk_1` FOREIGN KEY (`TypeId`) REFERENCES `Himall_Types` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=580 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_StatisticOrderComments
-- ----------------------------
DROP TABLE IF EXISTS `Himall_StatisticOrderComments`;
CREATE TABLE `Himall_StatisticOrderComments` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `CommentKey` int(11) NOT NULL,
  `CommentValue` decimal(10,4) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `himall_statisticordercomments_ibfk_1` (`ShopId`) USING BTREE,
  CONSTRAINT `himall_statisticordercomments_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='订单评价统计表';

-- ----------------------------
-- Table structure for Himall_TopicModules
-- ----------------------------
DROP TABLE IF EXISTS `Himall_TopicModules`;
CREATE TABLE `Himall_TopicModules` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TopicId` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Topic_TopicModule` (`TopicId`) USING BTREE,
  CONSTRAINT `himall_topicmodules_ibfk_1` FOREIGN KEY (`TopicId`) REFERENCES `Himall_Topics` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Topics
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Topics`;
CREATE TABLE `Himall_Topics` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `FrontCoverImage` varchar(100) DEFAULT NULL,
  `TopImage` varchar(100) NOT NULL,
  `BackgroundImage` varchar(100) NOT NULL,
  `PlatForm` int(11) NOT NULL DEFAULT '0',
  `Tags` varchar(100) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_TypeBrands
-- ----------------------------
DROP TABLE IF EXISTS `Himall_TypeBrands`;
CREATE TABLE `Himall_TypeBrands` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TypeId` bigint(20) NOT NULL,
  `BrandId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Brand_TypeBrand` (`BrandId`) USING BTREE,
  KEY `FK_Type_TypeBrand` (`TypeId`) USING BTREE,
  CONSTRAINT `himall_typebrands_ibfk_1` FOREIGN KEY (`BrandId`) REFERENCES `Himall_Brands` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_typebrands_ibfk_2` FOREIGN KEY (`TypeId`) REFERENCES `Himall_Types` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1475 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_Types
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Types`;
CREATE TABLE `Himall_Types` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `IsSupportColor` tinyint(1) NOT NULL,
  `IsSupportSize` tinyint(1) NOT NULL,
  `IsSupportVersion` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_VShop
-- ----------------------------
DROP TABLE IF EXISTS `Himall_VShop`;
CREATE TABLE `Himall_VShop` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL,
  `CreateTime` datetime NOT NULL,
  `VisitNum` int(11) NOT NULL,
  `buyNum` int(11) NOT NULL,
  `State` int(11) NOT NULL,
  `Logo` varchar(200) DEFAULT NULL,
  `BackgroundImage` varchar(200) DEFAULT NULL,
  `Description` varchar(30) DEFAULT NULL,
  `Tags` varchar(100) DEFAULT NULL,
  `HomePageTitle` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_vshop_shopinfo` (`ShopId`) USING BTREE,
  CONSTRAINT `himall_vshop_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_VShopExtend
-- ----------------------------
DROP TABLE IF EXISTS `Himall_VShopExtend`;
CREATE TABLE `Himall_VShopExtend` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `VShopId` bigint(20) NOT NULL,
  `Sequence` int(11) DEFAULT NULL,
  `Type` int(11) NOT NULL,
  `AddTime` datetime NOT NULL,
  `State` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_vshopextend_vshop` (`VShopId`) USING BTREE,
  CONSTRAINT `himall_vshopextend_ibfk_1` FOREIGN KEY (`VShopId`) REFERENCES `Himall_VShop` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for Himall_WXshop
-- ----------------------------
DROP TABLE IF EXISTS `Himall_WXshop`;
CREATE TABLE `Himall_WXshop` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `AppId` varchar(30) NOT NULL,
  `AppSecret` varchar(35) NOT NULL,
  `Token` varchar(30) NOT NULL,
  `FollowUrl` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Procedure structure for sp_InsertProduct_proc
-- ----------------------------
DROP PROCEDURE IF EXISTS `sp_InsertProduct_proc`;
DELIMITER ;;
CREATE DEFINER=`himaller`@`%` PROCEDURE `sp_InsertProduct_proc`(
IN $shopName VARCHAR(100),/*店铺名称*/
IN $CategoryId BIGINT,/*分类ID*/
IN $ProductName VARCHAR(100),/*产品名称*/
IN $ProductPath VARCHAR(100),/*产品路径*/
IN $MarketPrice DECIMAL(8,2),/*市场价格*/
IN $MinsalePrice DECIMAL(8,2),/*销售价格*/
IN $MeasureUnit varchar(20),/*单位*/
IN $KeyWords varchar(1000),/*关键字*/
In $SaleCount int,/*销售数量*/
IN $ShortDescription  varchar(4000),/*简短描述*/
IN $Description Text,/*描述*/
IN $RegionId int, /*地区模板的ID*/
IN $CompanyRegionId int,/*公司地区模板的ID*/
IN $CompanyName VARCHAR(100),/*公司名称*/
IN $CompanyPhone VARCHAR(20), /*公司电话*/
OUT $p_sqlcode   INT,  
OUT $p_status_message  VARCHAR(100) 
)
BEGIN
DECLARE t_ShopID bigint DEFAULT -1;
DECLARE t_ProductId BIGINT  DEFAULT -1;
DECLARE t_CategoryId BIGINT  DEFAULT -1;
DECLARE t_TypeId BIGINT DEFAULT 1;
DECLARE t_CategoryPath VARCHAR(100) DEFAULT '1';
DECLARE t_RegionId INT default 0;
DECLARE t_FreightTemplateId int DEFAULT 0;
DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN  
        SET $p_sqlcode=1;  
        SET $p_status_message=CONCAT('店铺名:',$shopName,',产品名:',$ProductName,',插入错误');  
    END;  
/*插入店铺信息*/
SELECT Id into t_ShopID from Himall_Shops where shopName = $shopName LIMIT 1;
IF(t_ShopID=-1) THEN
 insert into Himall_Shops(shopName,gradeId,IsSelf,shopStatus,createDate,EndDate,CompanyRegionId,CompanyEmployeeCount,CompanyRegisteredCapital,BusinessLicenceNumberPhoto,
BusinessLicenceRegionId,BankRegionId,FreeFreight,Freight,Stage,CompanyName,CompanyPhone) 
values($shopName,0,0,7,'2000-01-01 00:00:00','2999-01-01 00:00:00',$CompanyRegionId,0,0,"",0,0,0,0,6,$CompanyName,$CompanyPhone);
set t_ShopID=last_insert_id();
end if;

SELECT SourceAddress,Id into t_RegionId,t_FreightTemplateId from Himall_FreightTemplate where ShopID=t_ShopID and SourceAddress=$RegionId LIMIT 1;
if(t_RegionId=0) THEN
INSERT INTO `Himall_FreightTemplate`(`Id`,`Name`,`SourceAddress`,`SendTime`,`IsFree`,`ValuationMethod`,`ShippingMethod`, `ShopID`) 
 VALUES (0,'默认运费模板', $RegionId, null, '1', '0', null, t_ShopID);
set t_FreightTemplateId=last_insert_id();
END IF;
/*分类信息*/
select Id,Path,TypeId into t_CategoryId,t_CategoryPath,t_TypeId from Himall_Categories where Id=$CategoryId LIMIT 1;
if(t_CategoryId>0) THEN
/*插入产品信息*/
SELECT Id  into t_ProductId from Himall_Products where ProductName = $ProductName  and ShopId=t_ShopID and CategoryId=$CategoryId LIMIT 1;
end if;
if(t_productId=-1) then
/*set @pid=(SELECT ifnull(Max(Id)+1,1)  from Himall_Products);*/
insert into Himall_Products(productName,ImagePath,brandId,ShopId,CategoryId,CategoryPath,TypeId,AddedDate,DisplaySequence,MarketPrice,MinSalePrice,HasSKU,MeasureUnit,FreightTemplateId,VistiCounts,SaleCounts,SaleStatus,AuditStatus,shortDescription) 
values($productName,$ProductPath,0,t_ShopID,t_CategoryId,t_CategoryPath,t_TypeId,'2000-01-01 00:00:00',1,$MarketPrice,$MinsalePrice,0,$MeasureUnit,t_FreightTemplateId,126,$SaleCount,1,2,$ShortDescription);
/*set t_ProductId=last_insert_id();*/
set t_productId=last_insert_id();
INSERT into Himall_ProductDescriptions(Id,ProductId,Meta_Keywords,Description,DescriptionPrefixId,DescriptiondSuffixId)
 values(0,t_ProductId,$KeyWords,$Description,0,0);
set @sku=CONCAT(t_ProductId,"_0_0_0");
INSERT INTO `Himall_SKUs` VALUES (@sku, t_ProductId, '', '', '', '', 199,$MarketPrice,$MinsalePrice);
end if;
END
;;
DELIMITER ;
