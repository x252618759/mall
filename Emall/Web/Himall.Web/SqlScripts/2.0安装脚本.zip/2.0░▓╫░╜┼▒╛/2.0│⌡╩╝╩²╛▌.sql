-- ----------------------------
-- Records of Himall_ArticleCategories
-- ----------------------------
INSERT INTO `Himall_ArticleCategories` VALUES ('1', '0', '首页服务', '1', '1');
INSERT INTO `Himall_ArticleCategories` VALUES ('2', '0', '系统快报', '2', '1');
INSERT INTO `Himall_ArticleCategories` VALUES ('3', '0', '平台公告', '3', '1');
INSERT INTO `Himall_ArticleCategories` VALUES ('4', '0', '资讯中心', '4', '1');
INSERT INTO `Himall_ArticleCategories` VALUES ('9', '1', '购物指南', '1', '0');
INSERT INTO `Himall_ArticleCategories` VALUES ('10', '1', '店主之家', '1', '0');
INSERT INTO `Himall_ArticleCategories` VALUES ('11', '1', '支付方式', '1', '0');
INSERT INTO `Himall_ArticleCategories` VALUES ('12', '1', '售后服务', '1', '0');
INSERT INTO `Himall_ArticleCategories` VALUES ('13', '1', '关于我们', '1', '0');



-- ----------------------------
-- Records of Himall_Articles
-- ----------------------------
INSERT INTO `Himall_Articles` VALUES ('1', '2', '4K智能电视2599元起', null, '<p>4K智能电视2599元起</p>', '2014-09-24 15:32:58', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('2', '2', '9.9元起，品蟹品酒季', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"9.9元起，品蟹品酒季\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">9.9元起，品蟹品酒季</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:15', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('3', '2', '彩票2元，买了就抽奖！', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"彩票2元，买了就抽奖！\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">彩票2元，买了就抽奖！</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:26', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('4', '2', '秋季运动惠大牌低至5折', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"秋季运动惠大牌低至5折\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">秋季运动惠大牌低至5折</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:36', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('5', '2', '《好妈妈2》新书7折抢', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"《好妈妈2》新书7折抢\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">《好妈妈2》新书7折抢</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:45', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('6', '2', '秋季服装 五折封顶', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"秋季服装 五折封顶    \" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">秋季服装 五折封顶</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:53', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('7', '2', '十一提前购 美孚299疯抢', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"十一提前购 美孚299疯抢\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">十一提前购 美孚299疯抢</a></p></li></ul><p><br/></p>', '2014-09-24 15:34:02', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('8', '2', '好蟹四免一', null, '<p><a target=\"_blank\" title=\"京东管控 好蟹四免一\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none; font-family: Arial, Verdana, 宋体; font-size: 12px; line-height: 25px; white-space: normal; background-color: rgb(255, 255, 255);\">好蟹四免一</a></p>', '2014-09-24 15:34:13', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('12', '3', '良良寝居满319减80 ', null, '<p>良良寝居满319减80 </p>', '2014-10-27 00:00:00', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('13', '9', '购物流程图', null, '<p><img alt=\"\" src=\"/Storage/Plat/Article/13/b116555e5f664e8ebeaebf8d783b4916.jpg\" style=\"margin: 10px; padding: 0px; vertical-align: middle; color: rgb(102, 102, 102); font-family: Arial, Verdana, 宋体; font-size: 12px; line-height: 18px; white-space: normal; background-color: rgb(255, 255, 255);\"/></p>', '2014-11-06 14:54:04', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('14', '9', '会员介绍', null, '<p style=\"text-align: center;\">会员介绍</p>', '2014-11-06 15:15:01', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('15', '9', '常见问题', null, '<p style=\"text-align: center;\"><a target=\"_blank\" rel=\"nofollow\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none; font-family: Arial, Verdana, 宋体; font-size: 12px; line-height: 20px; white-space: normal; background-color: rgb(255, 255, 255);\">常见问题</a></p>', '2014-11-06 15:15:17', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('16', '9', '联系客服', null, '<p style=\"text-align: center;\"><a target=\"_blank\" rel=\"nofollow\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none; font-family: Arial, Verdana, 宋体; font-size: 12px; line-height: 20px; white-space: normal; background-color: rgb(255, 255, 255);\">联系客服</a></p>', '2014-11-06 15:15:29', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('17', '10', '如何申请开店', null, '<p style=\"text-align: center;\"><a title=\"如何申请开店\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">如何申请开店</a></p>', '2014-11-06 15:17:26', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('18', '10', '查看售出商品', null, '<p style=\"text-align: center;\"><a title=\"查看售出商品\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">查看售出商品</a></p>', '2014-11-06 15:17:41', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('19', '10', '商城商品推荐', null, '<p style=\"text-align: center;\"><a title=\"商城商品推荐\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">商城商品推荐</a></p>', '2014-11-06 15:20:47', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('20', '10', '如何管理店铺', null, '<p style=\"text-align: center;\"><a title=\"如何管理店铺\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">如何管理店铺</a></p>', '2014-11-06 15:20:58', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('21', '10', '如何发货', null, '<p style=\"text-align: center;\"><a title=\"如何发货\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">如何发货</a></p>', '2014-11-06 15:21:14', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('22', '11', '公司转账', null, '<p style=\"text-align: center;\"><a title=\"公司转账\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">公司转账</a></p>', '2014-11-06 15:21:27', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('23', '11', '在线支付', null, '<p style=\"text-align: center;\"><a title=\"在线支付\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">在线支付</a></p>', '2014-11-06 15:21:39', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('24', '11', '邮局汇款', null, '<p style=\"text-align: center;\"><a title=\"邮局汇款\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">邮局汇款</a></p>', '2014-11-06 15:21:49', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('25', '11', '如何注册支付宝', null, '<p style=\"text-align: center;\"><a title=\"如何注册支付宝\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">如何注册支付宝</a></p>', '2014-11-06 15:22:01', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('26', '12', '退换货流程', null, '<p style=\"text-align: center;\"><a title=\"退换货流程\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">退换货流程</a></p>', '2014-11-06 15:22:19', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('27', '12', '退款申请', null, '<p style=\"text-align: center;\"><a title=\"退款申请\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">退款申请</a></p>', '2014-11-06 15:22:33', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('28', '12', '退换货政策', null, '<p style=\"text-align: center;\"><a title=\"退换货政策\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">退换货政策</a></p>', '2014-11-06 15:22:45', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('29', '12', '联系卖家', null, '<p style=\"text-align: center;\"><a title=\"联系卖家\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">联系卖家</a></p>', '2014-11-06 15:23:00', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('30', '12', '返修/退换货', null, '<p style=\"text-align: center;\"><a title=\"返修/退换货\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">返修/退换货</a></p>', '2014-11-06 15:23:28', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('31', '13', '联系我们', null, '<p style=\"text-align: center;\"><a title=\"联系我们\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">联系我们</a></p>', '2014-11-06 15:24:25', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('32', '13', '合作及洽谈', null, '<p style=\"text-align: center;\"><a title=\"合作及洽谈\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">合作及洽谈</a></p>', '2014-11-06 15:24:37', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('33', '13', '关于Hishop', null, '<p style=\"text-align: center;\">关于Hishop</p>', '2014-11-06 15:25:05', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('34', '13', '招聘英才', null, '<p style=\"text-align: center;\"><a title=\"招聘英才\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">招聘英才</a></p>', '2014-11-06 15:25:16', '1', null, null, null, '1');



-- ----------------------------
-- Records of Himall_ImageAds
-- ----------------------------
INSERT INTO `Himall_ImageAds` VALUES ('1', '0', '/Storage/Plat/ImageAd/201411271922228999734.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('2', '0', '/Storage/Plat/ImageAd/201411271924231094774.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('3', '0', '/Storage/Plat/ImageAd/201411271924294978926.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('4', '0', '/Storage/Plat/ImageAd/201411271924378518505.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('5', '0', '/Storage/Plat/ImageAd/201411271926118702550.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('6', '0', '/Storage/Plat/ImageAd/201411271924581698733.png', '/');
INSERT INTO `Himall_ImageAds` VALUES ('7', '0', '/Storage/Plat/ImageAd/201411271925052044514.png', '/');
INSERT INTO `Himall_ImageAds` VALUES ('8', '0', '/Storage/Plat/ImageAd/201411271925115289451.png', '/');
INSERT INTO `Himall_ImageAds` VALUES ('9', '0', '/Storage/Plat/ImageAd/201411271925179346361.png', '/');
INSERT INTO `Himall_ImageAds` VALUES ('10', '0', '/Storage/Plat/ImageAd/201411051538294152167.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('11', '0', '/Storage/Plat/ImageAd/201411051538347344891.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('12', '0', '/Storage/Plat/ImageAd/201411051538401142128.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('13', '0', '/Storage/Plat/ImageAd/201411271923150932253.jpg', '/');



-- ----------------------------
-- Records of Himall_SiteSettings
-- ----------------------------
INSERT INTO `Himall_SiteSettings` VALUES ('1', 'Logo', '/Storage/Plat/ImageAd/logo.png');
INSERT INTO `Himall_SiteSettings` VALUES ('2', 'SiteName', '站点1号');
INSERT INTO `Himall_SiteSettings` VALUES ('3', 'ICPNubmer', ' ');
INSERT INTO `Himall_SiteSettings` VALUES ('4', 'CustomerTel', ' ');
INSERT INTO `Himall_SiteSettings` VALUES ('5', 'SiteIsOpen', 'False');
INSERT INTO `Himall_SiteSettings` VALUES ('6', 'Keyword', '手机');
INSERT INTO `Himall_SiteSettings` VALUES ('7', 'Hotkeywords', '男装,海飞丝,女装,ABC,手机,Nikon,包包,鞋子');
INSERT INTO `Himall_SiteSettings` VALUES ('8', 'PageFoot', ' ');
INSERT INTO `Himall_SiteSettings` VALUES ('9', 'UserCookieKey', 'd1b31e1b3176cf3aa8993428061c8af2');


-- ----------------------------
-- Records of Himall_ShopGrades
-- ----------------------------
INSERT INTO `Himall_ShopGrades` VALUES ('1', '白金店铺', '500', '500', '500', '500.00', null);
INSERT INTO `Himall_ShopGrades` VALUES ('2', '钻石店铺', '1000', '1000', '1000', '1000.00', null);


-- ----------------------------
-- Records of Himall_Shops
-- ----------------------------
INSERT INTO `Himall_Shops` VALUES ('1', '1', '官方自营店', null, null, null, '1', '6', null, '2014-10-30 00:00:00', '2014-12-12 00:00:00', '海商网络科技', '102', '文化大厦', '876588888', '1000', '1.00', '杨先生', '13988887748', 'Yang@hishop.com', '966587458', '1', '102', '2014-05-05 00:00:00', '2014-12-12 00:00:00', '1', '66548726', '1', '1', '杨先生', '6228445888796651200', '中国银行', '44698', '101', '1', '1', '33695', '1', '1', '1', '1', '1', '1', '11.00', '11.00', '5', '102', null, null, null, null, null);
