/*
Navicat MySQL Data Transfer

Source Server         : MySql
Source Server Version : 50623
Source Host           : 192.168.10.63:3306
Source Database       : TestInData

Target Server Type    : MYSQL
Target Server Version : 50623
File Encoding         : 65001

Date: 2015-06-08 13:45:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for Himall_AccountDetails
-- ----------------------------
DROP TABLE IF EXISTS `Himall_AccountDetails`;
CREATE TABLE `Himall_AccountDetails` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AccountId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `Date` datetime NOT NULL COMMENT '完成日期',
  `OrderDate` datetime NOT NULL,
  `OrderType` int(11) NOT NULL COMMENT '枚举 完成订单1，退订单0',
  `OrderId` bigint(20) NOT NULL,
  `ProductActualPaidAmount` decimal(8,2) NOT NULL COMMENT '商品实付总额',
  `FreightAmount` decimal(8,2) NOT NULL COMMENT '运费金额',
  `CommissionAmount` decimal(8,2) NOT NULL COMMENT '佣金',
  `RefundTotalAmount` decimal(8,2) NOT NULL COMMENT '退款金额',
  `RefundCommisAmount` decimal(8,2) NOT NULL COMMENT '退还佣金',
  `OrderRefundsDates` varchar(300) NOT NULL COMMENT '退单的日期集合以;分隔',
  PRIMARY KEY (`Id`),
  KEY `himall_accountdetails_ibfk_1` (`AccountId`) USING BTREE,
  CONSTRAINT `himall_accountdetails_ibfk_1` FOREIGN KEY (`AccountId`) REFERENCES `Himall_Accounts` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_AccountDetails
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_AccountMeta
-- ----------------------------
DROP TABLE IF EXISTS `Himall_AccountMeta`;
CREATE TABLE `Himall_AccountMeta` (
  `Id` bigint(20) NOT NULL,
  `AccountId` bigint(20) NOT NULL,
  `MetaKey` varchar(100) NOT NULL,
  `MetaValue` text NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_AccountMeta
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_AccountPurchaseAgreement
-- ----------------------------
DROP TABLE IF EXISTS `Himall_AccountPurchaseAgreement`;
CREATE TABLE `Himall_AccountPurchaseAgreement` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AccountId` bigint(20) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL,
  `Date` datetime NOT NULL,
  `PurchaseAgreementId` bigint(20) NOT NULL,
  `AdvancePayment` decimal(8,2) NOT NULL COMMENT '预付款金额',
  `FinishDate` datetime NOT NULL COMMENT '平台审核时间',
  `ApplyDate` datetime DEFAULT NULL COMMENT '申请',
  PRIMARY KEY (`Id`),
  KEY `AccountId` (`AccountId`) USING BTREE,
  CONSTRAINT `himall_accountpurchaseagreement_ibfk_1` FOREIGN KEY (`AccountId`) REFERENCES `Himall_Accounts` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='结算预付款';

-- ----------------------------
-- Records of Himall_AccountPurchaseAgreement
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_Accounts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Accounts`;
CREATE TABLE `Himall_Accounts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `AccountDate` datetime NOT NULL COMMENT '出账日期',
  `StartDate` datetime NOT NULL COMMENT '开始时间',
  `EndDate` datetime NOT NULL COMMENT '结束时间',
  `Status` int(11) NOT NULL COMMENT '枚举 0未结账，1已结账',
  `ProductActualPaidAmount` decimal(8,2) NOT NULL COMMENT '商品实付总额',
  `FreightAmount` decimal(8,2) NOT NULL COMMENT '运费',
  `CommissionAmount` decimal(8,2) NOT NULL COMMENT '佣金',
  `RefundCommissionAmount` decimal(8,2) NOT NULL COMMENT '退还佣金',
  `RefundAmount` decimal(8,2) NOT NULL COMMENT '退款金额',
  `AdvancePaymentAmount` decimal(8,2) NOT NULL COMMENT '预付款总额',
  `PeriodSettlement` decimal(8,2) NOT NULL COMMENT '本期应结',
  `Remark` text,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Accounts
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ActiveMarketService
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ActiveMarketService`;
CREATE TABLE `Himall_ActiveMarketService` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TypeId` int(11) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ActiveMarketService
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_Agreement
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Agreement`;
CREATE TABLE `Himall_Agreement` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AgreementType` int(4) NOT NULL COMMENT '协议类型 枚举 AgreementType：0买家注册协议，1卖家入驻协议',
  `AgreementContent` text NOT NULL COMMENT '协议内容',
  `LastUpdateTime` datetime DEFAULT NULL COMMENT '最后修改日期',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of Himall_Agreement
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ArticleCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ArticleCategories`;
CREATE TABLE `Himall_ArticleCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParentCategoryId` bigint(20) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `IsDefault` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ArticleCategories
-- ----------------------------
INSERT INTO `Himall_ArticleCategories` VALUES ('1', '0', '首页服务', '1', '1');
INSERT INTO `Himall_ArticleCategories` VALUES ('2', '0', '系统快报', '2', '1');
INSERT INTO `Himall_ArticleCategories` VALUES ('3', '0', '平台公告', '3', '1');
INSERT INTO `Himall_ArticleCategories` VALUES ('4', '0', '资讯中心', '4', '1');
INSERT INTO `Himall_ArticleCategories` VALUES ('9', '1', '购物指南', '1', '0');
INSERT INTO `Himall_ArticleCategories` VALUES ('10', '1', '店主之家', '1', '0');
INSERT INTO `Himall_ArticleCategories` VALUES ('11', '1', '支付方式', '1', '0');
INSERT INTO `Himall_ArticleCategories` VALUES ('12', '1', '售后服务', '1', '0');
INSERT INTO `Himall_ArticleCategories` VALUES ('13', '1', '关于我们', '1', '0');

-- ----------------------------
-- Table structure for Himall_Articles
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Articles`;
CREATE TABLE `Himall_Articles` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `CategoryId` bigint(20) NOT NULL DEFAULT '0',
  `Title` varchar(100) NOT NULL,
  `IconUrl` varchar(100) DEFAULT NULL,
  `Content` text NOT NULL,
  `AddDate` datetime NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `Meta_Title` text,
  `Meta_Description` text,
  `Meta_Keywords` text,
  `IsRelease` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_ArticleCategory_Article` (`CategoryId`) USING BTREE,
  CONSTRAINT `himall_articles_ibfk_1` FOREIGN KEY (`CategoryId`) REFERENCES `Himall_ArticleCategories` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Articles
-- ----------------------------
INSERT INTO `Himall_Articles` VALUES ('1', '2', '4K智能电视2599元起', null, '<p>4K智能电视2599元起</p>', '2014-09-24 15:32:58', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('2', '2', '9.9元起，品蟹品酒季', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"9.9元起，品蟹品酒季\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">9.9元起，品蟹品酒季</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:15', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('3', '2', '彩票2元，买了就抽奖！', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"彩票2元，买了就抽奖！\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">彩票2元，买了就抽奖！</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:26', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('4', '2', '秋季运动惠大牌低至5折', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"秋季运动惠大牌低至5折\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">秋季运动惠大牌低至5折</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:36', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('5', '2', '《好妈妈2》新书7折抢', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"《好妈妈2》新书7折抢\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">《好妈妈2》新书7折抢</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:45', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('6', '2', '秋季服装 五折封顶', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"秋季服装 五折封顶    \" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">秋季服装 五折封顶</a></p></li></ul><p><br/></p>', '2014-09-24 15:33:53', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('7', '2', '十一提前购 美孚299疯抢', null, '<ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><a target=\"_blank\" title=\"十一提前购 美孚299疯抢\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none;\">十一提前购 美孚299疯抢</a></p></li></ul><p><br/></p>', '2014-09-24 15:34:02', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('8', '2', '好蟹四免一', null, '<p><a target=\"_blank\" title=\"京东管控 好蟹四免一\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none; font-family: Arial, Verdana, 宋体; font-size: 12px; line-height: 25px; white-space: normal; background-color: rgb(255, 255, 255);\">好蟹四免一</a></p>', '2014-09-24 15:34:13', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('12', '3', '良良寝居满319减80 ', null, '<p>良良寝居满319减80 </p>', '2014-10-27 00:00:00', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('13', '9', '购物流程图', null, '<p><img alt=\"\" src=\"/Storage/Plat/Article/13/b116555e5f664e8ebeaebf8d783b4916.jpg\" style=\"margin: 10px; padding: 0px; vertical-align: middle; color: rgb(102, 102, 102); font-family: Arial, Verdana, 宋体; font-size: 12px; line-height: 18px; white-space: normal; background-color: rgb(255, 255, 255);\"/></p>', '2014-11-06 14:54:04', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('14', '9', '会员介绍', null, '<p style=\"text-align: center;\">会员介绍</p>', '2014-11-06 15:15:01', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('15', '9', '常见问题', null, '<p style=\"text-align: center;\"><a target=\"_blank\" rel=\"nofollow\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none; font-family: Arial, Verdana, 宋体; font-size: 12px; line-height: 20px; white-space: normal; background-color: rgb(255, 255, 255);\">常见问题</a></p>', '2014-11-06 15:15:17', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('16', '9', '联系客服', null, '<p style=\"text-align: center;\"><a target=\"_blank\" rel=\"nofollow\" style=\"margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none; font-family: Arial, Verdana, 宋体; font-size: 12px; line-height: 20px; white-space: normal; background-color: rgb(255, 255, 255);\">联系客服</a></p>', '2014-11-06 15:15:29', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('17', '10', '如何申请开店', null, '<p style=\"text-align: center;\"><a title=\"如何申请开店\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">如何申请开店</a></p>', '2014-11-06 15:17:26', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('18', '10', '查看售出商品', null, '<p style=\"text-align: center;\"><a title=\"查看售出商品\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">查看售出商品</a></p>', '2014-11-06 15:17:41', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('19', '10', '商城商品推荐', null, '<p style=\"text-align: center;\"><a title=\"商城商品推荐\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">商城商品推荐</a></p>', '2014-11-06 15:20:47', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('20', '10', '如何管理店铺', null, '<p style=\"text-align: center;\"><a title=\"如何管理店铺\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">如何管理店铺</a></p>', '2014-11-06 15:20:58', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('21', '10', '如何发货', null, '<p style=\"text-align: center;\"><a title=\"如何发货\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">如何发货</a></p>', '2014-11-06 15:21:14', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('22', '11', '公司转账', null, '<p style=\"text-align: center;\"><a title=\"公司转账\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">公司转账</a></p>', '2014-11-06 15:21:27', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('23', '11', '在线支付', null, '<p style=\"text-align: center;\"><a title=\"在线支付\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">在线支付</a></p>', '2014-11-06 15:21:39', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('24', '11', '邮局汇款', null, '<p style=\"text-align: center;\"><a title=\"邮局汇款\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">邮局汇款</a></p>', '2014-11-06 15:21:49', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('25', '11', '如何注册支付宝', null, '<p style=\"text-align: center;\"><a title=\"如何注册支付宝\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">如何注册支付宝</a></p>', '2014-11-06 15:22:01', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('26', '12', '退换货流程', null, '<p style=\"text-align: center;\"><a title=\"退换货流程\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">退换货流程</a></p>', '2014-11-06 15:22:19', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('27', '12', '退款申请', null, '<p style=\"text-align: center;\"><a title=\"退款申请\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">退款申请</a></p>', '2014-11-06 15:22:33', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('28', '12', '退换货政策', null, '<p style=\"text-align: center;\"><a title=\"退换货政策\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">退换货政策</a></p>', '2014-11-06 15:22:45', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('29', '12', '联系卖家', null, '<p style=\"text-align: center;\"><a title=\"联系卖家\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">联系卖家</a></p>', '2014-11-06 15:23:00', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('30', '12', '返修/退换货', null, '<p style=\"text-align: center;\"><a title=\"返修/退换货\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">返修/退换货</a></p>', '2014-11-06 15:23:28', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('31', '13', '联系我们', null, '<p style=\"text-align: center;\"><a title=\"联系我们\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">联系我们</a></p>', '2014-11-06 15:24:25', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('32', '13', '合作及洽谈', null, '<p style=\"text-align: center;\"><a title=\"合作及洽谈\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">合作及洽谈</a></p>', '2014-11-06 15:24:37', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('33', '13', '关于Hishop', null, '<p style=\"text-align: center;\">关于Hishop</p>', '2014-11-06 15:25:05', '1', null, null, null, '1');
INSERT INTO `Himall_Articles` VALUES ('34', '13', '招聘英才', null, '<p style=\"text-align: center;\"><a title=\"招聘英才\" style=\"color: rgb(51, 51, 51); text-decoration: none; outline: none medium; transition: color 0.3s ease; -webkit-transition: color 0.3s ease; font-family: &#39;microsoft yahei&#39;; line-height: 20px; background-color: rgb(250, 250, 250);\">招聘英才</a></p>', '2014-11-06 15:25:16', '1', null, null, null, '1');

-- ----------------------------
-- Table structure for Himall_Attributes
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Attributes`;
CREATE TABLE `Himall_Attributes` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TypeId` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `IsMust` tinyint(1) NOT NULL,
  `IsMulti` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Type_Attribute` (`TypeId`) USING BTREE,
  CONSTRAINT `himall_attributes_ibfk_1` FOREIGN KEY (`TypeId`) REFERENCES `Himall_Types` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Attributes
-- ----------------------------
INSERT INTO `Himall_Attributes` VALUES ('10', '1', '人群', '10', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('11', '1', '颜色', '11', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('12', '1', '尺寸', '12', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('17', '3', '尺码', '17', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('19', '4', '尺寸', '18', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('20', '4', '颜色', '19', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('21', '5', '价格', '20', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('22', '5', '人群', '21', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('23', '6', '类别', '22', '1', '0');
INSERT INTO `Himall_Attributes` VALUES ('24', '7', '类型', '23', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('25', '8', '型号', '24', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('26', '13', '套餐', '25', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('27', '13', '服务', '26', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('29', '12', '机身', '28', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('30', '12', '套餐类型', '29', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('31', '12', '服务', '30', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('32', '14', '颜色', '31', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('33', '15', '颜色', '32', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('34', '16', '颜色', '33', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('35', '17', '颜色', '34', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('36', '17', '尺寸', '35', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('37', '18', '颜色', '36', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('38', '18', '尺寸', '37', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('39', '19', '颜色', '38', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('40', '20', '颜色', '39', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('41', '20', '尺寸', '40', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('42', '21', '颜色', '41', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('43', '21', '尺寸', '42', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('44', '22', '尺寸', '43', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('45', '22', '颜色', '44', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('46', '3', '颜色', '45', '1', '1');
INSERT INTO `Himall_Attributes` VALUES ('48', '12', '屏幕大小', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('49', '12', '网络', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('50', '13', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('51', '6', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('52', '24', '质保', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('54', '25', '尺寸', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('55', '25', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('56', '25', '质保类型', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('57', '5', '花型', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('58', '26', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('59', '26', '材质', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('60', '26', '风格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('61', '27', '类别', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('62', '27', '材质', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('63', '27', '尺寸', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('64', '28', '规格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('65', '28', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('66', '28', '是否带盖', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('67', '21', '人群', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('69', '20', '风格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('70', '1', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('71', '29', '材质', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('72', '29', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('73', '9', '人群', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('75', '17', '风格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('76', '17', '风格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('77', '16', '材质', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('79', '30', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('80', '30', '用途分类', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('81', '30', '钟面形状', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('82', '31', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('83', '31', '款式', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('84', '31', '类型', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('85', '32', '尺码', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('86', '32', '适用人群', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('87', '32', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('88', '33', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('89', '33', '净重', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('90', '33', '车架材质', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('94', '35', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('95', '35', '类别', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('96', '35', '风格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('97', '36', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('98', '36', '类型', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('99', '36', '材质', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('100', '37', '价格', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('101', '37', '适宜年龄', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('102', '38', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('103', '38', '类型', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('104', '39', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('105', '39', '类型', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('106', '40', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('107', '40', '类型', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('108', '41', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('109', '41', '类别', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('110', '41', '国别', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('111', '42', '折扣', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('112', '42', '价格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('113', '9', '适用类型', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('114', '9', '功效类型', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('115', '9', '适合发质', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('116', '12', '大家说', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('117', '12', '系统', '0', '0', '0');
INSERT INTO `Himall_Attributes` VALUES ('118', '21', '风格', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('119', '21', '领型', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('120', '21', '主要材质', '0', '0', '1');
INSERT INTO `Himall_Attributes` VALUES ('121', '21', '版型', '0', '0', '1');

-- ----------------------------
-- Table structure for Himall_AttributeValues
-- ----------------------------
DROP TABLE IF EXISTS `Himall_AttributeValues`;
CREATE TABLE `Himall_AttributeValues` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `AttributeId` bigint(20) NOT NULL,
  `Value` varchar(100) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Attribute_AttributeValue` (`AttributeId`) USING BTREE,
  CONSTRAINT `himall_attributevalues_ibfk_1` FOREIGN KEY (`AttributeId`) REFERENCES `Himall_Attributes` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=726 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_AttributeValues
-- ----------------------------
INSERT INTO `Himall_AttributeValues` VALUES ('22', '12', '26预包邮', '22');
INSERT INTO `Himall_AttributeValues` VALUES ('23', '12', '27预包邮', '23');
INSERT INTO `Himall_AttributeValues` VALUES ('24', '12', '28预包邮', '24');
INSERT INTO `Himall_AttributeValues` VALUES ('25', '12', '29预包邮', '25');
INSERT INTO `Himall_AttributeValues` VALUES ('32', '17', 'S', '32');
INSERT INTO `Himall_AttributeValues` VALUES ('33', '17', 'M', '33');
INSERT INTO `Himall_AttributeValues` VALUES ('34', '17', 'L', '34');
INSERT INTO `Himall_AttributeValues` VALUES ('41', '19', '1.5m', '35');
INSERT INTO `Himall_AttributeValues` VALUES ('42', '19', '1.8m', '36');
INSERT INTO `Himall_AttributeValues` VALUES ('43', '20', '绽放异彩', '37');
INSERT INTO `Himall_AttributeValues` VALUES ('44', '20', '后青春', '38');
INSERT INTO `Himall_AttributeValues` VALUES ('45', '20', '美国派', '39');
INSERT INTO `Himall_AttributeValues` VALUES ('46', '20', '狂想曲', '40');
INSERT INTO `Himall_AttributeValues` VALUES ('47', '19', '1.2m', '41');
INSERT INTO `Himall_AttributeValues` VALUES ('48', '20', '红色', '42');
INSERT INTO `Himall_AttributeValues` VALUES ('49', '20', '花色', '43');
INSERT INTO `Himall_AttributeValues` VALUES ('58', '23', '社会', '51');
INSERT INTO `Himall_AttributeValues` VALUES ('60', '23', '历史', '53');
INSERT INTO `Himall_AttributeValues` VALUES ('63', '24', '欧美', '55');
INSERT INTO `Himall_AttributeValues` VALUES ('64', '24', '科普', '56');
INSERT INTO `Himall_AttributeValues` VALUES ('65', '24', '中国原创', '57');
INSERT INTO `Himall_AttributeValues` VALUES ('66', '25', '#13', '58');
INSERT INTO `Himall_AttributeValues` VALUES ('67', '25', '#21', '59');
INSERT INTO `Himall_AttributeValues` VALUES ('68', '25', '#23', '60');
INSERT INTO `Himall_AttributeValues` VALUES ('69', '25', '06#', '61');
INSERT INTO `Himall_AttributeValues` VALUES ('70', '25', '05#', '62');
INSERT INTO `Himall_AttributeValues` VALUES ('71', '25', '04#', '63');
INSERT INTO `Himall_AttributeValues` VALUES ('72', '25', '03#', '64');
INSERT INTO `Himall_AttributeValues` VALUES ('73', '25', '02#', '65');
INSERT INTO `Himall_AttributeValues` VALUES ('74', '25', '01#', '66');
INSERT INTO `Himall_AttributeValues` VALUES ('75', '26', '官方标配', '67');
INSERT INTO `Himall_AttributeValues` VALUES ('76', '26', '套餐一', '68');
INSERT INTO `Himall_AttributeValues` VALUES ('77', '26', '套餐二', '69');
INSERT INTO `Himall_AttributeValues` VALUES ('78', '27', '全国联保', '70');
INSERT INTO `Himall_AttributeValues` VALUES ('79', '27', '远程服务', '71');
INSERT INTO `Himall_AttributeValues` VALUES ('80', '31', '全国联保', '72');
INSERT INTO `Himall_AttributeValues` VALUES ('81', '31', '远程服务', '73');
INSERT INTO `Himall_AttributeValues` VALUES ('82', '30', '官方标配', '74');
INSERT INTO `Himall_AttributeValues` VALUES ('83', '29', '金色', '75');
INSERT INTO `Himall_AttributeValues` VALUES ('84', '29', '皓白色', '76');
INSERT INTO `Himall_AttributeValues` VALUES ('85', '29', '深灰色', '77');
INSERT INTO `Himall_AttributeValues` VALUES ('86', '29', '白色', '78');
INSERT INTO `Himall_AttributeValues` VALUES ('87', '29', '简约白', '79');
INSERT INTO `Himall_AttributeValues` VALUES ('88', '29', '炫酷黑', '80');
INSERT INTO `Himall_AttributeValues` VALUES ('89', '29', '地级黑', '81');
INSERT INTO `Himall_AttributeValues` VALUES ('90', '29', '冰川银', '82');
INSERT INTO `Himall_AttributeValues` VALUES ('91', '32', '浅蓝', '83');
INSERT INTO `Himall_AttributeValues` VALUES ('92', '32', '深蓝', '84');
INSERT INTO `Himall_AttributeValues` VALUES ('93', '32', '紫色', '85');
INSERT INTO `Himall_AttributeValues` VALUES ('94', '32', '黑色', '86');
INSERT INTO `Himall_AttributeValues` VALUES ('95', '32', '红色', '87');
INSERT INTO `Himall_AttributeValues` VALUES ('96', '32', '粉红色', '88');
INSERT INTO `Himall_AttributeValues` VALUES ('97', '32', '白色', '89');
INSERT INTO `Himall_AttributeValues` VALUES ('98', '33', '橙色', '90');
INSERT INTO `Himall_AttributeValues` VALUES ('99', '33', '棕色', '91');
INSERT INTO `Himall_AttributeValues` VALUES ('100', '33', '花色', '92');
INSERT INTO `Himall_AttributeValues` VALUES ('101', '33', '蓝色', '93');
INSERT INTO `Himall_AttributeValues` VALUES ('102', '34', '黑白色', '94');
INSERT INTO `Himall_AttributeValues` VALUES ('103', '34', '蓝玫色', '95');
INSERT INTO `Himall_AttributeValues` VALUES ('104', '34', '湖蓝色', '96');
INSERT INTO `Himall_AttributeValues` VALUES ('105', '34', '玫瑰红', '97');
INSERT INTO `Himall_AttributeValues` VALUES ('106', '34', '黄色', '98');
INSERT INTO `Himall_AttributeValues` VALUES ('107', '34', '黑玫红', '99');
INSERT INTO `Himall_AttributeValues` VALUES ('108', '34', '黑白色', '100');
INSERT INTO `Himall_AttributeValues` VALUES ('109', '35', '土黄色', '101');
INSERT INTO `Himall_AttributeValues` VALUES ('110', '35', '蓝色', '102');
INSERT INTO `Himall_AttributeValues` VALUES ('111', '35', '米色', '103');
INSERT INTO `Himall_AttributeValues` VALUES ('112', '36', '38', '104');
INSERT INTO `Himall_AttributeValues` VALUES ('113', '36', '39', '105');
INSERT INTO `Himall_AttributeValues` VALUES ('114', '36', '40', '106');
INSERT INTO `Himall_AttributeValues` VALUES ('115', '36', '41', '107');
INSERT INTO `Himall_AttributeValues` VALUES ('116', '37', '土色', '108');
INSERT INTO `Himall_AttributeValues` VALUES ('117', '37', '粉色', '109');
INSERT INTO `Himall_AttributeValues` VALUES ('118', '37', '金色', '110');
INSERT INTO `Himall_AttributeValues` VALUES ('119', '37', '红色', '111');
INSERT INTO `Himall_AttributeValues` VALUES ('120', '37', '黑色', '112');
INSERT INTO `Himall_AttributeValues` VALUES ('121', '37', '杏色', '113');
INSERT INTO `Himall_AttributeValues` VALUES ('122', '38', '35', '114');
INSERT INTO `Himall_AttributeValues` VALUES ('123', '38', '36', '115');
INSERT INTO `Himall_AttributeValues` VALUES ('124', '38', '37', '116');
INSERT INTO `Himall_AttributeValues` VALUES ('125', '38', '38', '117');
INSERT INTO `Himall_AttributeValues` VALUES ('126', '39', '天蓝色', '118');
INSERT INTO `Himall_AttributeValues` VALUES ('127', '39', '枚红色', '119');
INSERT INTO `Himall_AttributeValues` VALUES ('128', '39', '宝蓝色', '120');
INSERT INTO `Himall_AttributeValues` VALUES ('129', '39', '卡其色', '121');
INSERT INTO `Himall_AttributeValues` VALUES ('130', '39', '蝴蝶结', '122');
INSERT INTO `Himall_AttributeValues` VALUES ('131', '40', '蓝白', '123');
INSERT INTO `Himall_AttributeValues` VALUES ('132', '40', '红白', '124');
INSERT INTO `Himall_AttributeValues` VALUES ('133', '40', '黑白', '125');
INSERT INTO `Himall_AttributeValues` VALUES ('134', '40', '绿黑', '126');
INSERT INTO `Himall_AttributeValues` VALUES ('135', '40', '白紫', '127');
INSERT INTO `Himall_AttributeValues` VALUES ('136', '41', '120', '128');
INSERT INTO `Himall_AttributeValues` VALUES ('137', '41', '130', '129');
INSERT INTO `Himall_AttributeValues` VALUES ('138', '41', '140', '130');
INSERT INTO `Himall_AttributeValues` VALUES ('139', '41', '150', '131');
INSERT INTO `Himall_AttributeValues` VALUES ('140', '42', '卡其', '132');
INSERT INTO `Himall_AttributeValues` VALUES ('141', '42', '军绿', '133');
INSERT INTO `Himall_AttributeValues` VALUES ('142', '43', 'M', '134');
INSERT INTO `Himall_AttributeValues` VALUES ('143', '43', 'L', '135');
INSERT INTO `Himall_AttributeValues` VALUES ('144', '43', 'XL', '136');
INSERT INTO `Himall_AttributeValues` VALUES ('145', '43', 'XXL', '137');
INSERT INTO `Himall_AttributeValues` VALUES ('146', '44', '26', '138');
INSERT INTO `Himall_AttributeValues` VALUES ('147', '44', '27', '139');
INSERT INTO `Himall_AttributeValues` VALUES ('148', '44', '28', '140');
INSERT INTO `Himall_AttributeValues` VALUES ('149', '44', '29', '141');
INSERT INTO `Himall_AttributeValues` VALUES ('150', '45', '天蓝色', '142');
INSERT INTO `Himall_AttributeValues` VALUES ('151', '45', '深蓝色', '143');
INSERT INTO `Himall_AttributeValues` VALUES ('152', '46', '琥珀色', '144');
INSERT INTO `Himall_AttributeValues` VALUES ('153', '46', '白色', '145');
INSERT INTO `Himall_AttributeValues` VALUES ('154', '46', '绿色', '146');
INSERT INTO `Himall_AttributeValues` VALUES ('155', '46', '棕花色', '147');
INSERT INTO `Himall_AttributeValues` VALUES ('156', '35', '棕色', '148');
INSERT INTO `Himall_AttributeValues` VALUES ('157', '36', '37', '149');
INSERT INTO `Himall_AttributeValues` VALUES ('158', '36', '38', '150');
INSERT INTO `Himall_AttributeValues` VALUES ('159', '35', '白色', '151');
INSERT INTO `Himall_AttributeValues` VALUES ('160', '35', '黑色', '152');
INSERT INTO `Himall_AttributeValues` VALUES ('161', '35', '红色', '153');
INSERT INTO `Himall_AttributeValues` VALUES ('168', '48', '3.5-4.0英寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('169', '48', '4.0-4.5英寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('170', '48', '4.5-5.0英寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('171', '48', '5.0-6.0英寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('172', '49', '移动4G', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('173', '49', '联通4G', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('174', '49', '电信4G', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('175', '49', '移动3G', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('176', '49', '联通3G', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('177', '49', '电信3G', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('178', '50', '0-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('179', '50', '199-299', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('180', '50', '299-399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('181', '50', '399-599', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('182', '50', '600以上9', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('183', '23', '哲学', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('184', '23', '经济学', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('185', '23', '心理学', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('186', '23', '科技', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('187', '51', '0-19', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('188', '51', '19-39', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('189', '51', '39-59', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('190', '51', '59以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('191', '52', '一年', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('192', '52', '三年', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('193', '52', '二十年', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('194', '52', '终生质保', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('195', '54', '10.1寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('196', '54', '11寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('197', '54', '12寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('198', '54', '13寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('199', '54', '14寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('200', '54', '15.6寸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('201', '55', '500-999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('202', '55', '999-1999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('203', '55', '1999-2999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('204', '55', '2999-3999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('205', '55', '3999以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('206', '56', '本店质保', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('207', '56', '全国联保', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('208', '21', '0-99', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('209', '21', '99-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('210', '21', '199-299', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('211', '21', '299-499', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('212', '21', '499-599', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('213', '21', '599以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('214', '22', '女士', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('215', '22', '男士', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('216', '22', '儿童', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('217', '22', '亲子', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('218', '57', '心型', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('219', '57', '纯色', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('220', '57', '卡通', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('221', '57', '字母', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('222', '57', '格子', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('223', '57', '豹纹', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('224', '57', '条纹', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('225', '58', '0-1399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('226', '58', '1400-2299', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('227', '58', '2300-3399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('228', '58', '3400-4699', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('229', '58', '4699-6999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('230', '58', '6999以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('231', '59', '木质', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('232', '59', '布艺', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('233', '59', '实木', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('234', '59', '真皮', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('235', '59', '人造板', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('236', '59', '玻璃', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('237', '60', '现代简约', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('238', '60', '欧式古典', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('239', '60', '欧美式', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('240', '60', '中式现代', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('241', '60', '田园', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('242', '60', '韩式田园', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('243', '61', '地面砖', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('244', '61', '电源插座', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('245', '61', '墙面砖', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('246', '61', 'PVC墙纸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('247', '61', '马赛克', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('248', '62', '玻化砖', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('249', '62', '无纺布墙纸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('250', '62', '特种砖', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('251', '62', 'PVC墙纸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('252', '62', '植绒墙纸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('253', '63', '300*300', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('254', '63', '600*600', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('255', '63', '800*800', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('256', '64', '三件套', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('257', '64', '二件套', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('258', '64', '32cm', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('259', '64', '四件套', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('260', '64', '七件套', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('261', '64', '30cm', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('262', '65', '0-69', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('263', '65', '70-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('264', '65', '200-399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('265', '65', '400-699', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('266', '65', '700-1499', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('267', '66', '是', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('268', '66', '否', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('269', '42', '灰色', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('270', '42', '白色', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('271', '42', '黑色', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('272', '43', 'S', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('273', '67', '青年', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('274', '67', '青少年', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('275', '67', '中年', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('276', '67', '大码', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('277', '67', '老年', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('278', '67', '情侣装', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('279', '41', '160', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('280', '41', '170', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('281', '69', '日韩', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('282', '69', 'OL', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('283', '69', '淑女', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('284', '69', '休闲', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('285', '69', '欧美', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('286', '69', '甜美', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('287', '69', '性感', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('288', '69', '优雅', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('289', '10', '男式', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('290', '10', '女式', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('291', '10', '儿童', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('292', '10', '情侣', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('293', '11', '白', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('294', '11', '肉色', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('295', '11', '灰', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('296', '11', '黑', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('297', '11', '红', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('298', '11', '粉', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('299', '70', '0-39', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('300', '70', '39-59', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('301', '70', '59-99', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('302', '70', '99-129', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('303', '70', '130以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('304', '71', '银', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('305', '71', '金', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('306', '71', '白金', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('307', '71', '镶钻', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('308', '71', '玉石', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('309', '72', '0-1999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('310', '72', '1999-2999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('311', '72', '2999-3999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('312', '72', '4000以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('313', '73', '女士', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('314', '73', '男士', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('315', '73', '任何人群', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('316', '75', '欧美', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('317', '75', '英伦', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('318', '75', '韩版', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('319', '75', '百搭', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('320', '75', '休闲', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('321', '75', '甜美', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('322', '75', '简约', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('323', '77', 'ABS&PC', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('324', '77', 'ABS', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('325', '77', '牛津布', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('326', '77', 'PC涤纶', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('327', '77', '尼龙', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('328', '77', 'PU', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('329', '77', '其它', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('330', '79', '0-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('331', '79', '200-399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('332', '79', '400-699', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('333', '79', '700-1599', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('334', '79', '1600-6899', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('335', '79', '6900以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('336', '80', '挂钟', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('337', '80', '闹钟', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('338', '80', '座钟', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('339', '80', '立式钟', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('340', '80', '电子钟', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('341', '80', '其他计时工具', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('342', '81', '圆形', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('343', '81', '方形', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('344', '81', '其他', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('345', '82', '0-499', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('346', '82', '500-899', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('347', '82', '900-1499', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('348', '82', '1500-2499', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('349', '82', '2500-3999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('350', '82', '4000-6999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('351', '82', '7000以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('352', '83', 'T恤', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('353', '83', '外套', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('354', '83', '裤子', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('355', '83', '衬衫', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('356', '83', '针织', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('357', '83', '内衣裤', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('358', '83', '休闲时尚', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('359', '83', '商务休闲', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('360', '84', '板扣', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('361', '84', '针扣', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('362', '85', 'XXS', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('363', '85', 'XS', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('364', '85', 'S', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('365', '85', 'M', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('366', '85', 'L', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('367', '85', 'XL', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('368', '86', '儿童', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('369', '86', '男士', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('370', '86', '情侣', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('371', '86', '女士', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('372', '86', '中性', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('373', '87', '0-59', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('374', '87', '60-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('375', '87', '200-399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('376', '87', '400-699', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('377', '87', '700-1099', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('378', '87', '1100以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('379', '88', '0-599', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('380', '88', '600-899', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('381', '88', '900-1199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('382', '88', '1200-1499', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('383', '88', '1500-3399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('384', '88', '3400以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('385', '89', '10KG以下', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('386', '89', '10-15KG', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('387', '89', '15-20KG', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('388', '89', '20KG以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('389', '90', '铝合金', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('390', '90', '高碳钢', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('391', '90', '铁架', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('392', '90', '铬钼钢', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('393', '90', '其它', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('409', '94', '0-39', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('410', '94', '40-79', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('411', '94', '80-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('412', '94', '200-399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('413', '94', '400-599', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('414', '94', '600以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('415', '95', '方向盘套', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('416', '95', '车载支架/挂钩/托盘', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('417', '95', '车掸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('418', '95', '毛巾', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('419', '95', '档把套', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('420', '95', '遮阳档/雪挡', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('421', '96', '卡通', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('422', '96', '商务', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('423', '96', '运动', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('424', '96', '其他', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('425', '97', '0-39', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('426', '97', '40-79', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('427', '97', '80-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('428', '97', '200-399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('429', '97', '400以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('430', '98', '早教机', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('431', '98', '启蒙玩具', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('432', '98', '宝宝纪念品', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('433', '99', '纯棉', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('434', '99', '玻璃', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('435', '99', '硅胶', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('436', '99', 'pp', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('437', '99', 'ppsu', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('438', '99', '不锈钢', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('439', '99', '竹纤维/莫代尔', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('440', '99', 'PES', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('441', '99', '其他', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('442', '100', '0-39', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('443', '100', '40-79', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('444', '100', '80-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('445', '100', '200-399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('446', '100', '400以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('447', '101', '0-1岁', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('448', '101', '1-2岁', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('449', '101', '2-3岁', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('450', '101', '3-4岁', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('451', '101', '4-5岁', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('452', '101', '5岁以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('453', '102', '0-29', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('454', '102', '30-59', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('455', '102', '60-89', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('456', '102', '90-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('457', '102', '200-299', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('458', '102', '300以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('459', '103', '饮料', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('460', '103', '进口零食', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('461', '103', '米面杂粮', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('462', '104', '0-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('463', '104', '200-499', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('464', '104', '500-899', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('465', '104', '900-1699', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('466', '104', '1700-3999', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('467', '104', '4000-7399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('468', '104', '7400以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('469', '105', '红酒', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('470', '105', '白酒', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('471', '105', '啤酒', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('472', '105', '黄酒', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('473', '106', '0-39', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('474', '106', '40-79', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('475', '106', '80-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('476', '106', '200-399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('477', '106', '400-499', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('478', '106', '500以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('479', '107', '海鲜', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('480', '107', '水果', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('481', '107', '牛肉', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('482', '107', '虾', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('483', '107', '羊肉', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('484', '108', '0-89', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('485', '108', '90-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('486', '108', '200-399', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('487', '108', '400-699', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('488', '108', '700-1099', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('489', '108', '1100以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('490', '109', 'B族', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('491', '109', '维生素C', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('492', '109', '维生素E', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('493', '109', '复合维生素', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('494', '109', '矿物质', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('495', '109', '其他', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('496', '110', '国产', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('497', '110', '进口', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('498', '111', '0-3折', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('499', '111', '3-5折', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('500', '111', '5-7折', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('501', '111', '7折及以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('502', '112', '0-79', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('503', '112', '80-199', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('504', '112', '200-299', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('505', '112', '300-499', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('506', '112', '500-1699', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('507', '112', '1700以上', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('508', '113', '日用型', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('509', '113', '夜用型', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('510', '114', '深层净化', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('511', '114', '秋冬滋润', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('512', '114', '劲能套餐', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('513', '114', '型男霜', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('514', '114', '控油套餐', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('515', '115', '干性', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('516', '115', '中性', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('517', '115', '油性', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('518', '115', '混合性', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('519', '115', '受损发质', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('520', '30', '心动4G版', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('521', '30', '4G增强版', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('522', '30', 'WIFI增强版', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('523', '31', '上门维修', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('524', '31', 'VIP专线', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('525', '31', '免费返厂', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('526', '31', 'JFGT计划专服务', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('527', '48', '3.0英寸及以下', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('528', '49', '移动2G/联通2G', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('529', '49', '双卡', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('530', '116', '屏幕大', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('531', '116', '待机时间长', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('532', '116', '电池耐用', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('533', '116', '照相不错', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('534', '116', '反应快', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('535', '116', '外观不错', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('536', '116', '系统流畅', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('537', '116', '字体大', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('538', '116', '后盖很漂亮', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('539', '116', '软件也不错', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('540', '116', '功能齐全', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('541', '116', '分辨率高', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('542', '117', '安卓（Android）', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('543', '117', '微软（WindowsPhone）', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('544', '117', '苹果（IOS）', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('545', '117', '其它', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('546', '43', 'XXS', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('547', '43', 'XS', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('548', '43', '3XL', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('549', '43', '4XL', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('550', '43', '5XL', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('551', '43', '6XL', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('552', '43', '7XL', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('553', '43', '8XL', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('554', '43', '10', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('555', '43', '11', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('556', '118', '青春休闲', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('557', '118', '商务休闲', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('558', '118', '时尚休闲', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('559', '118', '日韩风格', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('560', '118', '商务正装', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('561', '118', '欧美简约', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('562', '118', '军旅工装', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('563', '118', '嘻哈风格', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('564', '118', '英式学院', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('565', '119', '立领', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('566', '119', '圆领', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('567', '119', 'V领', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('568', '119', '方领', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('569', '119', '尖领', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('570', '119', '翻领', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('571', '119', '连帽可脱卸', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('572', '119', '帽扣领', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('573', '119', '撞色领', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('574', '119', '高领', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('575', '120', '棉', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('576', '120', '羊毛', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('577', '120', '涤纶', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('578', '120', '羊绒', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('579', '120', '锦纶', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('580', '120', '蚕丝', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('581', '120', '腈纶', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('582', '120', '麻', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('583', '120', '兔毛', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('584', '120', 'LYCRA莱卡', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('585', '120', '莫代尔', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('586', '120', '马海毛', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('587', '121', '修身型', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('588', '121', '标准型', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('589', '121', '（腰围=胸围）', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('590', '121', '宽松型（腰围>胸围）', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('591', '121', '宽松型(腰围>胸围)', '1');
INSERT INTO `Himall_AttributeValues` VALUES ('592', '103', '坚果', '1');

-- ----------------------------
-- Table structure for Himall_Banners
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Banners`;
CREATE TABLE `Himall_Banners` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Position` int(11) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `Url` varchar(1000) NOT NULL,
  `Platform` int(11) NOT NULL DEFAULT '0',
  `UrlType` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Banners
-- ----------------------------
INSERT INTO `Himall_Banners` VALUES ('12', '0', '服装', '0', '1', '/', '0', '0');
INSERT INTO `Himall_Banners` VALUES ('13', '0', '手机', '0', '2', '/', '0', '0');
INSERT INTO `Himall_Banners` VALUES ('14', '0', '日化护理', '0', '3', '/', '0', '0');
INSERT INTO `Himall_Banners` VALUES ('16', '0', '数码配件', '0', '4', '/', '0', '0');
INSERT INTO `Himall_Banners` VALUES ('17', '0', '新品首发', '0', '5', '/', '0', '0');

-- ----------------------------
-- Table structure for Himall_Brands
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Brands`;
CREATE TABLE `Himall_Brands` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `Logo` varchar(1000) DEFAULT NULL,
  `RewriteName` varchar(50) DEFAULT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `Meta_Title` varchar(1000) DEFAULT NULL,
  `Meta_Description` varchar(1000) DEFAULT NULL,
  `Meta_Keywords` varchar(1000) DEFAULT NULL,
  `IsRecommend` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Brands
-- ----------------------------
INSERT INTO `Himall_Brands` VALUES ('1', 'Test', '0', '/Storage/Plat/Brand/logo_1.jpg', null, '1', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('3', '诺基亚', '0', '/Storage/Plat/Brand/logo_3.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('4', 'TCL', '0', '/Storage/Plat/Brand/logo_4.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('5', '飞科', '0', '/Storage/Plat/Brand/logo_5.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('6', '创维', '0', '/Storage/Plat/Brand/logo_6.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('7', '九阳', '0', '/Storage/Plat/Brand/logo_7.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('8', '长虹', '0', '/Storage/Plat/Brand/logo_8.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('9', '康佳', '0', '/Storage/Plat/Brand/logo_9.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('10', 'LG', '0', '/Storage/Plat/Brand/logo_10.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('11', '努比亚', '0', '/Storage/Plat/Brand/logo_11.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('12', '海尔', '0', '/Storage/Plat/Brand/logo_12.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('13', '英特尔', '0', '/Storage/Plat/Brand/logo_13.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('14', '佳能', '0', '/Storage/Plat/Brand/logo_14.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('15', '微软', '0', '/Storage/Plat/Brand/logo_15.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('16', '宏碁', '0', '/Storage/Plat/Brand/logo_16.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('17', '齐心办公', '0', '/Storage/Plat/Brand/logo_17.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('18', '神舟', '0', '/Storage/Plat/Brand/logo_18.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('19', 'Thinkpad', '0', '/Storage/Plat/Brand/logo_19.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('20', '得力办公', '0', '/Storage/Plat/Brand/logo_20.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('21', '惠普', '0', '/Storage/Plat/Brand/logo_21.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('22', '清华同方', '0', '/Storage/Plat/Brand/logo_22.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('23', 'HKC', '0', '/Storage/Plat/Brand/logo_23.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('24', 'AOC', '0', '/Storage/Plat/Brand/logo_24.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('25', 'TP-LINK', '0', '/Storage/Plat/Brand/logo_25.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('26', '海尔', '0', '/Storage/Plat/Brand/logo_26.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('27', '罗技', '0', '/Storage/Plat/Brand/logo_27.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('28', '天威', '0', '/Storage/Plat/Brand/logo_28.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('29', '海澜之家', '0', '/Storage/Plat/Brand/logo_29.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('30', '爱慕', '0', '/Storage/Plat/Brand/logo_30.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('31', 'GXG', '0', '/Storage/Plat/Brand/logo_31.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('32', 'mango', '0', '/Storage/Plat/Brand/logo_32.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('33', 'ELLE', '0', '/Storage/Plat/Brand/logo_33.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('34', '百丽', '0', '/Storage/Plat/Brand/logo_34.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('35', '探路者', '0', '/Storage/Plat/Brand/logo_35.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('36', '丝界', '0', '/Storage/Plat/Brand/logo_36.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('37', 'KENZO', '0', '/Storage/Plat/Brand/logo_37.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('38', '万里马', '0', '/Storage/Plat/Brand/logo_38.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('39', '兰芝', '0', '/Storage/Plat/Brand/logo_39.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('40', '天梭', '0', '/Storage/Plat/Brand/logo_40.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('41', '飞亚达', '0', '/Storage/Plat/Brand/logo_41.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('42', '丝蓓绮', '0', '/Storage/Plat/Brand/logo_42.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('43', '日百', '0', '/Storage/Plat/Brand/logo_43.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('44', '欧莱雅', '0', '/Storage/Plat/Brand/logo_44.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('45', '千寻海风', '0', '/Storage/Plat/Brand/logo_45.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('46', '莱百首饰', '0', '/Storage/Plat/Brand/logo_46.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('47', '谢瑞麟', '0', '/Storage/Plat/Brand/logo_47.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('48', '潮宏基', '0', '/Storage/Plat/Brand/logo_48.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('49', '罗莱家纺', '0', '/Storage/Plat/Brand/logo_49.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('50', '爱仕达', '0', '/Storage/Plat/Brand/logo_50.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('51', '拉歌蒂尼', '0', '/Storage/Plat/Brand/logo_51.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('52', '美国康宁', '0', '/Storage/Plat/Brand/logo_52.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('53', '滴露', '0', '/Storage/Plat/Brand/logo_53.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('54', '好事达', '0', '/Storage/Plat/Brand/logo_54.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('55', 'GLY', '0', '/Storage/Plat/Brand/logo_55.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('56', '光明家具', '0', '/Storage/Plat/Brand/logo_56.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('57', '宝优妮', '0', '/Storage/Plat/Brand/logo_57.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('58', '水星家纺', '0', '/Storage/Plat/Brand/logo_58.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('59', '惠氏', '0', '/Storage/Plat/Brand/logo_59.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('60', '帮宝适', '0', '/Storage/Plat/Brand/logo_60.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('61', '乐儿宝', '0', '/Storage/Plat/Brand/logo_61.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('62', '合生元', '0', '/Storage/Plat/Brand/logo_62.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('63', '路途乐', '0', '/Storage/Plat/Brand/logo_63.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('64', '好奇', '0', '/Storage/Plat/Brand/logo_64.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('65', '孕之彩', '0', '/Storage/Plat/Brand/logo_65.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('66', 'New Balance kids', '0', '/Storage/Plat/Brand/logo_66.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('67', '南极人', '0', '/Storage/Plat/Brand/logo_67.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('68', '红孩儿', '0', '/Storage/Plat/Brand/logo_68.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('69', '百草味', '0', '/Storage/Plat/Brand/logo_69.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('70', '五粮液', '0', '/Storage/Plat/Brand/logo_70.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('71', '贵州馆', '0', '/Storage/Plat/Brand/logo_71.gif', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('72', '庄民', '0', '/Storage/Plat/Brand/logo_72.gif', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('73', '拉菲', '0', '/Storage/Plat/Brand/logo_73.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('74', '日百', '0', '/Storage/Plat/Brand/logo_74.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('75', '汇源', '0', '/Storage/Plat/Brand/logo_75.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('76', '洋河', '0', '/Storage/Plat/Brand/logo_76.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('77', '顺丰', '0', '/Storage/Plat/Brand/logo_77.gif', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('78', '马莎', '0', '/Storage/Plat/Brand/logo_78.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('79', '111', '0', '/Storage/Plat/Brand/logo_79.jpg', null, '111', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('80', 'iPhone', '0', '/Storage/Plat/Brand/logo_80.jpg', null, '苹果\r\n', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('82', '老人头', '0', '/Storage/Plat/Brand/logo_82.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('83', '浪美', '0', '/Storage/Plat/Brand/logo_83.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('84', '雪曼', '0', '/Storage/Plat/Brand/logo_84.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('85', '茜茜', '0', '/Storage/Plat/Brand/logo_85.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('86', '朗芙丝', '0', '/Storage/Plat/Brand/logo_86.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('87', '千百惠', '0', '/Storage/Plat/Brand/logo_87.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('90', '欧莱雅', '0', '/Storage/Plat/Brand/logo_90.png', null, '法国欧莱雅集团是世界上最大的化妆品公司，创办于1907年。\r\n欧莱雅集团世界美妆品行业中的的领导者，经营范围遍及130多个国家和地区，在全球拥有283家分公司、42家工厂、100多个代理商，以及5万多名的员工，是总部设于法国旳跨国公司，也是财富全球500强企业之一。', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('92', '海飞丝', '0', '/Storage/Plat/Brand/logo_92.png', null, '海飞丝去屑洗发露清爽去油型500mlX2 ', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('93', '苹果', '0', '/Storage/Plat/Brand/logo_93.jpg', null, null, null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('95', '潘婷', '0', '/Storage/Plat/Brand/logo_95.png', null, '潘婷乳液修复洗发水750ml*2瓶深层修复滋润洗发露套装', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('96', '多芬', '0', '/Storage/Plat/Brand/logo_96.jpg', null, '全新多芬，比牛奶更滋润。', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('98', '舒肤佳', '0', '/Storage/Plat/Brand/logo_98.jpg', null, '专业保护健康全家', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('99', '飘柔', '0', '/Storage/Plat/Brand/logo_99.png', null, '飘柔滋润去屑洗发水/露700mlX2 去屑', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('101', '力士', '0', '/Storage/Plat/Brand/logo_101.jpg', null, '幽莲魅肤力士，精油香氛沐浴露。', null, null, null, '1');
INSERT INTO `Himall_Brands` VALUES ('104', '拉芳', '0', '/Storage/Plat/Brand/logo_104.png', null, '水疗素护发素柔顺发膜 倒膜套装染烫受损修复毛躁', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('106', '欧莱雅', '0', '/Storage/Plat/Brand/logo_106.png', null, '精油润养3x润发乳400ml 蜕变 防毛躁 滋养护发素', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('107', '多芬', '0', '/Storage/Plat/Brand/logo_107.png', null, '深度损伤洗发水', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('109', '玉兰油', '0', '/Storage/Plat/Brand/logo_109.png', null, 'Olay是一款全球领导护肤品牌，60年来倍受全球女性信任挚爱。Olay一直坚持深入聆听女性需求，并通过将尖端护肤科技注入产品以满足女性日新月异的护肤需求。Olay以卓越的产品品质成为广大女性的美丽标志，为全球超过八千万女性带来健康美丽的肌肤。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('111', '资生堂', '0', '/Storage/Plat/Brand/logo_111.png', null, '去屑无硅油洗发露护发素', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('112', '华为', '0', '/Storage/Plat/Brand/logo_112.jpg', null, null, null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('113', '沙宣', '0', '/Storage/Plat/Brand/logo_113.png', null, ' 垂坠质感洗发水+护发素 弹性轻盈保湿顺滑', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('115', '韩伊', '0', '/Storage/Plat/Brand/logo_115.png', null, 'coe韩伊Olive橄榄营养洗发水护发素套装男女士洗发水', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('116', '纳美牙刷', '0', '/Storage/Plat/Brand/logo_116.png', null, '纳美纳米抗菌牙刷软毛牙刷', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('117', '黑人牙刷', '0', '/Storage/Plat/Brand/logo_117.png', null, '黑人牙膏套装超白', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('118', '水之密语', '0', '/Storage/Plat/Brand/logo_118.jpg', null, '温和洗净，祛除油脂污垢，深锁肌肤水分，持久滋润，让肌肤保持自然清爽！', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('119', '郁美净', '0', '/Storage/Plat/Brand/logo_119.png', null, '郁美净人坚持优质产品的标准起步要高，郁美净儿童系列护肤品，如郁美净儿童霜、高级儿童霜、儿童营养霜、儿童营养保湿霜等都采用了国际标准，并取得了采用国际标准产品标志证书，产品水平认定为国际先进水平。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('120', '三星', '0', '/Storage/Plat/Brand/logo_120.jpg', null, null, null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('121', '高露洁', '0', '/Storage/Plat/Brand/logo_121.png', null, '高露洁三重深洁波浪牙刷（有效清洁牙缝）', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('122', '李施德林', '0', '/Storage/Plat/Brand/logo_122.png', null, '李施德林漱口水', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('123', 'ora2皓乐齿', '0', '/Storage/Plat/Brand/logo_123.png', null, 'ora2皓乐齿0酒精漱口水 去除牙龈出血口臭口气牙渍 日本进口', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('124', '袋鼠妈妈', '0', '/Storage/Plat/Brand/logo_124.jpg', null, '袋鼠妈妈孕妇专用护肤品，坏境中生长有机原料有机植物和有机植被以及大豆里面提取的精华研制而成的。适合准妈妈们食用 非转基因小麦成分，为准妈妈带来更好的福音', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('125', '护舒宝', '0', '/Storage/Plat/Brand/logo_125.png', null, '护舒宝卫生巾', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('126', 'ABC卫生巾', '0', '/Storage/Plat/Brand/logo_126.png', null, 'ABC卫生巾', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('127', '安尔乐', '0', '/Storage/Plat/Brand/logo_127.jpg', null, '安尔乐护垫', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('128', '高洁丝', '0', '/Storage/Plat/Brand/logo_128.png', null, '高洁丝卫生巾', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('129', '妇炎洁', '0', '/Storage/Plat/Brand/logo_129.png', null, '妇炎洁洗液', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('131', '七度空间', '0', '/Storage/Plat/Brand/logo_131.jpg', null, '七度空间护垫', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('132', 'LION狮王', '0', '/Storage/Plat/Brand/logo_132.gif', null, 'LION狮王日本进口CLINICA酵素洁净牙膏', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('133', '苏菲', '0', '/Storage/Plat/Brand/logo_133.jpg', null, '苏菲卫生巾', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('134', '娇妍', '0', '/Storage/Plat/Brand/logo_134.png', null, '娇妍私处护理液', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('135', '洁尔阴', '0', '/Storage/Plat/Brand/logo_135.png', null, '洁尔阴洗液', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('136', '迪彩', '0', '/Storage/Plat/Brand/logo_136.png', null, '发剂 植物遮白发 黑色棕黑棕色酒红紫红全套工具染发膏', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('137', '威娜', '0', '/Storage/Plat/Brand/logo_137.png', null, '正品威娜可丽丝倍佳染发膏60g 染膏染发剂送双氧染黑发', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('138', '凡士林', '0', '/Storage/Plat/Brand/logo_138.jpg', null, '凡士林是vaseline的译音，一种油脂状的石油产品。白色至黄棕色允许有矿物油气味，而不允许有煤油气味。滴点约37-54度。是由石油的残油经硫酸和白土精制而得，也可以由固体石腊烃和矿物润滑油调制而成。凡士林的化学成分长链烷烃。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('139', '老人头', '0', '/Storage/Plat/Brand/logo_139.png', null, '老人头五倍子泡沫染发剂纯植物染发梳染发膏染发笔染发棒黑色', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('140', '佰草集', '0', '/Storage/Plat/Brand/logo_140.jpg', null, '佰草集,美自根源,养有方,中国第一个完整意义上的现代中草药个人护理品牌。为您提供肌本理护、专意理护、香怡理护、品颜理护等美肤产品。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('141', '香奈儿', '0', '/Storage/Plat/Brand/logo_141.jpg', null, '香奈儿（CHANEL)），是由Gabrielle Chanel于1913年在法国巴黎创立的品牌，至今已有百年历史。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('142', '海蓝之谜', '0', '/Storage/Plat/Brand/logo_142.jpg', null, 'LA MER海蓝之谜，中国唯一官方网站，全球高端奢华护肤品牌，从具深层滋养保湿能量的深海巨藻中萃取神奇活性精萃，拥有强大修复再生功效。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('143', '福安康', '0', '/Storage/Plat/Brand/logo_143.jpg', null, '福安康秉承“弘扬敬老助残传统美德，发展老残病人用品事业”的宗旨，积极倡导老残病人护理新概念，积极推动敬老助残事业的发展，在做大、做强“福安康” 品牌的辛勤努力下，从最初的直营店经营发展为现在的连锁经营，经营品种由几十个发展到现在的六大类十二大系列、数千个品种，涵盖了老年人、残疾人、病人康复、保健护理、治疗、健身、娱乐、休闲的各个方面。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('144', '曼秀雷敦', '0', '/Storage/Plat/Brand/logo_144.jpg', null, '曼秀雷敦自1889年创立以来,分支机构遍布全球多个国家。1991年,曼秀雷敦(中国)药业有限公司在广东省中山市成立,其先进的生产设备、严谨的生产标准及专业的销售团队。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('145', '柏莱雅', '0', '/Storage/Plat/Brand/logo_145.jpg', null, '柏莱雅化妆品', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('146', '美帕', '0', '/Storage/Plat/Brand/logo_146.png', null, 'MedSPA的产品由法国顶级联合医学实验室出品，其实验室为全球最前沿皮肤诊所及抗衰老中心、著名护肤品牌商而定制小众产品。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('147', 'HTC', '0', '/Storage/Plat/Brand/logo_147.jpg', null, null, null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('148', '御泥坊', '0', '/Storage/Plat/Brand/logo_148.png', null, '御泥坊，相传在滩头，这个有着1500年历史的湘西边陲小镇，古代的居民们一直保留着一种奇特的“祭泥仪式”。 清光绪年间，以这种神秘泥块为原料生产的护肤品颇受妇女欢迎，成为宫中养颜圣品，被封为“御泥”。御泥坊通过网络口碑相传，已成为中国泥浆面膜第一品牌', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('149', '松下', '0', '/Storage/Plat/Brand/logo_149.png', null, '松下电器始终秉承着“通过生产、销售活动，改善并提高社会生活，为世界文化的发展做贡献”的经营理念，潜心研发了Econavi节能导航与nanoe纳米水离子两项先进技术，致力于为中国消费者提供最新的冰箱、电视机、4K数码相机、空气净化器在内的高品质电器产品。 ', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('150', '高丝', '0', '/Storage/Plat/Brand/logo_150.png', null, '高丝（日语：コーセー），是日本一家以化妆品制造与贩售为主的企业，初期以代理其他美容化妆品牌为主，1948年开始发展自己的品牌，由创办者小林孝三郎结合化学与药学人士于1946年创立。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('151', '春笑', '0', '/Storage/Plat/Brand/logo_151.png', null, '春天般的微笑', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('152', '仟草佰露 ', '0', '/Storage/Plat/Brand/logo_152.png', null, '仟草佰露严选最纯净的有机植物与芳香精油、结合传统医疗的古老智慧，呈现了最天然、最完整的植物商品。以合理、生活化的价格分享给大家，让精油产品唾手可得。', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('153', '金士顿', '0', '/Storage/Plat/Brand/logo_153.jpg', null, null, null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('154', '小米', '0', '/Storage/Plat/Brand/logo_154.png', null, '小米科技', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('155', '美特斯邦威', '0', '/Storage/Plat/Brand/logo_155.png', null, '美特斯邦威', null, null, null, '0');
INSERT INTO `Himall_Brands` VALUES ('156', '三只松鼠', '0', '/Storage/Plat/Brand/logo_156.png', null, '三只松鼠', null, null, null, '0');

-- ----------------------------
-- Table structure for Himall_BrowsingHistory
-- ----------------------------
DROP TABLE IF EXISTS `Himall_BrowsingHistory`;
CREATE TABLE `Himall_BrowsingHistory` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MemberId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `BrowseTime` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_BrowsingHistory_Himall_BrowsingHistory` (`MemberId`) USING BTREE,
  KEY `FK_Himall_BrowsingHistory_Himall_Products` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_browsinghistory_ibfk_1` FOREIGN KEY (`MemberId`) REFERENCES `Himall_Members` (`Id`),
  CONSTRAINT `himall_browsinghistory_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1302 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_BrowsingHistory
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_BusinessCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_BusinessCategories`;
CREATE TABLE `Himall_BusinessCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `CategoryId` bigint(20) NOT NULL,
  `CommisRate` decimal(8,2) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Category_BusinessCategory` (`CategoryId`) USING BTREE,
  CONSTRAINT `himall_businesscategories_ibfk_1` FOREIGN KEY (`CategoryId`) REFERENCES `Himall_Categories` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1540 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_BusinessCategories
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_CashDeposit
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CashDeposit`;
CREATE TABLE `Himall_CashDeposit` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ShopId` bigint(20) NOT NULL COMMENT 'Shop表外键',
  `CurrentBalance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '可用金额',
  `TotalBalance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '已缴纳金额',
  `Date` datetime DEFAULT NULL COMMENT '最后一次缴纳时间',
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_CashDeposit_Himall_Shops` (`ShopId`) USING BTREE,
  CONSTRAINT `Himall_cashdeposit_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of Himall_CashDeposit
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_CashDepositDetail
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CashDepositDetail`;
CREATE TABLE `Himall_CashDepositDetail` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `CashDepositId` bigint(20) NOT NULL DEFAULT '0',
  `AddDate` datetime NOT NULL,
  `Balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Operator` varchar(50) NOT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `RechargeWay` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `KF_Himall_CashDeposit_Himall_CashDepositDetail` (`CashDepositId`) USING BTREE,
  CONSTRAINT `Himall_cashdepositdetail_ibfk_1` FOREIGN KEY (`CashDepositId`) REFERENCES `Himall_CashDeposit` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of Himall_CashDepositDetail
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_Categories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Categories`;
CREATE TABLE `Himall_Categories` (
  `Id` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Icon` varchar(1000) DEFAULT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `ParentCategoryId` bigint(20) NOT NULL,
  `Depth` int(11) NOT NULL,
  `Path` varchar(100) NOT NULL,
  `RewriteName` varchar(50) DEFAULT NULL,
  `HasChildren` tinyint(1) NOT NULL,
  `TypeId` bigint(20) NOT NULL DEFAULT '0',
  `CommisRate` decimal(8,2) NOT NULL,
  `Meta_Title` varchar(1000) DEFAULT NULL,
  `Meta_Description` varchar(1000) DEFAULT NULL,
  `Meta_Keywords` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Type_Category` (`TypeId`) USING BTREE,
  CONSTRAINT `himall_categories_ibfk_1` FOREIGN KEY (`TypeId`) REFERENCES `Himall_Types` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Categories
-- ----------------------------
INSERT INTO `Himall_Categories` VALUES ('1', '图书', '/Storage/Plat/Category/201411280221592666310.jpg', '1', '0', '1', '1', null, '1', '6', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('2', '电子书', null, '1', '1', '2', '1|2', null, '1', '6', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('3', '文学', null, '2', '1', '2', '1|3', null, '1', '6', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('4', '少儿', null, '3', '1', '2', '1|4', null, '1', '6', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('5', '音像', null, '2', '0', '1', '5', null, '1', '42', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('6', '教育音像', null, '1', '5', '2', '5|6', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('7', '数字音乐', null, '2', '5', '2', '5|7', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('8', '影视', null, '3', '5', '2', '5|8', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('9', '数字商品', null, '3', '0', '1', '9', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('10', '数字音乐', null, '1', '9', '2', '9|10', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('11', '网络原创', null, '2', '9', '2', '9|11', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('13', '家用电器', null, '5', '0', '1', '13', null, '1', '24', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('14', '大家电', null, '1', '13', '2', '13|14', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('15', '数字杂志', null, '3', '9', '2', '9|15', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('16', '生活电器', null, '2', '13', '2', '13|16', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('17', '手机', null, '6', '0', '1', '17', null, '1', '12', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('18', '手机通讯', null, '1', '17', '2', '17|18', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('19', '合约机', null, '2', '17', '2', '17|19', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('20', '数码', null, '7', '0', '1', '20', null, '1', '13', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('21', '数码配件', null, '1', '20', '2', '20|21', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('22', '时尚影音', null, '2', '20', '2', '20|22', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('23', '电脑', null, '8', '0', '1', '23', null, '1', '25', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('24', '电脑整机', null, '1', '23', '2', '23|24', null, '1', '25', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('25', '电脑配件', null, '2', '23', '2', '23|25', null, '1', '25', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('26', '办公', null, '9', '0', '1', '26', null, '1', '25', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('27', '办公文仪', null, '1', '26', '2', '26|27', null, '1', '25', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('28', '服务产品', null, '2', '26', '2', '26|28', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('29', '小说', null, '1', '2', '3', '1|2|29', null, '0', '6', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('30', '多媒体图书', null, '2', '2', '3', '1|2|30', null, '0', '6', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('33', '数字杂志', null, '3', '2', '3', '1|2|33', null, '0', '6', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('34', '诗歌词曲', null, '1', '3', '3', '1|3|34', null, '0', '6', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('35', '世界名著', null, '2', '3', '3', '1|3|35', null, '0', '6', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('36', '名家作品', null, '3', '3', '3', '1|3|36', null, '0', '6', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('38', '动漫/卡通', null, '1', '4', '3', '1|4|38', null, '0', '6', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('39', '少儿英语', null, '2', '4', '3', '1|4|39', null, '0', '6', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('40', '学前启蒙', null, '1', '6', '3', '5|6|40', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('41', '英语学习', null, '2', '6', '3', '5|6|41', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('42', '电脑培训', null, '3', '6', '3', '5|6|42', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('43', '明星周边', null, '1', '7', '3', '5|7|43', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('44', '欧美流行', null, '2', '7', '3', '5|7|44', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('45', '古典', null, '3', '7', '3', '5|7|45', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('46', '影视周边', null, '1', '8', '3', '5|8|46', null, '0', '1', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('47', '电视剧', null, '2', '8', '3', '5|8|47', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('48', '流行音乐', null, '1', '10', '3', '9|10|48', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('49', '爵士蓝调', null, '2', '10', '3', '9|10|49', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('50', '言情', null, '1', '11', '3', '9|11|50', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('51', '生活/家庭', null, '1', '15', '3', '9|15|51', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('52', '空调', null, '1', '14', '3', '13|14|52', null, '0', '24', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('53', '取暖电器', null, '1', '16', '3', '13|16|53', null, '0', '24', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('54', '净化器', null, '2', '16', '3', '13|16|54', null, '0', '24', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('55', '720高清', null, '1', '18', '3', '17|18|55', null, '0', '12', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('56', '拍照神器', null, '2', '18', '3', '17|18|56', null, '0', '12', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('57', '双卡手机', null, '3', '18', '3', '17|18|57', null, '0', '12', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('58', '中国联通', null, '1', '19', '3', '17|19|58', null, '0', '12', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('59', '中国移动', null, '2', '19', '3', '17|19|59', null, '0', '12', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('60', '存储卡', null, '1', '21', '3', '20|21|60', null, '0', '13', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('61', ' 读卡器', null, '2', '21', '3', '20|21|61', null, '0', '13', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('62', '苹果周边', null, '1', '22', '3', '20|22|62', null, '0', '13', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('63', ' 蓝牙音箱', null, '2', '22', '3', '20|22|63', null, '0', '13', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('64', '笔记本', null, '1', '24', '3', '23|24|64', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('65', '超极本', null, '2', '24', '3', '23|24|65', null, '0', '25', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('66', 'CPU', null, '1', '25', '3', '23|25|66', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('67', '显卡', null, '2', '25', '3', '23|25|67', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('68', '学生文具', null, '1', '27', '3', '26|27|68', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('69', '文件管理', null, '2', '27', '3', '26|27|69', null, '0', '25', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('70', '上门服务', null, '1', '28', '3', '26|28|70', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('71', '远程服务', null, '2', '28', '3', '26|28|71', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('73', '儿童教育', null, '3', '4', '3', '1|4|73', null, '0', '6', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('75', '教育', null, '4', '1', '2', '1|75', null, '1', '6', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('76', '人文社科', null, '5', '1', '2', '1|76', null, '1', '6', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('77', '外语学习', null, '1', '75', '3', '1|75|77', null, '0', '6', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('78', '考试', null, '2', '75', '3', '1|75|78', null, '0', '6', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('79', '教材', null, '3', '75', '3', '1|75|79', null, '0', '6', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('80', '社会科学', null, '1', '76', '3', '1|76|80', null, '0', '6', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('81', '法律', null, '2', '76', '3', '1|76|81', null, '0', '6', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('82', '历史', null, '3', '76', '3', '1|76|82', null, '0', '6', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('83', '亲子幼教', null, '3', '8', '3', '5|8|83', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('84', '有声读物', null, '4', '9', '2', '9|84', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('85', '世界音乐', null, '3', '10', '3', '9|10|85', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('86', '都市生活', null, '2', '11', '3', '9|11|86', null, '0', '1', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('87', '玄幻奇幻', null, '3', '11', '3', '9|11|87', null, '0', '1', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('88', '娱乐/时尚', null, '2', '15', '3', '9|15|88', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('89', '经管理财', null, '3', '15', '3', '9|15|89', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('90', '百家讲坛', null, '1', '84', '3', '9|84|90', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('91', '评书', null, '2', '84', '3', '9|84|91', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('92', '历史录音', null, '3', '84', '3', '9|84|92', null, '0', '1', '5.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('93', '厨房电器', null, '3', '13', '2', '13|93', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('94', '个护健康', null, '4', '13', '2', '13|94', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('95', '五金家装', null, '5', '13', '2', '13|95', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('96', '平板电视', null, '2', '14', '3', '13|14|96', null, '0', '24', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('97', '冰箱', null, '3', '14', '3', '13|14|97', null, '0', '24', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('98', '吸尘器', null, '3', '16', '3', '13|16|98', null, '0', '24', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('99', '榨汁机', null, '1', '93', '3', '13|93|99', null, '0', '24', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('100', '电压力锅', null, '2', '93', '3', '13|93|100', null, '0', '24', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('101', '电饭煲', null, '3', '93', '3', '13|93|101', null, '0', '24', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('102', '口腔护理', null, '1', '94', '3', '13|94|102', null, '0', '24', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('103', '剃须刀', null, '2', '94', '3', '13|94|103', null, '0', '24', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('104', '电吹风', null, '3', '94', '3', '13|94|104', null, '0', '24', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('105', 'LED灯', null, '1', '95', '3', '13|95|105', null, '0', '24', '5.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('106', '电动工具', null, '2', '95', '3', '13|95|106', null, '0', '24', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('107', '排气扇', null, '3', '95', '3', '13|95|107', null, '0', '24', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('108', '手机配件', null, '3', '17', '2', '17|108', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('109', '手机预售', null, '4', '17', '2', '17|109', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('110', '新机首发', null, '5', '17', '2', '17|110', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('111', '全部手机', null, '4', '18', '3', '17|18|111', null, '0', '12', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('112', '中国电信', null, '3', '19', '3', '17|19|112', null, '0', '12', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('113', '电池', null, '1', '108', '3', '17|108|113', null, '0', '12', '5.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('114', '蓝牙耳机', null, '2', '108', '3', '17|108|114', null, '0', '12', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('115', '移动电源', null, '3', '108', '3', '17|108|115', null, '0', '12', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('116', 'iPhone6', null, '1', '109', '3', '17|109|116', null, '0', '12', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('117', '华为mate7', null, '2', '109', '3', '17|109|117', null, '0', '12', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('118', 'iphone 6plus', null, '3', '109', '3', '17|109|118', null, '0', '12', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('119', '荣耀 6 ', null, '1', '110', '3', '17|110|119', null, '0', '12', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('120', '三星note4', null, '2', '110', '3', '17|110|120', null, '0', '12', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('121', ' 摄影摄像', null, '3', '20', '2', '20|121', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('122', '智能设备', null, '4', '20', '2', '20|122', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('123', '电子教育', null, '5', '20', '2', '20|123', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('124', ' 滤镜', null, '3', '21', '3', '20|21|124', null, '0', '13', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('125', '蓝牙耳机 ', null, '3', '22', '3', '20|22|125', null, '0', '13', '5.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('126', '数码相机 ', null, '1', '121', '3', '20|121|126', null, '0', '13', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('127', '微单相机', null, '2', '121', '3', '20|121|127', null, '0', '13', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('128', ' 单反相机', null, '3', '121', '3', '20|121|128', null, '0', '13', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('129', '智能手环', null, '1', '122', '3', '20|122|129', null, '0', '12', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('130', ' 智能手表', null, '2', '122', '3', '20|122|130', null, '0', '13', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('131', '运动跟踪器', null, '3', '122', '3', '20|122|131', null, '0', '13', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('132', '学生平板', null, '1', '123', '3', '20|123|132', null, '0', '13', '5.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('133', ' 早教机', null, '2', '123', '3', '20|123|133', null, '0', '13', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('134', ' 故事机 ', null, '3', '123', '3', '20|123|134', null, '0', '13', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('135', '外设产品', null, '3', '23', '2', '23|135', null, '1', '25', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('136', '网络产品', null, '4', '23', '2', '23|136', null, '1', '25', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('137', '平板电脑', null, '3', '24', '3', '23|24|137', null, '0', '25', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('138', '主板', null, '3', '25', '3', '23|25|138', null, '0', '25', '5.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('139', '路由器', null, '1', '135', '3', '23|135|139', null, '0', '25', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('140', 'U盘', null, '2', '135', '3', '23|135|140', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('141', '鼠标', null, '3', '135', '3', '23|135|141', null, '0', '25', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('142', '网卡', null, '1', '136', '3', '23|136|142', null, '0', '25', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('143', '交换机', null, '2', '136', '3', '23|136|143', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('144', '3G上网', null, '3', '136', '3', '23|136|144', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('145', '办公打印', null, '3', '26', '2', '26|145', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('146', '办公文具', null, '3', '27', '3', '26|27|146', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('147', '打印机', null, '1', '145', '3', '26|145|147', null, '0', '25', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('148', '一体机', null, '2', '145', '3', '26|145|148', null, '0', '25', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('149', '投影机', null, '3', '145', '3', '26|145|149', null, '0', '25', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('150', '营养保健', null, '9', '0', '1', '150', null, '1', '41', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('151', '电脑软件', null, '3', '28', '3', '26|28|151', null, '0', '25', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('152', '家居', null, '10', '0', '1', '152', null, '1', '5', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('153', '家纺', null, '1', '152', '2', '152|153', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('154', '清洁用品', null, '2', '152', '2', '152|154', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('155', '生活日用', null, '3', '152', '2', '152|155', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('156', '灯具用品', null, '4', '152', '2', '152|156', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('157', '床品套件', null, '1', '153', '3', '152|153|157', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('158', '蚊帐', null, '2', '153', '3', '152|153|158', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('159', '凉席', null, '3', '153', '3', '152|153|159', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('160', '被子', null, '4', '153', '3', '152|153|160', null, '0', '5', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('161', '纸品湿巾', null, '1', '154', '3', '152|154|161', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('162', '衣物清洁', null, '2', '154', '3', '152|154|162', null, '0', '5', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('163', '家装软饰', null, '5', '152', '2', '152|163', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('164', '驱虫用品', null, '3', '154', '3', '152|154|164', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('165', '营养健康', null, '1', '150', '2', '150|165', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('166', '收纳用品', null, '1', '155', '3', '152|155|166', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('167', '雨伞雨具', null, '2', '155', '3', '152|155|167', null, '0', '5', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('168', '营养成分', null, '2', '150', '2', '150|168', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('169', '传统滋补', null, '3', '150', '2', '150|169', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('170', '浴室用品', null, '3', '155', '3', '152|155|170', null, '0', '5', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('171', '缝纫针织', null, '4', '155', '3', '152|155|171', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('172', '成人用品', null, '4', '150', '2', '150|172', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('173', '台灯', null, '1', '156', '3', '152|156|173', null, '0', '5', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('174', '保健器械', null, '5', '150', '2', '150|174', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('175', '节能灯', null, '2', '156', '3', '152|156|175', null, '0', '5', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('176', 'LED灯', null, '3', '156', '3', '152|156|176', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('177', '调节免疫', null, '1', '165', '3', '150|165|177', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('178', '调节三高', null, '2', '165', '3', '150|165|178', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('179', '缓解疲劳', null, '3', '165', '3', '150|165|179', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('180', '肠胃养护', null, '4', '165', '3', '150|165|180', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('181', '照片墙', null, '1', '163', '3', '152|163|181', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('182', '地毯地垫', null, '2', '163', '3', '152|163|182', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('183', '明目益智', null, '5', '165', '3', '150|165|183', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('184', '装饰字画', null, '3', '163', '3', '152|163|184', null, '0', '5', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('185', '蛋白质', null, '1', '168', '3', '150|168|185', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('186', '家具', null, '11', '0', '1', '186', null, '1', '26', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('187', '左旋肉碱', null, '2', '168', '3', '150|168|187', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('188', '卧室家具', null, '1', '186', '2', '186|188', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('189', '客厅家具', null, '2', '186', '2', '186|189', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('190', '葡萄籽', null, '3', '168', '3', '150|168|190', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('191', '餐厅家具', null, '3', '186', '2', '186|191', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('192', '书房家具', null, '4', '186', '2', '186|192', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('193', '胶原蛋白', null, '4', '168', '3', '150|168|193', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('194', '储物家具', null, '5', '186', '2', '186|194', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('195', '芦荟提取', null, '5', '168', '3', '150|168|195', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('196', '床', null, '1', '188', '3', '186|188|196', null, '0', '26', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('197', '阿胶', null, '1', '169', '3', '150|169|197', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('198', '床垫', null, '2', '188', '3', '186|188|198', null, '0', '26', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('199', '参类', null, '2', '169', '3', '150|169|199', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('200', '床头柜', null, '3', '188', '3', '186|188|200', null, '0', '26', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('201', '冬虫夏草', null, '3', '169', '3', '150|169|201', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('202', '衣柜', null, '4', '188', '3', '186|188|202', null, '0', '26', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('203', '燕窝', null, '4', '169', '3', '150|169|203', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('204', '沙发', null, '1', '189', '3', '186|189|204', null, '0', '26', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('205', '灵芝', null, '5', '169', '3', '150|169|205', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('206', '电视柜', null, '2', '189', '3', '186|189|206', null, '0', '26', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('207', '安全避孕', null, '1', '172', '3', '150|172|207', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('208', '床边桌', null, '3', '189', '3', '186|189|208', null, '0', '26', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('209', '验孕测孕', null, '2', '172', '3', '150|172|209', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('210', '人体润滑', null, '3', '172', '3', '150|172|210', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('211', '餐桌', null, '1', '191', '3', '186|191|211', null, '0', '26', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('212', '情爱玩具', null, '4', '172', '3', '150|172|212', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('213', '餐边柜', null, '2', '191', '3', '186|191|213', null, '0', '26', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('214', '情趣内衣', null, '5', '172', '3', '150|172|214', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('215', '餐椅', null, '3', '191', '3', '186|191|215', null, '0', '26', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('216', '电脑椅', null, '1', '192', '3', '186|192|216', null, '0', '26', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('217', '电脑桌', null, '2', '192', '3', '186|192|217', null, '0', '26', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('218', '血压仪器', null, '1', '174', '3', '150|174|218', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('219', '书柜/书架', null, '3', '192', '3', '186|192|219', null, '0', '26', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('220', '血糖用品', null, '2', '174', '3', '150|174|220', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('221', '衣帽鞋架', null, '1', '194', '3', '186|194|221', null, '0', '26', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('222', '储物收纳', null, '2', '194', '3', '186|194|222', null, '0', '26', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('223', '置物架', null, '3', '194', '3', '186|194|223', null, '0', '26', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('224', '家装', null, '12', '0', '1', '224', null, '1', '27', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('225', '养生器械', null, '3', '174', '3', '150|174|225', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('226', '灯饰照明', null, '1', '224', '2', '224|226', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('227', '康复辅助', null, '4', '174', '3', '150|174|227', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('228', '厨房卫浴', null, '2', '224', '2', '224|228', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('229', '五金工具', null, '3', '224', '2', '224|229', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('230', '电工电料', null, '4', '224', '2', '224|230', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('231', '呼吸制氧', null, '5', '174', '3', '150|174|231', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('232', '墙地面材料', null, '5', '224', '2', '224|232', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('233', '吸顶灯', null, '1', '226', '3', '224|226|233', null, '0', '27', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('234', '食品饮料', null, '13', '0', '1', '234', null, '1', '38', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('235', '台灯', null, '2', '226', '3', '224|226|235', null, '0', '27', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('236', '进口食品', null, '1', '234', '2', '234|236', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('237', '筒灯', null, '3', '226', '3', '224|226|237', null, '0', '27', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('238', '休闲食品', null, '2', '234', '2', '234|238', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('239', '射灯', null, '4', '226', '3', '224|226|239', null, '0', '27', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('240', '地方特产', null, '3', '234', '2', '234|240', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('241', '淋浴花洒', null, '1', '228', '3', '224|228|241', null, '0', '27', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('242', '茗茶', null, '4', '234', '2', '234|242', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('243', '厨卫', null, '2', '228', '3', '224|228|243', null, '0', '27', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('244', '饮料冲调', null, '5', '234', '2', '234|244', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('245', '挂件龙头', null, '3', '228', '3', '224|228|245', null, '0', '27', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('246', '牛奶', null, '1', '236', '3', '234|236|246', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('247', '锁具', null, '1', '229', '3', '224|229|247', null, '0', '27', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('248', '饼干蛋糕', null, '2', '236', '3', '234|236|248', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('249', '手动工具', null, '2', '229', '3', '224|229|249', null, '0', '27', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('250', '巧克力', null, '3', '236', '3', '234|236|250', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('251', '电动工具', null, '3', '229', '3', '224|229|251', null, '0', '27', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('252', '休闲零食', null, '4', '236', '3', '234|236|252', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('253', '开关插座', null, '1', '230', '3', '224|230|253', null, '0', '27', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('254', '冲调饮品', null, '5', '236', '3', '234|236|254', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('255', '休闲零食', null, '1', '238', '3', '234|238|255', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('256', '智能家居', null, '2', '230', '3', '224|230|256', null, '0', '27', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('257', '坚果炒货', null, '2', '238', '3', '234|238|257', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('258', '配电箱', null, '3', '230', '3', '224|230|258', null, '0', '27', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('259', '油漆/涂料', null, '1', '232', '3', '224|232|259', null, '0', '27', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('260', '壁纸', null, '2', '232', '3', '224|232|260', null, '0', '27', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('261', '肉干肉脯', null, '3', '238', '3', '234|238|261', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('262', '瓷砖', null, '3', '232', '3', '224|232|262', null, '0', '27', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('263', '蜜饯果干', null, '4', '238', '3', '234|238|263', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('264', '厨具', null, '14', '0', '1', '264', null, '1', '28', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('265', '无糖食品', null, '5', '238', '3', '234|238|265', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('266', '烹饪锅具', null, '1', '264', '2', '264|266', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('267', '新疆', null, '1', '240', '3', '234|240|267', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('268', '厨房配件', null, '2', '264', '2', '264|268', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('269', '餐  具', null, '3', '264', '2', '264|269', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('270', '四川', null, '2', '240', '3', '234|240|270', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('271', '水具酒具', null, '4', '264', '2', '264|271', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('272', '云南', null, '3', '240', '3', '234|240|272', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('273', '咖啡具', null, '5', '264', '2', '264|273', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('274', '湖南', null, '4', '240', '3', '234|240|274', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('275', '内蒙', null, '5', '240', '3', '234|240|275', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('276', '炒锅', null, '1', '266', '3', '264|266|276', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('277', '铁观音', null, '1', '242', '3', '234|242|277', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('278', '煎锅', null, '2', '266', '3', '264|266|278', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('279', '普洱', null, '2', '242', '3', '234|242|279', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('280', '压力锅', null, '3', '266', '3', '264|266|280', null, '0', '28', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('281', '蒸锅', null, '4', '266', '3', '264|266|281', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('282', '龙井', null, '3', '242', '3', '234|242|282', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('283', '绿茶', null, '4', '242', '3', '234|242|283', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('284', '乌龙茶', null, '5', '242', '3', '234|242|284', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('285', '保鲜用品', null, '1', '268', '3', '264|268|285', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('286', '牛奶乳品', null, '1', '244', '3', '234|244|286', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('287', '饭盒/提锅', null, '2', '268', '3', '264|268|287', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('288', '饮料', null, '2', '244', '3', '234|244|288', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('289', '厨房工具', null, '3', '268', '3', '264|268|289', null, '0', '28', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('290', '饮用水', null, '3', '244', '3', '234|244|290', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('291', '咖啡', null, '4', '244', '3', '234|244|291', null, '0', '38', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('292', '餐具套装', null, '1', '269', '3', '264|269|292', null, '0', '28', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('293', '蜂蜜柚子茶', null, '5', '244', '3', '234|244|293', null, '0', '41', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('294', '碗/碟', null, '2', '269', '3', '264|269|294', null, '0', '28', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('295', '酒类', null, '15', '0', '1', '295', null, '1', '39', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('296', '筷勺/刀叉', null, '3', '269', '3', '264|269|296', null, '0', '28', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('297', '中外名酒', null, '1', '295', '2', '295|297', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('298', '葡萄酒', null, '1', '297', '3', '295|297|298', null, '0', '39', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('299', '塑料杯', null, '1', '271', '3', '264|271|299', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('300', '白酒', null, '2', '297', '3', '295|297|300', null, '0', '39', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('301', '运动水杯', null, '2', '271', '3', '264|271|301', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('302', '洋酒', null, '3', '297', '3', '295|297|302', null, '0', '39', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('303', '玻璃杯', null, '3', '271', '3', '264|271|303', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('304', '啤酒', null, '4', '297', '3', '295|297|304', null, '0', '39', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('305', '保温杯', null, '4', '271', '3', '264|271|305', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('306', '整套茶具', null, '1', '273', '3', '264|273|306', null, '0', '28', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('307', '黄酒', null, '5', '297', '3', '295|297|307', null, '0', '39', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('308', '茶杯', null, '2', '273', '3', '264|273|308', null, '0', '28', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('309', '生鲜', null, '16', '0', '1', '309', null, '1', '40', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('310', '茶壶', null, '3', '273', '3', '264|273|310', null, '0', '28', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('311', '生鲜食品', null, '1', '309', '2', '309|311', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('312', '男装', null, '17', '0', '1', '312', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('313', '食品礼券', null, '2', '309', '2', '309|313', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('314', '当季流行', null, '1', '312', '2', '312|314', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('315', '水果蔬菜', null, '1', '311', '3', '309|311|315', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('316', '上装', null, '2', '312', '2', '312|316', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('317', '海鲜水产', null, '2', '311', '3', '309|311|317', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('318', '下装', null, '3', '312', '2', '312|318', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('319', '海参', null, '3', '311', '3', '309|311|319', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('320', '特色', null, '4', '312', '2', '312|320', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('321', '牛排', null, '4', '311', '3', '309|311|321', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('322', '热销品牌', null, '5', '312', '2', '312|322', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('323', '纯色羽绒', null, '1', '314', '3', '312|314|323', null, '0', '21', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('324', '帅气牛仔', null, '2', '314', '3', '312|314|324', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('325', '潮流棉服', null, '3', '314', '3', '312|314|325', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('326', '熟食腊味', null, '5', '311', '3', '309|311|326', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('327', '羽绒服', null, '1', '316', '3', '312|316|327', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('328', '大闸蟹', null, '1', '313', '3', '309|313|328', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('329', '粽子', null, '2', '313', '3', '309|313|329', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('330', '夹克', null, '2', '316', '3', '312|316|330', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('331', '衬衫', null, '3', '316', '3', '312|316|331', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('332', '月饼', null, '3', '313', '3', '309|313|332', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('334', '牛仔裤', null, '1', '318', '3', '312|318|334', null, '0', '21', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('335', '卡券', null, '5', '313', '3', '309|313|335', null, '0', '40', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('336', '休闲裤', null, '2', '318', '3', '312|318|336', null, '0', '21', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('337', '西裤', null, '3', '318', '3', '312|318|337', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('338', '母婴', null, '18', '0', '1', '338', null, '1', '36', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('339', '华菲型格', null, '1', '320', '3', '312|320|339', null, '0', '21', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('340', '奶粉', null, '1', '338', '2', '338|340', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('341', '营养辅食', null, '2', '338', '2', '338|341', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('342', '品立', null, '2', '320', '3', '312|320|342', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('343', '花笙记', null, '3', '320', '3', '312|320|343', null, '0', '21', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('344', '尿裤湿巾', null, '3', '338', '2', '338|344', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('345', '洗护用品', null, '4', '338', '2', '338|345', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('346', '劲霸', null, '1', '322', '3', '312|322|346', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('347', '喂养用品', null, '5', '338', '2', '338|347', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('348', '海澜之家', null, '2', '322', '3', '312|322|348', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('349', '婴幼奶粉', null, '1', '340', '3', '338|340|349', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('350', '马克华菲', null, '3', '322', '3', '312|322|350', null, '0', '21', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('351', '成人奶粉', null, '2', '340', '3', '338|340|351', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('352', '女装', null, '19', '0', '1', '352', null, '1', '20', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('353', '最热推荐', null, '1', '352', '2', '352|353', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('354', 'DHA', null, '1', '341', '3', '338|341|354', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('355', '热门类目', null, '2', '352', '2', '352|355', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('356', '大牌精选', null, '3', '352', '2', '352|356', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('357', '哥弟针织衫', null, '1', '353', '3', '352|353|357', null, '0', '20', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('358', '钙铁锌', null, '2', '341', '3', '338|341|358', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('359', '益生菌', null, '3', '341', '3', '338|341|359', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('360', '冬季连衣裙', null, '2', '353', '3', '352|353|360', null, '0', '20', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('361', '加绒裤', null, '3', '353', '3', '352|353|361', null, '0', '20', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('362', '宝宝零食', null, '4', '341', '3', '338|341|362', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('363', '果汁', null, '5', '341', '3', '338|341|363', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('364', '新品连衣裙', null, '1', '355', '3', '352|355|364', null, '0', '20', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('367', '婴儿尿裤', null, '1', '344', '3', '338|344|367', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('368', '针织衫', null, '2', '355', '3', '352|355|368', null, '0', '20', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('369', '拉拉裤', null, '2', '344', '3', '338|344|369', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('370', '毛呢大衣', null, '3', '355', '3', '352|355|370', null, '0', '20', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('371', '成人尿裤', null, '3', '344', '3', '338|344|371', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('372', '湿巾', null, '4', '344', '3', '338|344|372', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('373', '鄂尔多斯', null, '1', '356', '3', '352|356|373', null, '0', '20', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('374', '欧时力', null, '2', '356', '3', '352|356|374', null, '0', '20', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('375', '宝宝护肤', null, '1', '345', '3', '338|345|375', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('376', 'ONLY', null, '3', '356', '3', '352|356|376', null, '0', '20', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('377', '宝宝洗浴', null, '2', '345', '3', '338|345|377', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('378', '内衣', null, '20', '0', '1', '378', null, '1', '1', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('379', '洗衣液', null, '3', '345', '3', '338|345|379', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('380', '当季流行', null, '1', '378', '2', '378|380', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('381', '热门分类', null, '2', '378', '2', '378|381', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('382', '热门品牌', null, '3', '378', '2', '378|382', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('383', '理发器', null, '4', '345', '3', '338|345|383', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('384', '保暖速递', null, '1', '380', '3', '378|380|384', null, '0', '1', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('385', '聚拢文胸', null, '2', '380', '3', '378|380|385', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('386', '奶瓶清洗', null, '5', '345', '3', '338|345|386', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('387', '纯棉睡衣', null, '3', '380', '3', '378|380|387', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('388', '奶瓶奶嘴', null, '1', '347', '3', '338|347|388', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('389', '保暖内衣', null, '1', '381', '3', '378|381|389', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('390', '吸奶器', null, '2', '347', '3', '338|347|390', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('391', '文胸', null, '2', '381', '3', '378|381|391', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('392', '打底裤袜', null, '3', '381', '3', '378|381|392', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('393', '牙胶安抚', null, '3', '347', '3', '338|347|393', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('394', '暖奶消毒', null, '4', '347', '3', '338|347|394', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('395', '爱慕', null, '1', '382', '3', '378|382|395', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('396', '水壶', null, '5', '347', '3', '338|347|396', null, '0', '36', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('397', '华歌尔', null, '2', '382', '3', '378|382|397', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('398', '曼妮芬', null, '3', '382', '3', '378|382|398', null, '0', '1', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('399', '玩具乐器', null, '21', '0', '1', '399', null, '1', '37', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('400', '古今', null, '4', '382', '3', '378|382|400', null, '0', '1', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('403', '珠宝', null, '22', '0', '1', '403', null, '1', '29', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('405', '时尚饰品', null, '1', '403', '2', '403|405', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('406', '玩具乐器', null, '4', '399', '2', '399|406', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('407', '纯金饰品', null, '2', '403', '2', '403|407', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('408', '金银投资', null, '3', '403', '2', '403|408', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('409', '钻石', null, '4', '403', '2', '403|409', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('410', '翡翠玉石', null, '5', '403', '2', '403|410', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('411', '适用年龄', null, '1', '406', '3', '399|406|411', null, '0', '37', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('412', '毛绒布艺', null, '2', '406', '3', '399|406|412', null, '0', '37', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('413', '娃娃玩具', null, '3', '406', '3', '399|406|413', null, '0', '37', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('414', '项链', null, '1', '405', '3', '403|405|414', null, '0', '29', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('415', '动漫玩具', null, '4', '406', '3', '399|406|415', null, '0', '37', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('416', '益智玩具', null, '5', '406', '3', '399|406|416', null, '0', '37', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('417', ' 戒指', null, '2', '405', '3', '403|405|417', null, '0', '30', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('418', '整车', null, '23', '0', '1', '418', null, '1', '33', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('419', ' 耳饰', null, '3', '405', '3', '403|405|419', null, '0', '29', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('420', '全新整车', null, '1', '418', '2', '418|420', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('421', '耳饰', null, '1', '407', '3', '403|407|421', null, '0', '29', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('422', '小型车', null, '1', '420', '3', '418|420|422', null, '0', '33', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('423', '戒指', null, '2', '407', '3', '403|407|423', null, '0', '29', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('424', '紧凑型车', null, '2', '420', '3', '418|420|424', null, '0', '33', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('425', '中型车', null, '3', '420', '3', '418|420|425', null, '0', '33', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('426', '吊坠', null, '3', '407', '3', '403|407|426', null, '0', '29', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('427', '豪华车', null, '4', '420', '3', '418|420|427', null, '0', '33', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('428', 'SUV', null, '5', '420', '3', '418|420|428', null, '0', '33', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('429', '工艺金', null, '1', '408', '3', '403|408|429', null, '0', '29', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('430', '工艺银', null, '2', '408', '3', '403|408|430', null, '0', '29', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('431', '汽车用品', null, '24', '0', '1', '431', null, '1', '35', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('432', '维修保养', null, '1', '431', '2', '431|432', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('433', '车载电器', null, '2', '431', '2', '431|433', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('434', '裸钻', null, '1', '409', '3', '403|409|434', null, '0', '29', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('435', '美容清洗', null, '3', '431', '2', '431|435', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('436', '戒指', null, '2', '409', '3', '403|409|436', null, '0', '29', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('437', '汽车装饰', null, '4', '431', '2', '431|437', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('438', '安全自驾', null, '5', '431', '2', '431|438', null, '1', '3', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('439', '手镯', null, '3', '409', '3', '403|409|439', null, '0', '29', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('440', '润滑剂', null, '1', '432', '3', '431|432|440', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('441', '添加剂', null, '2', '432', '3', '431|432|441', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('442', '手串', null, '1', '410', '3', '403|410|442', null, '0', '29', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('443', '防冻液', null, '3', '432', '3', '431|432|443', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('444', '高值收藏', null, '2', '410', '3', '403|410|444', null, '0', '29', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('445', '滤清器', null, '4', '432', '3', '431|432|445', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('446', '项链', null, '3', '410', '3', '403|410|446', null, '0', '29', '4.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('447', '火花塞', null, '5', '432', '3', '431|432|447', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('448', '个户化妆', null, '25', '0', '1', '448', null, '1', '9', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('449', '导航仪', null, '1', '433', '3', '431|433|449', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('450', '面部护理', null, '1', '448', '2', '448|450', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('451', '安全预警仪', null, '2', '433', '3', '431|433|451', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('452', '身体护理', null, '2', '448', '2', '448|452', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('453', '行车记录仪', null, '3', '433', '3', '431|433|453', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('454', '洗发护发', null, '3', '448', '2', '448|454', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('455', '倒车雷达', null, '4', '433', '3', '431|433|455', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('456', '口腔护理', null, '4', '448', '2', '448|456', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('457', '净化器', null, '5', '433', '3', '431|433|457', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('458', '女性护理', null, '5', '448', '2', '448|458', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('459', '车蜡', null, '1', '435', '3', '431|435|459', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('460', '护肤', null, '1', '450', '3', '448|450|460', null, '0', '9', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('461', '补漆笔', null, '2', '435', '3', '431|435|461', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('462', '面膜', null, '2', '450', '3', '448|450|462', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('463', '清洁', null, '3', '450', '3', '448|450|463', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('464', '玻璃水', null, '3', '435', '3', '431|435|464', null, '0', '3', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('465', '清洁剂', null, '4', '435', '3', '431|435|465', null, '0', '3', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('466', '沐浴', null, '1', '452', '3', '448|452|466', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('467', '洗车工具', null, '5', '435', '3', '431|435|467', null, '0', '3', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('468', '润肤', null, '2', '452', '3', '448|452|468', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('469', '脚垫', null, '1', '437', '3', '431|437|469', null, '0', '3', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('470', '坐垫', null, '2', '437', '3', '431|437|470', null, '0', '3', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('471', '手足', null, '3', '452', '3', '448|452|471', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('472', '洗发', null, '1', '454', '3', '448|454|472', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('473', '护发', null, '2', '454', '3', '448|454|473', null, '0', '9', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('474', '染发', null, '3', '454', '3', '448|454|474', null, '0', '9', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('475', '牙刷', null, '1', '456', '3', '448|456|475', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('476', '后备箱垫', null, '3', '437', '3', '431|437|476', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('477', '牙膏', null, '2', '456', '3', '448|456|477', null, '0', '9', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('478', '漱口水', null, '3', '456', '3', '448|456|478', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('479', '香水', null, '4', '437', '3', '431|437|479', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('480', '卫生棉', null, '1', '458', '3', '448|458|480', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('481', '护垫', null, '2', '458', '3', '448|458|481', null, '0', '9', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('482', '车内饰品', null, '5', '437', '3', '431|437|482', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('483', '私密护理', null, '3', '458', '3', '448|458|483', null, '0', '9', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('484', '安全座椅', null, '1', '438', '3', '431|438|484', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('485', '鞋靴', null, '26', '0', '1', '485', null, '1', '17', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('486', '时尚女鞋', null, '1', '485', '2', '485|486', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('487', '流行男鞋', null, '2', '485', '2', '485|487', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('488', '充气泵', null, '2', '438', '3', '431|438|488', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('489', '防盗设备', null, '3', '438', '3', '431|438|489', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('490', '雪地靴', null, '1', '486', '3', '485|486|490', null, '0', '17', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('491', '长筒靴', null, '2', '486', '3', '485|486|491', null, '0', '17', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('492', '储物箱', null, '4', '438', '3', '431|438|492', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('494', '单鞋', null, '3', '486', '3', '485|486|494', null, '0', '17', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('495', '自驾野营', null, '6', '438', '3', '431|438|495', null, '0', '35', '1.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('496', '短靴', null, '4', '486', '3', '485|486|496', null, '0', '17', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('497', '休闲鞋', null, '1', '487', '3', '485|487|497', null, '0', '17', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('498', '板鞋', null, '2', '487', '3', '485|487|498', null, '0', '17', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('499', '正装鞋', null, '3', '487', '3', '485|487|499', null, '0', '17', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('500', '箱包', null, '27', '0', '1', '500', null, '1', '16', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('501', '潮流女包', null, '1', '500', '2', '500|501', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('502', '精品男包', null, '2', '500', '2', '500|502', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('503', '功能箱包', null, '3', '500', '2', '500|503', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('504', '礼品', null, '4', '500', '2', '500|504', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('505', '钱包', null, '1', '501', '3', '500|501|505', null, '0', '16', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('506', '手拿包', null, '2', '501', '3', '500|501|506', null, '0', '16', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('507', '单肩包', null, '3', '501', '3', '500|501|507', null, '0', '16', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('508', '双肩包', null, '4', '501', '3', '500|501|508', null, '0', '16', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('509', '商务公文包', null, '1', '502', '3', '500|502|509', null, '0', '16', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('510', '单肩包', null, '2', '502', '3', '500|502|510', null, '0', '16', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('511', '斜挎包', null, '3', '502', '3', '500|502|511', null, '0', '16', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('512', '拉杆箱/包', null, '1', '503', '3', '500|503|512', null, '0', '16', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('513', '电脑包', null, '2', '503', '3', '500|503|513', null, '0', '16', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('514', '休闲运动包', null, '3', '503', '3', '500|503|514', null, '0', '16', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('515', '旅行包', null, '4', '503', '3', '500|503|515', null, '0', '16', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('516', '工艺礼品', null, '1', '504', '3', '500|504|516', null, '0', '16', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('517', '火机烟具', null, '2', '504', '3', '500|504|517', null, '0', '16', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('518', '礼品文具', null, '3', '504', '3', '500|504|518', null, '0', '16', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('519', '军刀军具', null, '4', '504', '3', '500|504|519', null, '0', '16', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('520', '钟表', null, '28', '0', '1', '520', null, '1', '30', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('521', '男表', null, '1', '520', '2', '520|521', null, '0', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('522', '女表', null, '2', '520', '2', '520|522', null, '0', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('523', '儿童表', null, '3', '520', '2', '520|523', null, '0', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('524', '座钟挂钟', null, '4', '520', '2', '520|524', null, '0', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('525', '奢侈品', null, '29', '0', '1', '525', null, '1', '31', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('526', '箱包', null, '1', '525', '2', '525|526', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('527', '钱包', null, '2', '525', '2', '525|527', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('528', '服饰', null, '3', '525', '2', '525|528', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('529', '腰带', null, '4', '525', '2', '525|529', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('530', '鞋靴', null, '5', '525', '2', '525|530', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('531', 'COACH', null, '1', '526', '3', '525|526|531', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('532', 'MCM', null, '2', '526', '3', '525|526|532', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('533', '古驰', null, '3', '526', '3', '525|526|533', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('534', '普拉达', null, '1', '527', '3', '525|527|534', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('535', '巴宝莉', null, '2', '527', '3', '525|527|535', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('536', '兰姿', null, '3', '527', '3', '525|527|536', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('537', '迪赛', null, '1', '528', '3', '525|528|537', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('538', '芬迪', null, '2', '528', '3', '525|528|538', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('539', '杰尼亚', null, '3', '528', '3', '525|528|539', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('540', '巴宝莉', null, '1', '529', '3', '525|529|540', null, '0', '31', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('541', '蔻驰', null, '2', '529', '3', '525|529|541', null, '0', '31', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('542', '阿玛尼', null, '3', '529', '3', '525|529|542', null, '0', '31', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('544', '巴利', null, '1', '530', '3', '525|530|544', null, '0', '31', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('545', '托德斯', null, '2', '530', '3', '525|530|545', null, '0', '31', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('546', '运动户外', null, '30', '0', '1', '546', null, '1', '32', '0.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('547', '运动鞋包', null, '1', '546', '2', '546|547', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('548', '运动服饰', null, '2', '546', '2', '546|548', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('549', '健身训练', null, '3', '546', '2', '546|549', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('550', '骑行运动', null, '4', '546', '2', '546|550', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('551', '体育用品', null, '5', '546', '2', '546|551', null, '1', '1', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('552', '跑步鞋', null, '1', '547', '3', '546|547|552', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('553', '篮球鞋', null, '2', '547', '3', '546|547|553', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('554', ' 休闲鞋', null, '3', '547', '3', '546|547|554', null, '0', '32', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('555', '卫衣套头衫', null, '1', '548', '3', '546|548|555', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('556', '套装', null, '2', '548', '3', '546|548|556', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('557', '夹克/风衣', null, '3', '548', '3', '546|548|557', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('558', '甩脂机', null, '1', '549', '3', '546|549|558', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('559', '健身器械', null, '2', '549', '3', '546|549|559', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('560', '家用跑步机', null, '3', '549', '3', '546|549|560', null, '0', '32', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('561', '平衡车', null, '1', '550', '3', '546|550|561', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('562', '折叠车', null, '2', '550', '3', '546|550|562', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('563', '挡风被', null, '3', '550', '3', '546|550|563', null, '0', '32', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('564', '自营篮球', null, '1', '551', '3', '546|551|564', null, '0', '32', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('565', '自营乒乓球', null, '2', '551', '3', '546|551|565', null, '0', '32', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('566', '羽毛球拍', null, '3', '551', '3', '546|551|566', null, '0', '32', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('567', '水果', null, '3', '309', '2', '309|567', null, '1', '40', '100.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('568', '进口水果', null, '1', '567', '3', '309|567|568', null, '0', '40', '2.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('569', '国内水果', null, '2', '567', '3', '309|567|569', null, '0', '40', '3.00', null, null, null);
INSERT INTO `Himall_Categories` VALUES ('570', '测试', null, '4', '75', '3', '1|75|570', null, '0', '6', '4.00', null, null, null);

-- ----------------------------
-- Table structure for Himall_Coupon
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Coupon`;
CREATE TABLE `Himall_Coupon` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) DEFAULT NULL,
  `Price` decimal(18,0) NOT NULL,
  `PerMax` int(11) NOT NULL,
  `OrderAmount` decimal(18,0) NOT NULL,
  `Num` int(11) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  `CouponName` varchar(100) NOT NULL,
  `CreateTime` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_Coupon_Himall_Shops` (`ShopId`) USING BTREE,
  CONSTRAINT `himall_coupon_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Coupon
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_CouponRecord
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CouponRecord`;
CREATE TABLE `Himall_CouponRecord` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `CouponId` bigint(20) NOT NULL,
  `CounponSN` varchar(50) NOT NULL,
  `CounponTime` datetime NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `UserId` bigint(20) NOT NULL,
  `UsedTime` datetime DEFAULT NULL,
  `OrderId` bigint(20) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `CounponStatus` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_couponrecord_couponid` (`CouponId`) USING BTREE,
  KEY `FK_couponrecord_shopid` (`ShopId`) USING BTREE,
  CONSTRAINT `himall_couponrecord_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`),
  CONSTRAINT `himall_couponrecord_ibfk_2` FOREIGN KEY (`CouponId`) REFERENCES `Himall_Coupon` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_CouponRecord
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_CouponSetting
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CouponSetting`;
CREATE TABLE `Himall_CouponSetting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PlatForm` int(11) NOT NULL,
  `CouponID` bigint(20) NOT NULL,
  `Display` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_CouponSetting
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_CustomerServices
-- ----------------------------
DROP TABLE IF EXISTS `Himall_CustomerServices`;
CREATE TABLE `Himall_CustomerServices` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Tool` int(11) NOT NULL,
  `Type` int(11) NOT NULL,
  `Name` varchar(1000) NOT NULL,
  `AccountCode` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_CustomerServices
-- ----------------------------
INSERT INTO `Himall_CustomerServices` VALUES ('1', '3', '1', '1', '小青', '123566');
INSERT INTO `Himall_CustomerServices` VALUES ('2', '3', '1', '2', '小兰', '56222');
INSERT INTO `Himall_CustomerServices` VALUES ('3', '4', '1', '1', '雨燕', '556211485');
INSERT INTO `Himall_CustomerServices` VALUES ('4', '4', '2', '2', '花儿岩', '56992145');
INSERT INTO `Himall_CustomerServices` VALUES ('5', '5', '1', '1', '花儿美丽', '665233104');
INSERT INTO `Himall_CustomerServices` VALUES ('6', '5', '2', '2', '小哥', '6652418');
INSERT INTO `Himall_CustomerServices` VALUES ('7', '1', '1', '1', '小美丽', '774588512');
INSERT INTO `Himall_CustomerServices` VALUES ('8', '1', '2', '2', '杨过', '66321548552');

-- ----------------------------
-- Table structure for Himall_Favorites
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Favorites`;
CREATE TABLE `Himall_Favorites` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `Tags` varchar(100) DEFAULT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_Favorite` (`UserId`) USING BTREE,
  KEY `FK_Product_Favorite` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_favorites_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_favorites_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=368 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Favorites
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_FavoriteShops
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FavoriteShops`;
CREATE TABLE `Himall_FavoriteShops` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `Tags` varchar(100) DEFAULT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_FavoriteShops
-- ----------------------------
INSERT INTO `Himall_FavoriteShops` VALUES ('6', '4', '1', '', '2014-11-29 14:34:15');
INSERT INTO `Himall_FavoriteShops` VALUES ('10', '18', '1', '', '2014-11-29 14:56:44');
INSERT INTO `Himall_FavoriteShops` VALUES ('13', '10', '1', '', '2014-11-29 15:01:11');
INSERT INTO `Himall_FavoriteShops` VALUES ('14', '21', '1', '', '2014-11-29 15:21:49');
INSERT INTO `Himall_FavoriteShops` VALUES ('19', '22', '1', '', '2014-11-29 16:17:25');
INSERT INTO `Himall_FavoriteShops` VALUES ('23', '23', '1', '', '2014-11-29 16:27:57');

-- ----------------------------
-- Table structure for Himall_FloorBrands
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FloorBrands`;
CREATE TABLE `Himall_FloorBrands` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorId` bigint(20) NOT NULL,
  `BrandId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Brand_FloorBrand` (`BrandId`) USING BTREE,
  KEY `FK_HomeFloor_FloorBrand` (`FloorId`) USING BTREE,
  CONSTRAINT `himall_floorbrands_ibfk_1` FOREIGN KEY (`BrandId`) REFERENCES `Himall_Brands` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_floorbrands_ibfk_2` FOREIGN KEY (`FloorId`) REFERENCES `Himall_HomeFloors` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_FloorBrands
-- ----------------------------
INSERT INTO `Himall_FloorBrands` VALUES ('1', '1', '51');
INSERT INTO `Himall_FloorBrands` VALUES ('7', '1', '29');
INSERT INTO `Himall_FloorBrands` VALUES ('8', '1', '37');
INSERT INTO `Himall_FloorBrands` VALUES ('9', '1', '36');
INSERT INTO `Himall_FloorBrands` VALUES ('10', '1', '38');
INSERT INTO `Himall_FloorBrands` VALUES ('11', '1', '31');
INSERT INTO `Himall_FloorBrands` VALUES ('25', '4', '12');
INSERT INTO `Himall_FloorBrands` VALUES ('27', '4', '16');
INSERT INTO `Himall_FloorBrands` VALUES ('28', '4', '18');
INSERT INTO `Himall_FloorBrands` VALUES ('29', '4', '22');
INSERT INTO `Himall_FloorBrands` VALUES ('30', '4', '21');
INSERT INTO `Himall_FloorBrands` VALUES ('31', '4', '19');
INSERT INTO `Himall_FloorBrands` VALUES ('32', '2', '74');
INSERT INTO `Himall_FloorBrands` VALUES ('33', '2', '72');
INSERT INTO `Himall_FloorBrands` VALUES ('34', '2', '75');
INSERT INTO `Himall_FloorBrands` VALUES ('35', '2', '73');
INSERT INTO `Himall_FloorBrands` VALUES ('36', '2', '76');
INSERT INTO `Himall_FloorBrands` VALUES ('37', '2', '69');
INSERT INTO `Himall_FloorBrands` VALUES ('38', '2', '70');
INSERT INTO `Himall_FloorBrands` VALUES ('39', '2', '78');
INSERT INTO `Himall_FloorBrands` VALUES ('40', '2', '77');
INSERT INTO `Himall_FloorBrands` VALUES ('41', '1', '35');
INSERT INTO `Himall_FloorBrands` VALUES ('42', '1', '57');
INSERT INTO `Himall_FloorBrands` VALUES ('43', '1', '30');
INSERT INTO `Himall_FloorBrands` VALUES ('44', '1', '33');
INSERT INTO `Himall_FloorBrands` VALUES ('45', '1', '42');
INSERT INTO `Himall_FloorBrands` VALUES ('46', '1', '34');
INSERT INTO `Himall_FloorBrands` VALUES ('47', '1', '48');
INSERT INTO `Himall_FloorBrands` VALUES ('48', '1', '39');
INSERT INTO `Himall_FloorBrands` VALUES ('49', '1', '43');
INSERT INTO `Himall_FloorBrands` VALUES ('50', '1', '63');
INSERT INTO `Himall_FloorBrands` VALUES ('51', '4', '14');
INSERT INTO `Himall_FloorBrands` VALUES ('52', '4', '120');
INSERT INTO `Himall_FloorBrands` VALUES ('53', '5', '95');
INSERT INTO `Himall_FloorBrands` VALUES ('54', '5', '98');
INSERT INTO `Himall_FloorBrands` VALUES ('55', '5', '101');
INSERT INTO `Himall_FloorBrands` VALUES ('56', '5', '44');
INSERT INTO `Himall_FloorBrands` VALUES ('57', '5', '53');
INSERT INTO `Himall_FloorBrands` VALUES ('58', '5', '61');
INSERT INTO `Himall_FloorBrands` VALUES ('59', '5', '99');
INSERT INTO `Himall_FloorBrands` VALUES ('60', '5', '104');
INSERT INTO `Himall_FloorBrands` VALUES ('61', '5', '116');
INSERT INTO `Himall_FloorBrands` VALUES ('62', '5', '117');
INSERT INTO `Himall_FloorBrands` VALUES ('63', '5', '118');
INSERT INTO `Himall_FloorBrands` VALUES ('64', '5', '119');
INSERT INTO `Himall_FloorBrands` VALUES ('65', '5', '121');
INSERT INTO `Himall_FloorBrands` VALUES ('66', '5', '125');
INSERT INTO `Himall_FloorBrands` VALUES ('67', '5', '126');
INSERT INTO `Himall_FloorBrands` VALUES ('68', '7', '68');
INSERT INTO `Himall_FloorBrands` VALUES ('69', '7', '101');
INSERT INTO `Himall_FloorBrands` VALUES ('70', '7', '53');
INSERT INTO `Himall_FloorBrands` VALUES ('71', '7', '86');
INSERT INTO `Himall_FloorBrands` VALUES ('72', '7', '107');
INSERT INTO `Himall_FloorBrands` VALUES ('73', '7', '109');
INSERT INTO `Himall_FloorBrands` VALUES ('74', '7', '129');
INSERT INTO `Himall_FloorBrands` VALUES ('75', '7', '123');
INSERT INTO `Himall_FloorBrands` VALUES ('76', '7', '144');
INSERT INTO `Himall_FloorBrands` VALUES ('77', '7', '142');
INSERT INTO `Himall_FloorBrands` VALUES ('78', '7', '133');
INSERT INTO `Himall_FloorBrands` VALUES ('79', '7', '150');
INSERT INTO `Himall_FloorBrands` VALUES ('80', '7', '156');

-- ----------------------------
-- Table structure for Himall_FloorCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FloorCategories`;
CREATE TABLE `Himall_FloorCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorId` bigint(20) NOT NULL,
  `CategoryId` bigint(20) NOT NULL,
  `Depth` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Category_FloorCategory` (`CategoryId`) USING BTREE,
  KEY `FK_HomeFloor_FloorCategory` (`FloorId`) USING BTREE,
  CONSTRAINT `himall_floorcategories_ibfk_1` FOREIGN KEY (`CategoryId`) REFERENCES `Himall_Categories` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_floorcategories_ibfk_2` FOREIGN KEY (`FloorId`) REFERENCES `Himall_HomeFloors` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_FloorCategories
-- ----------------------------
INSERT INTO `Himall_FloorCategories` VALUES ('43', '2', '9', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('44', '2', '17', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('45', '2', '20', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('61', '3', '9', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('62', '3', '23', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('63', '3', '26', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('64', '3', '48', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('65', '3', '49', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('66', '3', '50', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('67', '3', '51', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('68', '3', '64', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('69', '3', '65', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('70', '3', '66', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('71', '3', '67', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('72', '3', '69', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('73', '3', '70', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('74', '3', '68', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('75', '3', '71', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('77', '4', '20', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('78', '4', '23', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('90', '1', '312', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('91', '1', '352', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('92', '1', '378', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('93', '1', '485', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('106', '1', '314', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('107', '1', '324', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('108', '1', '325', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('109', '1', '323', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('110', '1', '381', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('111', '1', '389', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('112', '1', '391', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('113', '1', '392', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('118', '2', '150', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('119', '2', '234', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('120', '2', '165', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('121', '2', '177', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('122', '2', '180', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('123', '2', '178', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('124', '2', '179', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('125', '2', '183', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('126', '2', '236', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('127', '2', '246', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('128', '2', '248', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('129', '2', '250', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('130', '2', '254', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('131', '2', '252', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('144', '1', '353', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('145', '1', '360', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('146', '1', '361', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('147', '1', '357', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('158', '5', '448', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('160', '5', '450', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('161', '5', '460', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('163', '5', '463', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('164', '5', '452', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('165', '5', '471', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('166', '5', '466', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('171', '5', '456', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('172', '5', '478', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('174', '4', '21', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('175', '4', '60', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('176', '4', '61', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('177', '4', '124', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('178', '4', '22', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('179', '4', '62', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('180', '4', '63', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('181', '4', '125', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('182', '4', '121', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('183', '4', '126', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('184', '4', '127', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('185', '4', '128', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('186', '7', '152', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('187', '7', '224', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('188', '7', '234', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('189', '7', '295', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('190', '7', '312', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('191', '7', '338', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('192', '7', '264', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('193', '7', '309', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('194', '7', '378', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('195', '7', '448', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('196', '7', '485', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('197', '7', '500', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('198', '7', '520', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('199', '7', '546', '1');
INSERT INTO `Himall_FloorCategories` VALUES ('206', '7', '155', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('207', '7', '170', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('208', '7', '171', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('209', '7', '166', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('210', '7', '167', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('211', '7', '236', '2');
INSERT INTO `Himall_FloorCategories` VALUES ('212', '7', '246', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('213', '7', '248', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('214', '7', '250', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('215', '7', '254', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('216', '7', '252', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('218', '5', '475', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('220', '5', '477', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('221', '5', '462', '3');
INSERT INTO `Himall_FloorCategories` VALUES ('222', '5', '468', '3');

-- ----------------------------
-- Table structure for Himall_FloorProducts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FloorProducts`;
CREATE TABLE `Himall_FloorProducts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorId` bigint(20) NOT NULL,
  `Tab` int(11) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_HomeFloor_FloorProduct` (`FloorId`) USING BTREE,
  KEY `FK_Product_FloorProduct` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_floorproducts_ibfk_1` FOREIGN KEY (`FloorId`) REFERENCES `Himall_HomeFloors` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_floorproducts_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_FloorProducts
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_FloorTopics
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FloorTopics`;
CREATE TABLE `Himall_FloorTopics` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorId` bigint(20) NOT NULL,
  `TopicType` int(11) NOT NULL,
  `TopicImage` varchar(100) NOT NULL,
  `TopicName` varchar(100) NOT NULL,
  `Url` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_HomeFloor_FloorTopic` (`FloorId`) USING BTREE,
  CONSTRAINT `himall_floortopics_ibfk_1` FOREIGN KEY (`FloorId`) REFERENCES `Himall_HomeFloors` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1721 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_FloorTopics
-- ----------------------------
INSERT INTO `Himall_FloorTopics` VALUES ('1', '1', '2', '/Storage/Plat/PageSettings/HomeFloor/1/floor_Top_20141105152144270434.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('42', '2', '2', '/Storage/Plat/PageSettings/HomeFloor/2/floor_Top_20141105160028670382.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('51', '3', '2', '/Storage/Plat/PageSettings/HomeFloor/3/floor_Top_20141105160935898681.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('68', '3', '5', '', '2013版三国杀：神话再临合集（含军争风', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('69', '3', '5', '', '追风筝的人', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('70', '3', '5', '', '乖，摸摸头', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('71', '3', '5', '', '你的孤独，虽败犹荣', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('72', '3', '3', '/Storage/Plat/PageSettings/HomeFloor/3/floor_Middle_20141105160935915682.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('73', '3', '3', '/Storage/Plat/PageSettings/HomeFloor/3/floor_Middle_20141105160935926683.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('74', '3', '3', '/Storage/Plat/PageSettings/HomeFloor/3/floor_Middle_20141105160935927683.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('75', '3', '3', '/Storage/Plat/PageSettings/HomeFloor/3/floor_Middle_20141105160935927683.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('76', '4', '2', '/Storage/Plat/PageSettings/HomeFloor/4/floor_Top_20141105161602880815.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('253', '5', '2', '/Storage/Plat/PageSettings/HomeFloor/5/floor_Top_20141128193504018554.png', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('283', '7', '2', '/Storage/Plat/PageSettings/HomeFloor/7/floor_Top_20141128203407262695.png', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('648', '7', '5', '', '品牌乐器请看这里', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('649', '7', '5', '', '瞅瞅！土豪的宝宝都用啥？', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('650', '7', '5', '', '保健养生器械专场', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('651', '7', '5', '', '红啤洋酒最高满399减150', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('652', '7', '5', '', '蜜果尝鲜专场满199立减100元', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('653', '7', '5', '', '精品童装 全场最高满299立减100元', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('654', '7', '5', '', '母婴用品专场，最高满200减50', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('655', '7', '3', '/Storage/Plat/PageSettings/HomeFloor/7/floor_Middle_20141128202617684570.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('656', '7', '3', '/Storage/Plat/PageSettings/HomeFloor/7/floor_Middle_20141130191636579101.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('657', '7', '3', '/Storage/Plat/PageSettings/HomeFloor/7/floor_Middle_20141130200439657226.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('658', '7', '3', '/Storage/Plat/PageSettings/HomeFloor/7/floor_Middle_20141130200439657226.png', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('659', '1', '5', '', '11.11品牌西洋管乐全场特惠', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('660', '1', '5', '', '“京”喜72小时，11.11提前过', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('661', '1', '5', '', '安全出行没它不行!', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('662', '1', '5', '', '母婴价格低过11.11！速达质保', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('663', '1', '5', '', '家纺大聚惠 0.1元秒杀', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('664', '1', '5', '', '黑色星期五 5折开抢', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('665', '1', '5', '', '互动答题赢大奖', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('666', '1', '3', '/Storage/Plat/PageSettings/HomeFloor/1/floor_Middle_20141130195747000976.png', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('667', '1', '3', '/Storage/Plat/PageSettings/HomeFloor/1/floor_Middle_20141130195747094726.png', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('668', '1', '3', '/Storage/Plat/PageSettings/HomeFloor/1/floor_Middle_20141130193030641601.png', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('669', '1', '3', '/Storage/Plat/PageSettings/HomeFloor/1/floor_Middle_20141130195747094726.png', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('670', '4', '5', '', '无线喷墨照片机，还能2', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('671', '4', '5', '', '超静音游戏猛兽来袭！', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('672', '4', '5', '', '【每满100减20！】振华', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('673', '4', '5', '', '托兔 I7 4790/华硕GTX760DIY组装机', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('674', '4', '5', '', '屏幕碎了？免费换新！', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('675', '4', '5', '', '修改送安时间等信息', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('676', '4', '5', '', '自拍神器免费送啦', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('677', '4', '3', '/Storage/Plat/PageSettings/HomeFloor/4/floor_Middle_20141105161602903817.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('678', '4', '3', '/Storage/Plat/PageSettings/HomeFloor/4/floor_Middle_20141130191246735351.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('679', '4', '3', '/Storage/Plat/PageSettings/HomeFloor/4/floor_Middle_20141130200005750976.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('680', '4', '3', '/Storage/Plat/PageSettings/HomeFloor/4/floor_Middle_20141130191246750976.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('689', '5', '5', '', '尾品汇，3.9折封顶！', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('690', '5', '5', '', '精选4.9折封顶', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('691', '5', '5', '', '炬惠周年庆满999减50', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('692', '5', '5', '', '感恩节特惠！', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('693', '5', '5', '', '欧莱雅全场火拼！', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('694', '5', '5', '', '黑色星期五，海外特品会', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('695', '5', '5', '', '秋冬保湿专场', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('696', '5', '3', '/Storage/Plat/PageSettings/HomeFloor/5/floor_Middle_20141128214127481445.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('697', '5', '3', '/Storage/Plat/PageSettings/HomeFloor/5/floor_Middle_20141130191556579101.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('698', '5', '3', '/Storage/Plat/PageSettings/HomeFloor/5/floor_Middle_20141130200142047851.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('699', '5', '3', '/Storage/Plat/PageSettings/HomeFloor/5/floor_Middle_20141130200142047851.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('700', '2', '5', '', '进口橄榄油 橄露满199减100', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('701', '2', '5', '', '福临门专场满99立减15元', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('702', '2', '5', '', '冬季保暖选京东', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('703', '2', '5', '', '成人低价钜惠，这次不买就涨价了', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('704', '2', '5', '', '自拍神器免费送啦', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('705', '2', '5', '', '黑色星期五，海外特品会', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('706', '2', '5', '', '保健养生器械专场', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('707', '2', '3', '/Storage/Plat/PageSettings/HomeFloor/2/floor_Middle_20141105160028693383.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('708', '2', '3', '/Storage/Plat/PageSettings/HomeFloor/2/floor_Middle_20141105160028694383.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('709', '2', '3', '/Storage/Plat/PageSettings/HomeFloor/2/floor_Middle_20141105160028694383.jpg', '', '/');
INSERT INTO `Himall_FloorTopics` VALUES ('710', '2', '3', '/Storage/Plat/PageSettings/HomeFloor/2/floor_Middle_20141105160028695383.jpg', '', '/');

-- ----------------------------
-- Table structure for Himall_FreightAreaContent
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FreightAreaContent`;
CREATE TABLE `Himall_FreightAreaContent` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FreightTemplateId` bigint(20) NOT NULL,
  `AreaContent` varchar(4000) DEFAULT NULL,
  `FirstUnit` int(11) DEFAULT NULL,
  `FirstUnitMonry` float DEFAULT NULL,
  `AccumulationUnit` int(11) DEFAULT NULL,
  `AccumulationUnitMoney` float DEFAULT NULL,
  `IsDefault` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Freighttemalate_FreightAreaContent` (`FreightTemplateId`) USING BTREE,
  CONSTRAINT `himall_freightareacontent_ibfk_1` FOREIGN KEY (`FreightTemplateId`) REFERENCES `Himall_FreightTemplate` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_FreightAreaContent
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_FreightTemplate
-- ----------------------------
DROP TABLE IF EXISTS `Himall_FreightTemplate`;
CREATE TABLE `Himall_FreightTemplate` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `SourceAddress` int(11) DEFAULT NULL,
  `SendTime` varchar(100) DEFAULT NULL,
  `IsFree` int(11) NOT NULL,
  `ValuationMethod` int(11) NOT NULL,
  `ShippingMethod` int(11) DEFAULT NULL,
  `ShopID` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_FreightTemplate
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_HandSlideAds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_HandSlideAds`;
CREATE TABLE `Himall_HandSlideAds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ImageUrl` varchar(100) NOT NULL,
  `Url` varchar(1000) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_HandSlideAds
-- ----------------------------
INSERT INTO `Himall_HandSlideAds` VALUES ('1', '/Storage/Plat/ImageAd/201411051528182361563.jpg', '/', '1');
INSERT INTO `Himall_HandSlideAds` VALUES ('2', '/Storage/Plat/ImageAd/201411051528229582873.jpg', '/', '2');
INSERT INTO `Himall_HandSlideAds` VALUES ('3', '/Storage/Plat/ImageAd/201411051528270478945.jpg', '/', '3');
INSERT INTO `Himall_HandSlideAds` VALUES ('5', '/Storage/Plat/ImageAd/201411051528364572567.jpg', '/', '4');
INSERT INTO `Himall_HandSlideAds` VALUES ('6', '/Storage/Plat/ImageAd/201411051528404527667.jpg', '/', '5');
INSERT INTO `Himall_HandSlideAds` VALUES ('7', '/Storage/Plat/ImageAd/201411051528443681324.jpg', '/', '6');
INSERT INTO `Himall_HandSlideAds` VALUES ('8', '/Storage/Plat/ImageAd/201411051528483706424.jpg', '/', '7');
INSERT INTO `Himall_HandSlideAds` VALUES ('9', '/Storage/Plat/ImageAd/201411051528527222779.jpg', '/', '8');

-- ----------------------------
-- Table structure for Himall_HomeCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_HomeCategories`;
CREATE TABLE `Himall_HomeCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `RowId` int(11) NOT NULL,
  `CategoryId` bigint(20) NOT NULL,
  `Depth` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Category_HomeCategory` (`CategoryId`) USING BTREE,
  CONSTRAINT `himall_homecategories_ibfk_1` FOREIGN KEY (`CategoryId`) REFERENCES `Himall_Categories` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1672 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_HomeCategories
-- ----------------------------
INSERT INTO `Himall_HomeCategories` VALUES ('293', '6', '13', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('294', '6', '107', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('295', '6', '106', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('296', '6', '105', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('297', '6', '104', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('298', '6', '103', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('299', '6', '102', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('300', '6', '101', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('301', '6', '100', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('302', '6', '99', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('303', '6', '98', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('304', '6', '54', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('305', '6', '53', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('306', '6', '97', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('307', '6', '96', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('308', '6', '52', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('373', '3', '23', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('374', '3', '26', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('375', '3', '144', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('376', '3', '143', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('377', '3', '142', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('378', '3', '141', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('379', '3', '140', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('380', '3', '139', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('381', '3', '138', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('382', '3', '67', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('383', '3', '66', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('384', '3', '137', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('385', '3', '65', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('386', '3', '64', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('387', '3', '149', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('388', '3', '148', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('389', '3', '147', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('390', '3', '151', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('391', '3', '71', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('392', '3', '70', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('393', '3', '146', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('394', '3', '69', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('395', '3', '68', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('396', '7', '186', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('397', '7', '152', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('398', '7', '224', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('399', '7', '264', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('400', '7', '223', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('401', '7', '222', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('402', '7', '221', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('403', '7', '219', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('404', '7', '217', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('405', '7', '216', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('406', '7', '215', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('407', '7', '213', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('408', '7', '211', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('409', '7', '208', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('410', '7', '206', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('411', '7', '204', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('412', '7', '202', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('413', '7', '200', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('414', '7', '198', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('415', '7', '196', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('416', '7', '262', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('417', '7', '260', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('418', '7', '259', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('419', '7', '258', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('420', '7', '256', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('421', '7', '253', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('422', '7', '251', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('423', '7', '249', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('424', '7', '247', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('425', '7', '245', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('426', '7', '243', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('427', '7', '241', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('428', '7', '239', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('429', '7', '237', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('430', '7', '235', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('431', '7', '233', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('432', '7', '310', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('433', '7', '308', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('434', '7', '306', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('435', '7', '305', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('436', '7', '303', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('437', '7', '301', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('438', '7', '299', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('439', '7', '296', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('440', '7', '294', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('441', '7', '292', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('442', '7', '289', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('443', '7', '287', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('444', '7', '285', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('445', '7', '281', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('446', '7', '280', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('447', '7', '278', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('448', '7', '276', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('449', '7', '184', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('450', '7', '182', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('451', '7', '181', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('452', '7', '176', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('453', '7', '175', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('454', '7', '173', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('455', '7', '171', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('456', '7', '170', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('457', '7', '167', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('458', '7', '166', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('459', '7', '164', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('460', '7', '162', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('461', '7', '161', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('462', '7', '160', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('463', '7', '159', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('464', '7', '158', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('465', '7', '157', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('518', '8', '448', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('519', '8', '483', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('520', '8', '481', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('521', '8', '480', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('522', '8', '478', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('523', '8', '477', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('524', '8', '475', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('525', '8', '474', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('526', '8', '473', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('527', '8', '472', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('528', '8', '471', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('529', '8', '468', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('530', '8', '466', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('531', '8', '463', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('532', '8', '462', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('533', '8', '460', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('534', '9', '485', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('535', '9', '500', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('536', '9', '520', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('537', '9', '525', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('538', '9', '499', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('539', '9', '498', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('540', '9', '497', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('541', '9', '496', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('542', '9', '494', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('543', '9', '491', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('544', '9', '490', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('545', '9', '519', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('546', '9', '518', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('547', '9', '517', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('548', '9', '516', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('549', '9', '515', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('550', '9', '514', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('551', '9', '513', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('552', '9', '512', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('553', '9', '511', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('554', '9', '510', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('555', '9', '509', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('556', '9', '508', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('557', '9', '507', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('558', '9', '506', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('559', '9', '505', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('560', '9', '545', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('561', '9', '544', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('562', '9', '542', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('563', '9', '541', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('564', '9', '540', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('565', '9', '539', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('566', '9', '538', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('567', '9', '537', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('568', '9', '536', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('569', '9', '535', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('570', '9', '534', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('571', '9', '533', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('572', '9', '532', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('573', '9', '531', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('574', '10', '546', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('575', '10', '566', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('576', '10', '565', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('577', '10', '564', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('578', '10', '563', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('579', '10', '562', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('580', '10', '561', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('581', '10', '560', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('582', '10', '559', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('583', '10', '558', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('584', '10', '557', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('585', '10', '556', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('586', '10', '555', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('587', '10', '554', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('588', '10', '553', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('589', '10', '552', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('622', '11', '418', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('623', '11', '431', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('624', '11', '495', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('625', '11', '492', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('626', '11', '489', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('627', '11', '488', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('628', '11', '484', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('629', '11', '482', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('630', '11', '479', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('631', '11', '476', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('632', '11', '470', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('633', '11', '469', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('634', '11', '467', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('635', '11', '465', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('636', '11', '464', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('637', '11', '461', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('638', '11', '459', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('639', '11', '457', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('640', '11', '455', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('641', '11', '453', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('642', '11', '451', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('643', '11', '449', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('644', '11', '447', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('645', '11', '445', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('646', '11', '443', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('647', '11', '441', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('648', '11', '440', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('649', '11', '428', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('650', '11', '427', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('651', '11', '425', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('652', '11', '424', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('653', '11', '422', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('654', '12', '338', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('655', '12', '399', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('656', '12', '396', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('657', '12', '394', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('658', '12', '393', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('659', '12', '390', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('660', '12', '388', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('661', '12', '386', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('662', '12', '383', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('663', '12', '379', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('664', '12', '377', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('665', '12', '375', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('666', '12', '372', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('667', '12', '371', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('668', '12', '369', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('669', '12', '367', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('670', '12', '363', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('671', '12', '362', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('672', '12', '359', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('673', '12', '358', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('674', '12', '354', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('675', '12', '351', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('676', '12', '349', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('677', '12', '416', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('678', '12', '415', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('679', '12', '413', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('680', '12', '412', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('681', '12', '411', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('708', '14', '150', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('709', '14', '231', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('710', '14', '227', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('711', '14', '225', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('712', '14', '220', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('713', '14', '218', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('714', '14', '214', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('715', '14', '212', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('716', '14', '210', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('717', '14', '209', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('718', '14', '207', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('719', '14', '205', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('720', '14', '203', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('721', '14', '201', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('722', '14', '199', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('723', '14', '197', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('724', '14', '195', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('725', '14', '193', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('726', '14', '190', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('727', '14', '187', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('728', '14', '185', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('729', '14', '183', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('730', '14', '180', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('731', '14', '179', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('732', '14', '178', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('733', '14', '177', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('734', '13', '234', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('735', '13', '295', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('736', '13', '309', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('737', '13', '293', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('738', '13', '291', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('739', '13', '290', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('740', '13', '288', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('741', '13', '286', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('742', '13', '284', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('743', '13', '283', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('744', '13', '282', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('745', '13', '279', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('746', '13', '277', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('747', '13', '275', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('748', '13', '274', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('749', '13', '272', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('750', '13', '270', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('751', '13', '267', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('752', '13', '265', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('753', '13', '263', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('754', '13', '261', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('755', '13', '257', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('756', '13', '255', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('757', '13', '254', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('758', '13', '252', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('759', '13', '250', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('760', '13', '248', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('761', '13', '246', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('762', '13', '335', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('763', '13', '332', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('764', '13', '329', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('765', '13', '328', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('766', '13', '326', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('767', '13', '321', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('768', '13', '319', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('769', '13', '317', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('770', '13', '315', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('771', '13', '307', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('772', '13', '304', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('773', '13', '302', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('774', '13', '300', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('775', '13', '298', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('843', '1', '17', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('844', '1', '20', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('845', '1', '120', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('846', '1', '119', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('847', '1', '118', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('848', '1', '117', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('849', '1', '116', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('850', '1', '115', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('851', '1', '114', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('852', '1', '113', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('853', '1', '112', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('854', '1', '59', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('855', '1', '58', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('856', '1', '111', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('857', '1', '57', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('858', '1', '56', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('859', '1', '55', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1089', '5', '338', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('1090', '5', '403', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('1091', '5', '446', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1092', '5', '444', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1093', '5', '442', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1094', '5', '439', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1095', '5', '436', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1096', '5', '434', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1097', '5', '430', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1098', '5', '429', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1099', '5', '426', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1100', '5', '423', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1101', '5', '421', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1102', '5', '419', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1103', '5', '417', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1104', '5', '414', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1105', '5', '396', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1106', '5', '394', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1107', '5', '393', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1108', '5', '390', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1109', '5', '388', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1110', '5', '386', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1111', '5', '383', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1112', '5', '375', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1113', '4', '186', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('1114', '4', '152', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('1115', '4', '223', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1116', '4', '222', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1117', '4', '221', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1118', '4', '219', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1119', '4', '217', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1120', '4', '216', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1121', '4', '215', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1122', '4', '213', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1123', '4', '211', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1124', '4', '208', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1125', '4', '206', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1126', '4', '204', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1127', '4', '202', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1128', '4', '200', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1129', '4', '198', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1130', '4', '196', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1131', '4', '184', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1132', '4', '182', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1133', '4', '181', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1134', '2', '312', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('1135', '2', '352', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('1136', '2', '546', '1');
INSERT INTO `Himall_HomeCategories` VALUES ('1137', '2', '350', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1138', '2', '348', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1139', '2', '346', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1140', '2', '343', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1141', '2', '342', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1142', '2', '339', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1143', '2', '337', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1144', '2', '336', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1145', '2', '334', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1146', '2', '331', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1147', '2', '330', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1148', '2', '327', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1149', '2', '325', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1150', '2', '324', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1151', '2', '323', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1152', '2', '376', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1153', '2', '374', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1154', '2', '373', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1155', '2', '370', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1156', '2', '368', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1157', '2', '364', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1158', '2', '361', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1159', '2', '360', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1160', '2', '357', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1161', '2', '566', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1162', '2', '565', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1163', '2', '564', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1164', '2', '563', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1165', '2', '562', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1166', '2', '561', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1167', '2', '560', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1168', '2', '559', '3');
INSERT INTO `Himall_HomeCategories` VALUES ('1169', '2', '558', '3');

-- ----------------------------
-- Table structure for Himall_HomeCategoryRows
-- ----------------------------
DROP TABLE IF EXISTS `Himall_HomeCategoryRows`;
CREATE TABLE `Himall_HomeCategoryRows` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `RowId` int(11) NOT NULL,
  `Image1` varchar(100) NOT NULL,
  `Url1` varchar(100) NOT NULL,
  `Image2` varchar(100) NOT NULL,
  `Url2` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_HomeCategoryRows
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_HomeFloors
-- ----------------------------
DROP TABLE IF EXISTS `Himall_HomeFloors`;
CREATE TABLE `Himall_HomeFloors` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FloorName` varchar(100) NOT NULL,
  `SubName` varchar(100) DEFAULT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `IsShow` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_HomeFloors
-- ----------------------------
INSERT INTO `Himall_HomeFloors` VALUES ('1', '服饰鞋包', null, '1', '1');
INSERT INTO `Himall_HomeFloors` VALUES ('2', '食品保健', null, '2', '1');
INSERT INTO `Himall_HomeFloors` VALUES ('3', '图书音像', null, '3', '0');
INSERT INTO `Himall_HomeFloors` VALUES ('4', '手机数码', null, '4', '1');
INSERT INTO `Himall_HomeFloors` VALUES ('5', '个人护理', null, '5', '1');
INSERT INTO `Himall_HomeFloors` VALUES ('7', '日化百货', null, '6', '1');

-- ----------------------------
-- Table structure for Himall_ImageAds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ImageAds`;
CREATE TABLE `Himall_ImageAds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ImageUrl` varchar(100) NOT NULL,
  `Url` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ImageAds
-- ----------------------------
INSERT INTO `Himall_ImageAds` VALUES ('1', '0', '/Storage/Plat/ImageAd/201411271922228999734.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('2', '0', '/Storage/Plat/ImageAd/201411271924231094774.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('3', '0', '/Storage/Plat/ImageAd/201411271924294978926.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('4', '0', '/Storage/Plat/ImageAd/201411271924378518505.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('5', '0', '/Storage/Plat/ImageAd/201411271926118702550.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('6', '0', '/Storage/Plat/ImageAd/201411271924581698733.png', '/');
INSERT INTO `Himall_ImageAds` VALUES ('7', '0', '/Storage/Plat/ImageAd/201411271925052044514.png', '/');
INSERT INTO `Himall_ImageAds` VALUES ('8', '0', '/Storage/Plat/ImageAd/201411271925115289451.png', '/');
INSERT INTO `Himall_ImageAds` VALUES ('9', '0', '/Storage/Plat/ImageAd/201411271925179346361.png', '/');
INSERT INTO `Himall_ImageAds` VALUES ('10', '0', '/Storage/Plat/ImageAd/201411051538294152167.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('11', '0', '/Storage/Plat/ImageAd/201411051538347344891.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('12', '0', '/Storage/Plat/ImageAd/201411051538401142128.jpg', '/');
INSERT INTO `Himall_ImageAds` VALUES ('13', '0', '/Storage/Plat/ImageAd/201411271923150932253.jpg', '/');

-- ----------------------------
-- Table structure for Himall_LimitTimeMarket
-- ----------------------------
DROP TABLE IF EXISTS `Himall_LimitTimeMarket`;
CREATE TABLE `Himall_LimitTimeMarket` (
  `Id` bigint(20) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `CategoryName` varchar(100) NOT NULL,
  `AuditStatus` smallint(6) NOT NULL,
  `AuditTime` datetime NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `Price` decimal(18,0) NOT NULL,
  `RecentMonthPrice` decimal(18,0) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  `Stock` int(11) NOT NULL,
  `SaleCount` int(11) NOT NULL,
  `CancelReson` text NOT NULL,
  `MaxSaleCount` int(11) NOT NULL,
  `ProductAd` varchar(100) NOT NULL,
  `MinPrice` decimal(18,0) NOT NULL,
  `ImagePath` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_LimitTimeMarket
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_Logs
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Logs`;
CREATE TABLE `Himall_Logs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `PageUrl` varchar(1000) NOT NULL,
  `Date` datetime NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `IPAddress` varchar(100) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=1965 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Logs
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_Managers
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Managers`;
CREATE TABLE `Himall_Managers` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `RoleId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `PasswordSalt` varchar(100) NOT NULL,
  `CreateDate` datetime NOT NULL,
  `Remark` varchar(1000) DEFAULT NULL,
  `RealName` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Managers
-- ----------------------------
INSERT INTO `Himall_Managers` VALUES ('1', '1', '0', 'admin', '4fcda0a56d0533a2ee8d49bf74dafa58', '22fa104e-8b97-42e7-9883-234cd9308e8c', '2015-06-05 11:43:35', null, null);
INSERT INTO `Himall_Managers` VALUES ('2', '0', '0', 'admin', '203ff7f2dec78dda84c5d323ab3bc8bc', '4bb5263f-2aa2-4626-bcfc-f0d22b26011b', '2015-06-05 11:43:35', null, null);

-- ----------------------------
-- Table structure for Himall_MarketServiceRecord
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MarketServiceRecord`;
CREATE TABLE `Himall_MarketServiceRecord` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MarketServiceId` bigint(20) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_MarketServiceRecord_Himall_ActiveMarketService` (`MarketServiceId`),
  CONSTRAINT `FK_Himall_MarketServiceRecord_Himall_ActiveMarketService` FOREIGN KEY (`MarketServiceId`) REFERENCES `Himall_ActiveMarketService` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MarketServiceRecord
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MarketSetting
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MarketSetting`;
CREATE TABLE `Himall_MarketSetting` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TypeId` int(11) NOT NULL,
  `Price` decimal(18,0) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MarketSetting
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MarketSettingMeta
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MarketSettingMeta`;
CREATE TABLE `Himall_MarketSettingMeta` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `MarketId` int(11) NOT NULL,
  `MetaKey` varchar(100) NOT NULL,
  `MetaValue` text,
  PRIMARY KEY (`Id`),
  KEY `FK_Hiamll_MarketSettingMeta_ToSetting` (`MarketId`),
  CONSTRAINT `FK_Hiamll_MarketSettingMeta_ToSetting` FOREIGN KEY (`MarketId`) REFERENCES `Himall_MarketSetting` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MarketSettingMeta
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MemberContacts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberContacts`;
CREATE TABLE `Himall_MemberContacts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `UserType` int(11) NOT NULL,
  `ServiceProvider` varchar(40) NOT NULL,
  `Contact` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MemberContacts
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MemberGrade
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberGrade`;
CREATE TABLE `Himall_MemberGrade` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `GradeName` varchar(100) NOT NULL,
  `Integral` int(11) NOT NULL,
  `Remark` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MemberGrade
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MemberIntegral
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegral`;
CREATE TABLE `Himall_MemberIntegral` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MemberId` bigint(20) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `HistoryIntegrals` int(11) NOT NULL,
  `AvailableIntegrals` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_MemberIntegral` (`MemberId`),
  CONSTRAINT `FK_Member_MemberIntegral` FOREIGN KEY (`MemberId`) REFERENCES `Himall_Members` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MemberIntegral
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MemberIntegralExchangeRules
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegralExchangeRules`;
CREATE TABLE `Himall_MemberIntegralExchangeRules` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `IntegralPerMoney` int(11) NOT NULL,
  `MoneyPerIntegral` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MemberIntegralExchangeRules
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MemberIntegralRecord
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegralRecord`;
CREATE TABLE `Himall_MemberIntegralRecord` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `MemberId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `TypeId` int(11) NOT NULL,
  `Integral` int(11) NOT NULL,
  `RecordDate` datetime DEFAULT NULL,
  `ReMark` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_MemberId_Members` (`MemberId`) USING BTREE,
  CONSTRAINT `himall_memberintegralrecord_ibfk_1` FOREIGN KEY (`MemberId`) REFERENCES `Himall_Members` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MemberIntegralRecord
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MemberIntegralRecordAction
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegralRecordAction`;
CREATE TABLE `Himall_MemberIntegralRecordAction` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `IntegralRecordId` bigint(20) NOT NULL,
  `VirtualItemTypeId` int(11) DEFAULT NULL,
  `VirtualItemId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_IntegralRecordId_MemberIntegralRecord` (`IntegralRecordId`) USING BTREE,
  CONSTRAINT `himall_memberintegralrecordaction_ibfk_1` FOREIGN KEY (`IntegralRecordId`) REFERENCES `Himall_MemberIntegralRecord` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MemberIntegralRecordAction
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MemberIntegralRule
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberIntegralRule`;
CREATE TABLE `Himall_MemberIntegralRule` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TypeId` int(11) NOT NULL,
  `Integral` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MemberIntegralRule
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MemberOpenIds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MemberOpenIds`;
CREATE TABLE `Himall_MemberOpenIds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `OpenId` varchar(100) NOT NULL,
  `ServiceProvider` varchar(40) NOT NULL,
  `AppIdType` int(255) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_MemberOpenId` (`UserId`) USING BTREE,
  CONSTRAINT `himall_memberopenids_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MemberOpenIds
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_Members
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Members`;
CREATE TABLE `Himall_Members` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `PasswordSalt` varchar(100) NOT NULL,
  `Nick` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `CreateDate` datetime NOT NULL,
  `TopRegionId` int(11) NOT NULL,
  `RegionId` int(11) NOT NULL,
  `RealName` varchar(100) DEFAULT NULL,
  `CellPhone` varchar(100) DEFAULT NULL,
  `QQ` varchar(100) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Disabled` tinyint(1) NOT NULL,
  `LastLoginDate` datetime NOT NULL,
  `OrderNumber` int(11) NOT NULL,
  `Expenditure` decimal(8,2) NOT NULL,
  `Points` int(11) NOT NULL,
  `Photo` varchar(100) DEFAULT NULL,
  `ParentSellerId` bigint(20) NOT NULL DEFAULT '0',
  `Remark` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Members
-- ----------------------------
INSERT INTO `Himall_Members` VALUES ('1', 'Test', '69f66c7df1620005b3303d320ea07caa', '4caa8b4452974693f7a2', 'Test', null, '2014-10-31 16:47:14', '0', '0', null, null, null, null, '0', '2014-11-27 16:16:16', '0', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('2', 'zjjsuper', '6b3791b13d00a45d0e8b9a2269893a52', '4f829c536b9c4d077c3d', 'zjjsuper', null, '2014-11-27 16:09:32', '0', '0', null, null, null, null, '0', '2014-11-28 11:10:28', '2', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('3', 'abcd', 'dcf5518385936c1ea0c71fb470d27840', '4fe3b78636c3708b6cf0', 'abcd', null, '2014-11-27 21:52:32', '0', '0', null, null, null, null, '0', '2014-11-27 21:52:42', '2', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('4', 'xielingxiao', '3cea5f055bc6bdf8eceb1bb141d18ce2', '41ddb41ad9d4af75521f', 'xielingxiao', null, '2014-11-28 11:11:21', '0', '0', null, null, null, null, '0', '2014-12-01 09:12:36', '18', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('5', 'yangzhenhua', '3a37390226b1657608741e79137c18c0', '40648758c525fb66782b', 'yangzhenhua', null, '2014-11-28 11:11:24', '0', '0', null, null, null, null, '0', '2014-11-28 17:13:34', '1', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('6', 'ATest', '623bb3c864f749efeb0b686be5bf6f10', '4d84a0698234069d0ef4', 'ATest', null, '2014-11-28 12:40:11', '0', '0', null, null, null, null, '0', '2014-11-28 12:40:21', '0', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('7', 'ceshi01', '8a4ffe09befde4419545d1f896a7aa62', '43dcb460cd4dbf12e382', 'ceshi01', null, '2014-11-28 14:54:39', '0', '0', null, null, null, null, '0', '2014-11-28 14:54:49', '1', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('8', 'zesion', '0194b575bbfd7f6098a2abd664cbbe8f', '487880e7b8d17afa6775', 'zesion', null, '2014-11-28 15:22:48', '0', '0', null, null, null, null, '0', '2014-11-28 16:45:14', '2', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('9', 'rilong', '078ea3d2fde92fa73375a41cf40aaffa', '47a3ad328cd6893a064f', 'rilong', null, '2014-11-28 16:16:08', '0', '0', null, null, null, null, '0', '2014-12-01 20:05:53', '2', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('10', 'user', 'f18cb5d271a6864ca4ef9d2fac7f4b7f', '42c8a92b485be105a6af', '刘磊', 'liulei2983@qq.com', '2014-11-28 16:42:26', '0', '0', '刘磊', null, '414871659', null, '0', '2014-12-01 08:54:20', '17', '-3598.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('11', 'admin', '770571d08864f6a688b71cd279cf0605', '495b92f7a53380024cff', 'admin', null, '2014-11-28 16:43:48', '0', '0', null, null, null, null, '0', '2014-11-29 09:35:44', '3', '-990.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('12', 'rollinquentin', '282722e4fb10036a62d0ac628497e92a', '4469a274710bcb305952', 'rollinquentin', null, '2014-11-28 21:58:12', '0', '0', null, null, null, null, '0', '2014-11-28 21:58:27', '2', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('13', 'haoqi', 'f5d412832dd8136e0b2d5df8ec699e2c', '47879a6efe58636d6e01', 'haoqi', null, '2014-11-29 11:27:34', '0', '0', null, null, null, null, '0', '2014-11-29 11:27:54', '2', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('14', 'Heron1957', 'd1cee3e549a9faba02172d967146bc66', '488fa7c808a6dd6c5be6', 'Heron1957', null, '2014-11-29 11:28:14', '0', '0', null, null, null, null, '0', '2014-12-01 08:13:01', '5', '-1998.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('15', 'Kemvion', '2463f31ff6be62d529117475dcc1d377', '453587500144bd5de393', 'Kemvion', null, '2014-11-29 11:29:53', '0', '0', null, null, null, null, '0', '2014-11-29 21:50:35', '6', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('16', '爬向金字塔的蜗牛', '2516be98d5c93d3fd0dc6578e8975317', '4413aa503b1030dae173', '爬向金字塔的蜗牛', null, '2014-11-29 14:08:15', '0', '0', null, null, null, null, '0', '2014-11-29 14:08:47', '1', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('17', '笑一笑吧', '0559cac2d3e7a3c3ca9f1258cc1dc497', '40858854e477063403e5', '笑一笑吧', null, '2014-11-29 14:34:29', '0', '0', null, null, null, null, '0', '2014-11-29 14:34:42', '1', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('18', '公子十七', '7761a00b14b27ed9db14772e2cd20a26', '41deb9e0086b88eca666', '公子十七', null, '2014-11-29 14:41:12', '0', '0', null, null, null, null, '0', '2014-11-29 17:40:43', '8', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('19', '一桶江湖', '37b844c6eed7334670e66c98f3c7102d', '495e977fa589105c24ed', '一桶江湖', null, '2014-11-29 14:55:55', '0', '0', null, null, null, null, '0', '2014-11-29 14:56:07', '1', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('20', '410957650', '188082d61213ac2a320ea09d35386680', '41a5a1a906dc0f1984f0', '范冰冰', null, '2014-11-29 15:10:55', '0', '0', null, null, null, null, '0', '2014-11-29 15:11:02', '19', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('21', '谢凌霄1', 'c8d6c76057e9817f0e84b2a203f6e051', '4a70945affc894e4db74', '谢凌霄1', null, '2014-11-29 15:21:16', '0', '0', null, null, null, null, '0', '2014-11-29 17:37:28', '17', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('22', '谢凌霄2', 'e4f948504ab3a35b40e4477aefcff40c', '4f3b89230ccbaf4c123f', '谢凌霄2', null, '2014-11-29 16:13:42', '0', '0', null, null, null, null, '0', '2014-11-29 17:32:43', '15', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('23', '谢凌霄3', '41332b9df6e280728a8de3df0f7f7f83', '4daa9f58ecd9a9f903c4', '谢凌霄3', null, '2014-11-29 16:26:41', '0', '0', null, null, null, null, '0', '2014-11-29 16:27:06', '17', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('24', '龙将军痞子', '3453f407efc0e0e153fec17357395580', '4ec7a9482282904f3eb7', '龙将军痞子', null, '2014-11-29 22:16:26', '0', '0', null, null, null, null, '0', '2014-11-29 22:20:18', '2', '0.00', '0', null, '0', null);
INSERT INTO `Himall_Members` VALUES ('25', '飞翔的雨', '54e9c3fda2c7805d94a5a2c96f3ddcd5', '4d029ccf17a77a203519', '飞翔的雨', null, '2014-11-29 23:09:04', '0', '0', null, null, null, null, '0', '2014-11-29 23:09:12', '0', '0.00', '0', null, '0', null);

-- ----------------------------
-- Table structure for Himall_Menus
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Menus`;
CREATE TABLE `Himall_Menus` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParentId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `Title` varchar(10) NOT NULL,
  `Url` varchar(200) DEFAULT NULL,
  `Depth` smallint(6) NOT NULL,
  `Sequence` smallint(6) NOT NULL,
  `FullIdPath` varchar(100) NOT NULL,
  `Platform` int(11) NOT NULL,
  `UrlType` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Menus
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MessageLog
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MessageLog`;
CREATE TABLE `Himall_MessageLog` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) DEFAULT NULL,
  `TypeId` varchar(100) DEFAULT NULL,
  `MessageContent` char(1) DEFAULT NULL,
  `SendTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=718 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MessageLog
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MobileHomeProducts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MobileHomeProducts`;
CREATE TABLE `Himall_MobileHomeProducts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `PlatFormType` int(11) NOT NULL,
  `Sequence` smallint(6) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Himall_MobileHomeProducts_Himall_Products` (`ProductId`),
  CONSTRAINT `FK_Himall_MobileHomeProducts_Himall_Products` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MobileHomeProducts
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_MobileHomeTopics
-- ----------------------------
DROP TABLE IF EXISTS `Himall_MobileHomeTopics`;
CREATE TABLE `Himall_MobileHomeTopics` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL DEFAULT '0',
  `Platform` int(11) NOT NULL,
  `TopicId` bigint(20) NOT NULL,
  `Sequence` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `FK__Himall_Mo__Topic__02C769E9` (`TopicId`),
  CONSTRAINT `FK__Himall_Mo__Topic__02C769E9` FOREIGN KEY (`TopicId`) REFERENCES `Himall_Topics` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_MobileHomeTopics
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ModuleProducts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ModuleProducts`;
CREATE TABLE `Himall_ModuleProducts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ModuleId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ModuleProduct` (`ProductId`) USING BTREE,
  KEY `FK_TopicModule_ModuleProduct` (`ModuleId`) USING BTREE,
  CONSTRAINT `himall_moduleproducts_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_moduleproducts_ibfk_2` FOREIGN KEY (`ModuleId`) REFERENCES `Himall_TopicModules` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ModuleProducts
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_OrderComments
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderComments`;
CREATE TABLE `Himall_OrderComments` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `CommentDate` datetime NOT NULL,
  `PackMark` int(11) NOT NULL,
  `DeliveryMark` int(11) NOT NULL,
  `ServiceMark` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Order_OrderComment` (`OrderId`) USING BTREE,
  CONSTRAINT `himall_ordercomments_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `Himall_Orders` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_OrderComments
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_OrderComplaints
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderComplaints`;
CREATE TABLE `Himall_OrderComplaints` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `Status` int(11) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `ShopPhone` varchar(20) NOT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `UserPhone` varchar(20) DEFAULT NULL,
  `ComplaintDate` datetime NOT NULL,
  `ComplaintReason` varchar(1000) NOT NULL,
  `SellerReply` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Order_OrderComplaint` (`OrderId`) USING BTREE,
  CONSTRAINT `himall_ordercomplaints_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `Himall_Orders` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_OrderComplaints
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_OrderItems
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderItems`;
CREATE TABLE `Himall_OrderItems` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `SkuId` varchar(100) DEFAULT NULL,
  `SKU` varchar(20) DEFAULT NULL,
  `Quantity` bigint(20) NOT NULL,
  `ReturnQuantity` bigint(20) NOT NULL,
  `CostPrice` decimal(8,2) NOT NULL,
  `SalePrice` decimal(8,2) NOT NULL,
  `DiscountAmount` decimal(8,2) NOT NULL,
  `RealTotalPrice` decimal(8,2) NOT NULL,
  `RefundPrice` decimal(8,2) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `Color` varchar(100) DEFAULT NULL,
  `Size` varchar(100) DEFAULT NULL,
  `Version` varchar(100) DEFAULT NULL,
  `ThumbnailsUrl` varchar(100) DEFAULT NULL,
  `CommisRate` decimal(8,2) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Order_OrderItem` (`OrderId`) USING BTREE,
  CONSTRAINT `himall_orderitems_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `Himall_Orders` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1344 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_OrderItems
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_OrderOperationLogs
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderOperationLogs`;
CREATE TABLE `Himall_OrderOperationLogs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `Operator` varchar(100) NOT NULL,
  `OperateDate` datetime NOT NULL,
  `OperateContent` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Order_OrderOperationLog` (`OrderId`) USING BTREE,
  CONSTRAINT `himall_orderoperationlogs_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `Himall_Orders` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=884 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_OrderOperationLogs
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_OrderRefunds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_OrderRefunds`;
CREATE TABLE `Himall_OrderRefunds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OrderId` bigint(20) NOT NULL,
  `OrderItemId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `UserId` bigint(20) NOT NULL,
  `Applicant` varchar(100) NOT NULL,
  `ContactPerson` varchar(100) DEFAULT NULL,
  `ContactCellPhone` varchar(100) DEFAULT NULL,
  `RefundAccount` varchar(100) DEFAULT NULL,
  `ApplyDate` datetime NOT NULL,
  `Amount` decimal(8,2) NOT NULL,
  `Reason` varchar(1000) NOT NULL,
  `SellerAuditStatus` int(11) NOT NULL,
  `SellerAuditDate` datetime NOT NULL,
  `SellerRemark` varchar(1000) DEFAULT NULL,
  `ManagerConfirmStatus` int(11) NOT NULL,
  `ManagerConfirmDate` datetime NOT NULL,
  `ManagerRemark` varchar(1000) DEFAULT NULL,
  `IsReturn` tinyint(1) NOT NULL,
  `ExpressCompanyName` varchar(100) DEFAULT NULL,
  `ShipOrderNumber` varchar(100) DEFAULT NULL,
  `Payee` varchar(200) DEFAULT NULL,
  `PayeeAccount` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_OrderItem_OrderRefund` (`OrderItemId`) USING BTREE,
  CONSTRAINT `himall_orderrefunds_ibfk_1` FOREIGN KEY (`OrderItemId`) REFERENCES `Himall_OrderItems` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_OrderRefunds
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_Orders
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Orders`;
CREATE TABLE `Himall_Orders` (
  `Id` bigint(20) NOT NULL,
  `OrderStatus` int(11) NOT NULL,
  `OrderDate` datetime NOT NULL,
  `CloseReason` varchar(1000) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `SellerPhone` varchar(20) DEFAULT NULL,
  `SellerAddress` varchar(100) DEFAULT NULL,
  `SellerRemark` varchar(1000) DEFAULT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `UserRemark` varchar(1000) DEFAULT NULL,
  `ShipTo` varchar(100) NOT NULL,
  `CellPhone` varchar(20) DEFAULT NULL,
  `TopRegionId` int(11) NOT NULL,
  `RegionId` int(11) NOT NULL,
  `RegionFullName` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `ExpressCompanyName` varchar(100) DEFAULT NULL,
  `Freight` decimal(8,2) NOT NULL,
  `ShipOrderNumber` varchar(100) DEFAULT NULL,
  `ShippingDate` datetime DEFAULT NULL,
  `IsPrinted` tinyint(1) NOT NULL,
  `PaymentTypeName` varchar(100) DEFAULT NULL,
  `PaymentTypeGateway` varchar(100) DEFAULT NULL,
  `GatewayOrderId` varchar(100) DEFAULT NULL,
  `PayRemark` varchar(1000) DEFAULT NULL,
  `PayDate` datetime DEFAULT NULL,
  `InvoiceType` int(11) NOT NULL,
  `InvoiceTitle` varchar(100) DEFAULT NULL,
  `Tax` decimal(8,2) NOT NULL,
  `FinishDate` datetime DEFAULT NULL,
  `ProductTotalAmount` decimal(8,2) NOT NULL,
  `RefundTotalAmount` decimal(8,2) NOT NULL,
  `CommisTotalAmount` decimal(8,2) NOT NULL,
  `RefundCommisAmount` decimal(8,2) NOT NULL,
  `ActiveType` int(11) NOT NULL DEFAULT '0',
  `Platform` int(11) NOT NULL DEFAULT '0',
  `DiscountAmount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `IntegralDiscount` decimal(18,2) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Orders
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ProductAttributes
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductAttributes`;
CREATE TABLE `Himall_ProductAttributes` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProductId` bigint(20) NOT NULL,
  `AttributeId` bigint(20) NOT NULL,
  `ValueId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Attribute_ProductAttribute` (`AttributeId`) USING BTREE,
  KEY `FK_Product_ProductAttribute` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_productattributes_ibfk_1` FOREIGN KEY (`AttributeId`) REFERENCES `Himall_Attributes` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_productattributes_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4392 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ProductAttributes
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ProductComments
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductComments`;
CREATE TABLE `Himall_ProductComments` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `SubOrderId` bigint(20) DEFAULT NULL,
  `ProductId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) DEFAULT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `Email` varchar(1000) DEFAULT NULL,
  `ReviewContent` varchar(1000) DEFAULT NULL,
  `ReviewDate` datetime NOT NULL,
  `ReviewMark` int(11) NOT NULL,
  `ReplyContent` varchar(1000) DEFAULT NULL,
  `ReplyDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ProductComment` (`ProductId`) USING BTREE,
  KEY `SubOrderId` (`SubOrderId`) USING BTREE,
  KEY `ShopId` (`ShopId`) USING BTREE,
  KEY `UserId` (`UserId`) USING BTREE,
  CONSTRAINT `himall_productcomments_ibfk_1` FOREIGN KEY (`SubOrderId`) REFERENCES `Himall_OrderItems` (`Id`),
  CONSTRAINT `himall_productcomments_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`),
  CONSTRAINT `himall_productcomments_ibfk_3` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`),
  CONSTRAINT `himall_productcomments_ibfk_4` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=359 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ProductComments
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ProductConsultations
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductConsultations`;
CREATE TABLE `Himall_ProductConsultations` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProductId` bigint(20) NOT NULL,
  `ShopId` bigint(20) NOT NULL,
  `ShopName` varchar(100) DEFAULT NULL,
  `UserId` bigint(20) NOT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `Email` varchar(1000) DEFAULT NULL,
  `ConsultationContent` varchar(1000) DEFAULT NULL,
  `ConsultationDate` datetime NOT NULL,
  `ReplyContent` varchar(1000) DEFAULT NULL,
  `ReplyDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ProductConsultation` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_productconsultations_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ProductConsultations
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ProductDescriptions
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductDescriptions`;
CREATE TABLE `Himall_ProductDescriptions` (
  `Id` bigint(20) DEFAULT NULL,
  `ProductId` bigint(20) NOT NULL,
  `AuditReason` varchar(1000) DEFAULT NULL,
  `Description` text,
  `DescriptionPrefixId` bigint(20) NOT NULL,
  `DescriptiondSuffixId` bigint(20) NOT NULL,
  `Meta_Title` varchar(1000) DEFAULT NULL,
  `Meta_Description` varchar(1000) DEFAULT NULL,
  `Meta_Keywords` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ProductId`),
  KEY `FK_Product_ProductDescription` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_productdescriptions_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ProductDescriptions
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ProductDescriptionTemplates
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductDescriptionTemplates`;
CREATE TABLE `Himall_ProductDescriptionTemplates` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Position` int(11) NOT NULL,
  `Content` varchar(4000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ProductDescriptionTemplates
-- ----------------------------
INSERT INTO `Himall_ProductDescriptionTemplates` VALUES ('1', '4', 'q341', '2', '<p>213123123</p>');

-- ----------------------------
-- Table structure for Himall_Products
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Products`;
CREATE TABLE `Himall_Products` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `CategoryId` bigint(20) NOT NULL,
  `CategoryPath` varchar(100) NOT NULL,
  `TypeId` bigint(20) NOT NULL,
  `BrandId` bigint(20) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `ProductCode` varchar(100) DEFAULT NULL,
  `ShortDescription` varchar(4000) DEFAULT NULL,
  `SaleStatus` int(11) NOT NULL,
  `AuditStatus` int(11) NOT NULL,
  `AddedDate` datetime NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `ImagePath` varchar(100) DEFAULT NULL,
  `MarketPrice` decimal(8,2) NOT NULL,
  `MinSalePrice` decimal(8,2) NOT NULL,
  `HasSKU` tinyint(1) NOT NULL,
  `VistiCounts` bigint(20) NOT NULL,
  `SaleCounts` bigint(20) NOT NULL,
  `FreightTemplateId` bigint(20) NOT NULL,
  `Weight` decimal(18,2) DEFAULT NULL,
  `Volume` decimal(18,2) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `MeasureUnit` varchar(20) DEFAULT NULL COMMENT '计量单位',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Products
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ProductShopCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductShopCategories`;
CREATE TABLE `Himall_ProductShopCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProductId` bigint(20) NOT NULL,
  `ShopCategoryId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ProductShopCategory` (`ProductId`) USING BTREE,
  KEY `FK_ShopCategory_ProductShopCategory` (`ShopCategoryId`) USING BTREE,
  CONSTRAINT `himall_productshopcategories_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_productshopcategories_ibfk_2` FOREIGN KEY (`ShopCategoryId`) REFERENCES `Himall_ShopCategories` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1305 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ProductShopCategories
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ProductVistis
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ProductVistis`;
CREATE TABLE `Himall_ProductVistis` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProductId` bigint(20) NOT NULL,
  `Date` datetime NOT NULL,
  `VistiCounts` bigint(20) NOT NULL,
  `SaleCounts` bigint(20) NOT NULL,
  `SaleAmounts` decimal(8,2) NOT NULL,
  `OrderCounts` bigint(20) unsigned DEFAULT '0' COMMENT '订单总数',
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ProductVisti` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_productvistis_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1336 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ProductVistis
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_RolePrivileges
-- ----------------------------
DROP TABLE IF EXISTS `Himall_RolePrivileges`;
CREATE TABLE `Himall_RolePrivileges` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Privilege` int(11) NOT NULL,
  `RoleId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Role_RolePrivilege` (`RoleId`) USING BTREE,
  CONSTRAINT `himall_roleprivileges_ibfk_1` FOREIGN KEY (`RoleId`) REFERENCES `Himall_Roles` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=424 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_RolePrivileges
-- ----------------------------
INSERT INTO `Himall_RolePrivileges` VALUES ('8', '2005', '2');
INSERT INTO `Himall_RolePrivileges` VALUES ('9', '2001', '1');
INSERT INTO `Himall_RolePrivileges` VALUES ('10', '2002', '1');
INSERT INTO `Himall_RolePrivileges` VALUES ('11', '2003', '1');
INSERT INTO `Himall_RolePrivileges` VALUES ('12', '2004', '1');
INSERT INTO `Himall_RolePrivileges` VALUES ('13', '2005', '1');
INSERT INTO `Himall_RolePrivileges` VALUES ('14', '2006', '1');
INSERT INTO `Himall_RolePrivileges` VALUES ('15', '2007', '1');
INSERT INTO `Himall_RolePrivileges` VALUES ('16', '2001', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('17', '2002', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('18', '2003', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('19', '2004', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('20', '2005', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('21', '2006', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('22', '2007', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('23', '3001', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('24', '3002', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('25', '3003', '3');
INSERT INTO `Himall_RolePrivileges` VALUES ('26', '3001', '4');
INSERT INTO `Himall_RolePrivileges` VALUES ('27', '3002', '4');
INSERT INTO `Himall_RolePrivileges` VALUES ('28', '3003', '4');
INSERT INTO `Himall_RolePrivileges` VALUES ('29', '3004', '4');
INSERT INTO `Himall_RolePrivileges` VALUES ('30', '3005', '4');
INSERT INTO `Himall_RolePrivileges` VALUES ('31', '3006', '4');

-- ----------------------------
-- Table structure for Himall_Roles
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Roles`;
CREATE TABLE `Himall_Roles` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `RoleName` varchar(100) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Roles
-- ----------------------------
INSERT INTO `Himall_Roles` VALUES ('1', '0', 'Test', 'Test');
INSERT INTO `Himall_Roles` VALUES ('2', '0', 'Topic', 'Topic');
INSERT INTO `Himall_Roles` VALUES ('3', '10', 'Test', 'Test');
INSERT INTO `Himall_Roles` VALUES ('4', '0', '财务', '财务');

-- ----------------------------
-- Table structure for Himall_SellerSpecificationValues
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SellerSpecificationValues`;
CREATE TABLE `Himall_SellerSpecificationValues` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ValueId` bigint(20) NOT NULL,
  `Specification` int(11) NOT NULL,
  `TypeId` bigint(20) NOT NULL,
  `Value` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_SpecificationValue_SellerSpecificationValue` (`ValueId`) USING BTREE,
  CONSTRAINT `himall_sellerspecificationvalues_ibfk_1` FOREIGN KEY (`ValueId`) REFERENCES `Himall_SpecificationValues` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_SellerSpecificationValues
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_SensitiveWords
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SensitiveWords`;
CREATE TABLE `Himall_SensitiveWords` (
  `Id` int(4) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `SensitiveWord` varchar(100) DEFAULT NULL COMMENT '敏感词',
  `CategoryName` varchar(100) DEFAULT NULL COMMENT '敏感词类别',
  PRIMARY KEY (`Id`),
  KEY `Id` (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_SensitiveWords
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ShippingAddresses
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShippingAddresses`;
CREATE TABLE `Himall_ShippingAddresses` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `RegionId` int(11) NOT NULL,
  `ShipTo` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `IsDefault` tinyint(1) NOT NULL,
  `IsQuick` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_ShippingAddress` (`UserId`) USING BTREE,
  CONSTRAINT `himall_shippingaddresses_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ShippingAddresses
-- ----------------------------
INSERT INTO `Himall_ShippingAddresses` VALUES ('1', '2', '254', '张三', '韶山北路139号湖南文化大厦B座19楼1915-19室', '18988737766', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('2', '3', '218', 'bbbb', '23423423', '2432423', '1', '1');
INSERT INTO `Himall_ShippingAddresses` VALUES ('3', '7', '215', '张运峰', '阿斯顿撒旦法撒旦法撒旦法', '13523568978', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('4', '8', '215', 'dddd', 'dddddddd', '15874101134', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('6', '11', '118', '1231231', 'sdfsdfsdf', '123123123123', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('7', '4', '265', 'xielingxiao', 'xielingxiao', '18456456123', '1', '1');
INSERT INTO `Himall_ShippingAddresses` VALUES ('8', '9', '398', '廖日龙', 'ABD', '13655201147', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('9', '5', '1667', '杨振华', '东风一村 54栋 东风小学对面', '18354632145', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('10', '12', '1665', '小王', '四方坪', '13565000', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('11', '13', '104', '小子', '228号', '15211128868', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('12', '15', '1666', '阳莉', '绿地集团', '13755053087', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('13', '14', '217', '李花', 'ADO大厦', '13544120069', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('15', '16', '105', '笑笑', '228', '15211129949', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('16', '18', '217', '谢凌霄', '蓄势待发', '12312345611', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('17', '17', '153', '三爷', '222', '15211129949', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('18', '19', '1679', '二叔', '12', '15211129949', '1', '0');
INSERT INTO `Himall_ShippingAddresses` VALUES ('19', '20', '1052', '范冰冰', '三王旗A区21栋C单元3702', '18954623154', '1', '1');
INSERT INTO `Himall_ShippingAddresses` VALUES ('20', '21', '533', '谢凌霄', '234', '2341233123', '1', '1');
INSERT INTO `Himall_ShippingAddresses` VALUES ('21', '22', '667', '谢凌霄', '234', '1234123123', '1', '1');
INSERT INTO `Himall_ShippingAddresses` VALUES ('22', '23', '254', '谢凌霄', '123', '12312312312', '1', '1');
INSERT INTO `Himall_ShippingAddresses` VALUES ('23', '24', '533', '欧诺个龙', 'ADO', '13400987754', '1', '0');

-- ----------------------------
-- Table structure for Himall_ShopBrandApplys
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopBrandApplys`;
CREATE TABLE `Himall_ShopBrandApplys` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `ShopId` bigint(20) NOT NULL COMMENT '商家Id',
  `BrandId` bigint(20) DEFAULT NULL COMMENT '品牌Id',
  `BrandName` varchar(100) DEFAULT NULL COMMENT '品牌名称',
  `Logo` varchar(1000) DEFAULT NULL COMMENT '品牌Logo',
  `Description` varchar(1000) DEFAULT NULL COMMENT '描述',
  `AuthCertificate` varchar(4000) DEFAULT NULL COMMENT '品牌授权证书',
  `ApplyMode` int(11) NOT NULL COMMENT '申请类型 枚举 BrandApplyMode',
  `Remark` varchar(1000) DEFAULT NULL COMMENT '备注',
  `AuditStatus` int(11) NOT NULL COMMENT '审核状态 枚举 BrandAuditStatus',
  `ApplyTime` datetime NOT NULL COMMENT '操作时间',
  PRIMARY KEY (`Id`),
  KEY `FK_ShopId` (`ShopId`) USING BTREE,
  KEY `FK_BrandId` (`BrandId`) USING BTREE,
  KEY `Id` (`Id`) USING BTREE,
  CONSTRAINT `himall_shopbrandapplys_ibfk_1` FOREIGN KEY (`BrandId`) REFERENCES `Himall_Brands` (`Id`),
  CONSTRAINT `himall_shopbrandapplys_ibfk_2` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of Himall_ShopBrandApplys
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ShopBrands
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopBrands`;
CREATE TABLE `Himall_ShopBrands` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `ShopId` bigint(20) NOT NULL COMMENT '商家Id',
  `BrandId` bigint(20) NOT NULL COMMENT '品牌Id',
  PRIMARY KEY (`Id`),
  KEY `ShopId` (`ShopId`) USING BTREE,
  KEY `BrandId` (`BrandId`) USING BTREE,
  KEY `Id` (`Id`) USING BTREE,
  CONSTRAINT `himall_shopbrands_ibfk_1` FOREIGN KEY (`BrandId`) REFERENCES `Himall_Brands` (`Id`),
  CONSTRAINT `himall_shopbrands_ibfk_2` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of Himall_ShopBrands
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ShopCategories
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopCategories`;
CREATE TABLE `Himall_ShopCategories` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ParentCategoryId` bigint(20) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `IsShow` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=274 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ShopCategories
-- ----------------------------
INSERT INTO `Himall_ShopCategories` VALUES ('1', '1', '0', '男士专区', '1', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('24', '1', '0', '女装', '7', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('25', '1', '24', '新品', '1', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('26', '1', '24', '爆款', '2', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('34', '1', '1', '男鞋', '4', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('35', '1', '1', '男装', '5', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('39', '1', '0', '箱包', '10', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('40', '1', '39', '休闲包', '1', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('41', '1', '39', '商务包', '2', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('60', '1', '0', '数码产品', '15', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('61', '1', '60', '手机', '1', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('68', '1', '0', '食品', '17', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('70', '1', '68', '进口零食', '2', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('71', '1', '0', '图书', '17', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('74', '1', '0', '护肤品', '16', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('84', '1', '68', '水果', '3', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('131', '1', '0', '家电', '25', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('132', '6', '0', '储存卡', '26', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('133', '8', '0', '平板', '27', '1');
INSERT INTO `Himall_ShopCategories` VALUES ('134', '10', '0', '美特斯邦威', '28', '1');

-- ----------------------------
-- Table structure for Himall_ShopGrades
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopGrades`;
CREATE TABLE `Himall_ShopGrades` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `ProductLimit` int(11) NOT NULL,
  `ImageLimit` int(11) NOT NULL,
  `TemplateLimit` int(11) NOT NULL,
  `ChargeStandard` decimal(8,2) NOT NULL,
  `Remark` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ShopGrades
-- ----------------------------
INSERT INTO `Himall_ShopGrades` VALUES ('1', '白金店铺', '500', '500', '500', '500.00', null);
INSERT INTO `Himall_ShopGrades` VALUES ('2', '钻石店铺', '1000', '1000', '1000', '1000.00', null);

-- ----------------------------
-- Table structure for Himall_ShopHomeModuleProducts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopHomeModuleProducts`;
CREATE TABLE `Himall_ShopHomeModuleProducts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `HomeModuleId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_ShopHomeModuleProduct` (`ProductId`) USING BTREE,
  KEY `FK_ShopHomeModule_ShopHomeModuleProduct` (`HomeModuleId`) USING BTREE,
  CONSTRAINT `himall_shophomemoduleproducts_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_shophomemoduleproducts_ibfk_2` FOREIGN KEY (`HomeModuleId`) REFERENCES `Himall_ShopHomeModules` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ShopHomeModuleProducts
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_ShopHomeModules
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopHomeModules`;
CREATE TABLE `Himall_ShopHomeModules` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ShopHomeModules
-- ----------------------------
INSERT INTO `Himall_ShopHomeModules` VALUES ('1', '1', '精品推荐');
INSERT INTO `Himall_ShopHomeModules` VALUES ('2', '5', '洗发护发');
INSERT INTO `Himall_ShopHomeModules` VALUES ('3', '5', '身体护理');
INSERT INTO `Himall_ShopHomeModules` VALUES ('4', '1', '服装精选');
INSERT INTO `Himall_ShopHomeModules` VALUES ('5', '1', '箱包');
INSERT INTO `Himall_ShopHomeModules` VALUES ('6', '4', '精品推荐');
INSERT INTO `Himall_ShopHomeModules` VALUES ('7', '5', '女性护理');
INSERT INTO `Himall_ShopHomeModules` VALUES ('8', '5', '口腔护理');
INSERT INTO `Himall_ShopHomeModules` VALUES ('9', '5', '面部护肤');
INSERT INTO `Himall_ShopHomeModules` VALUES ('10', '5', '礼品套装');
INSERT INTO `Himall_ShopHomeModules` VALUES ('11', '4', '手机配件');
INSERT INTO `Himall_ShopHomeModules` VALUES ('12', '4', '数码配件');
INSERT INTO `Himall_ShopHomeModules` VALUES ('13', '3', '运动服饰');
INSERT INTO `Himall_ShopHomeModules` VALUES ('14', '3', '精品推荐');
INSERT INTO `Himall_ShopHomeModules` VALUES ('15', '4', '新商品');

-- ----------------------------
-- Table structure for Himall_ShoppingCarts
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShoppingCarts`;
CREATE TABLE `Himall_ShoppingCarts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserId` bigint(20) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `SkuId` varchar(100) DEFAULT NULL,
  `Quantity` bigint(20) NOT NULL,
  `AddTime` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Member_ShoppingCart` (`UserId`) USING BTREE,
  KEY `FK_Product_ShoppingCart` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_shoppingcarts_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `Himall_Members` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_shoppingcarts_ibfk_2` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ShoppingCarts
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_Shops
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Shops`;
CREATE TABLE `Himall_Shops` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `GradeId` bigint(20) NOT NULL,
  `ShopName` varchar(100) NOT NULL,
  `Logo` varchar(100) DEFAULT NULL,
  `SubDomains` varchar(100) DEFAULT NULL,
  `Theme` varchar(100) DEFAULT NULL,
  `IsSelf` tinyint(1) NOT NULL,
  `ShopStatus` int(11) NOT NULL,
  `RefuseReason` varchar(1000) DEFAULT NULL,
  `CreateDate` datetime NOT NULL,
  `EndDate` datetime DEFAULT NULL,
  `CompanyName` varchar(100) DEFAULT NULL,
  `CompanyRegionId` int(11) NOT NULL,
  `CompanyAddress` varchar(100) DEFAULT NULL,
  `CompanyPhone` varchar(20) DEFAULT NULL,
  `CompanyEmployeeCount` int(11) NOT NULL,
  `CompanyRegisteredCapital` decimal(8,2) NOT NULL,
  `ContactsName` varchar(100) DEFAULT NULL,
  `ContactsPhone` varchar(20) DEFAULT NULL,
  `ContactsEmail` varchar(100) DEFAULT NULL,
  `BusinessLicenceNumber` varchar(100) DEFAULT NULL,
  `BusinessLicenceNumberPhoto` varchar(100) NOT NULL,
  `BusinessLicenceRegionId` int(11) NOT NULL,
  `BusinessLicenceStart` datetime DEFAULT NULL,
  `BusinessLicenceEnd` datetime DEFAULT NULL,
  `BusinessSphere` varchar(100) DEFAULT NULL,
  `OrganizationCode` varchar(100) DEFAULT NULL,
  `OrganizationCodePhoto` varchar(100) DEFAULT NULL,
  `GeneralTaxpayerPhot` varchar(100) DEFAULT NULL,
  `BankAccountName` varchar(100) DEFAULT NULL,
  `BankAccountNumber` varchar(100) DEFAULT NULL,
  `BankName` varchar(100) DEFAULT NULL,
  `BankCode` varchar(100) DEFAULT NULL,
  `BankRegionId` int(11) NOT NULL,
  `BankPhoto` varchar(100) DEFAULT NULL,
  `TaxRegistrationCertificate` varchar(100) DEFAULT NULL,
  `TaxpayerId` varchar(100) DEFAULT NULL,
  `TaxRegistrationCertificatePhoto` varchar(100) DEFAULT NULL,
  `PayPhoto` varchar(100) DEFAULT NULL,
  `PayRemark` varchar(1000) DEFAULT NULL,
  `SenderName` varchar(100) DEFAULT NULL,
  `SenderAddress` varchar(100) DEFAULT NULL,
  `SenderPhone` varchar(100) DEFAULT NULL,
  `Freight` decimal(18,2) NOT NULL,
  `FreeFreight` decimal(18,2) NOT NULL,
  `Stage` int(11) DEFAULT '0',
  `SenderRegionId` int(11) DEFAULT NULL,
  `BusinessLicenseCert` varchar(120) DEFAULT NULL,
  `ProductCert` varchar(120) DEFAULT NULL,
  `OtherCert` varchar(120) DEFAULT NULL,
  `legalPerson` varchar(50) DEFAULT NULL COMMENT '法人代表',
  `CompanyFoundingDate` datetime DEFAULT NULL COMMENT '公司成立日期',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Shops
-- ----------------------------
INSERT INTO `Himall_Shops` VALUES ('1', '1', '官方自营店', null, null, null, '1', '6', null, '2014-10-30 00:00:00', '2014-12-12 00:00:00', '海商网络科技', '102', '文化大厦', '876588888', '1000', '1.00', '杨先生', '13988887748', 'Yang@hishop.com', '966587458', '1', '102', '2014-05-05 00:00:00', '2014-12-12 00:00:00', '1', '66548726', '1', '1', '杨先生', '6228445888796651200', '中国银行', '44698', '101', '1', '1', '33695', '1', '1', '1', '1', '1', '1', '11.00', '11.00', '5', '102', null, null, null, null, null);

-- ----------------------------
-- Table structure for Himall_ShopVistis
-- ----------------------------
DROP TABLE IF EXISTS `Himall_ShopVistis`;
CREATE TABLE `Himall_ShopVistis` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `Date` datetime NOT NULL,
  `VistiCounts` bigint(20) NOT NULL,
  `SaleCounts` bigint(20) NOT NULL,
  `SaleAmounts` decimal(8,2) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_ShopVistis
-- ----------------------------
INSERT INTO `Himall_ShopVistis` VALUES ('1', '1', '2014-11-27 00:00:00', '43', '0', '0.00');
INSERT INTO `Himall_ShopVistis` VALUES ('2', '1', '2014-11-28 00:00:00', '310', '13', '7668.00');
INSERT INTO `Himall_ShopVistis` VALUES ('7', '1', '2014-11-29 00:00:00', '214', '85', '103722.90');
INSERT INTO `Himall_ShopVistis` VALUES ('15', '1', '2014-11-30 00:00:00', '23', '0', '0.00');
INSERT INTO `Himall_ShopVistis` VALUES ('19', '1', '2014-12-01 00:00:00', '9', '0', '0.00');

-- ----------------------------
-- Table structure for Himall_SiteSettings
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SiteSettings`;
CREATE TABLE `Himall_SiteSettings` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Key` varchar(100) NOT NULL,
  `Value` varchar(4000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_SiteSettings
-- ----------------------------
INSERT INTO `Himall_SiteSettings` VALUES ('1', 'Logo', '/Storage/Plat/ImageAd/logo.png');
INSERT INTO `Himall_SiteSettings` VALUES ('2', 'SiteName', '站点1号');
INSERT INTO `Himall_SiteSettings` VALUES ('3', 'ICPNubmer', ' ');
INSERT INTO `Himall_SiteSettings` VALUES ('4', 'CustomerTel', ' ');
INSERT INTO `Himall_SiteSettings` VALUES ('5', 'SiteIsOpen', 'False');
INSERT INTO `Himall_SiteSettings` VALUES ('6', 'Keyword', '手机');
INSERT INTO `Himall_SiteSettings` VALUES ('7', 'Hotkeywords', '男装,海飞丝,女装,ABC,手机,Nikon,包包,鞋子');
INSERT INTO `Himall_SiteSettings` VALUES ('8', 'PageFoot', ' ');
INSERT INTO `Himall_SiteSettings` VALUES ('9', 'UserCookieKey', 'd1b31e1b3176cf3aa8993428061c8af2');

-- ----------------------------
-- Table structure for Himall_SKUs
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SKUs`;
CREATE TABLE `Himall_SKUs` (
  `Id` varchar(100) NOT NULL,
  `ProductId` bigint(20) NOT NULL,
  `Color` varchar(100) DEFAULT NULL,
  `Size` varchar(100) DEFAULT NULL,
  `Version` varchar(100) DEFAULT NULL,
  `Sku` varchar(100) DEFAULT NULL,
  `Stock` bigint(20) NOT NULL,
  `CostPrice` decimal(8,2) NOT NULL,
  `SalePrice` decimal(8,2) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Product_Sku` (`ProductId`) USING BTREE,
  CONSTRAINT `himall_skus_ibfk_1` FOREIGN KEY (`ProductId`) REFERENCES `Himall_Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_SKUs
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_SlideAds
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SlideAds`;
CREATE TABLE `Himall_SlideAds` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `ImageUrl` varchar(100) NOT NULL,
  `Url` varchar(1000) NOT NULL,
  `DisplaySequence` bigint(20) NOT NULL,
  `TypeId` int(11) NOT NULL DEFAULT '0',
  `Description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_SlideAds
-- ----------------------------
INSERT INTO `Himall_SlideAds` VALUES ('1', '0', '/Storage/Plat/ImageAd/201411271919471017064.jpg', '/', '2', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('2', '0', '/Storage/Plat/ImageAd/201411271919575803729.jpg', '/', '3', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('3', '0', '/Storage/Plat/ImageAd/201411271920042657851.jpg', '/', '4', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('6', '0', '/Storage/Plat/ImageAd/201411271921554438454.jpg', '/', '5', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('7', '0', '/Storage/Plat/ImageAd/201411271921325857372.jpg', '/', '6', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('8', '0', '/Storage/Plat/ImageAd/201411281521485989739.jpg', '/', '1', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('9', '1', '/Storage/Shop/1/ImageAd/201411281706243546729.jpg', 'http://himall.kuaidiantong.cn/Product/Detail/261', '1', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('11', '1', '/Storage/Shop/1/ImageAd/201411281524168837472.jpg', 'http://himall.kuaidiantong.cn/Product/Detail/252', '2', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('12', '1', '/Storage/Shop/1/ImageAd/201411281524222547796.jpg', 'http://himall.kuaidiantong.cn/Product/Detail/252', '3', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('15', '5', '/Storage/Shop/5/ImageAd/201411282001104344023.png', 'http://himall.kuaidiantong.cn/Product/Detail/133', '1', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('20', '5', '/Storage/Shop/5/ImageAd/201411282011332936802.png', 'http://himall.kuaidiantong.cn/Product/Detail/127', '2', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('22', '5', '/Storage/Shop/5/ImageAd/201411281955223942183.png', 'http://himall.kuaidiantong.cn/Product/Detail/218', '3', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('24', '4', '/Storage/Shop/4/ImageAd/201411281721372609514.png', '\\', '1', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('26', '3', '/Storage/Shop/3/ImageAd/201411282041157626148.png', 'http://himall.kuaidiantong.cn/Product/Detail/234', '1', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('27', '3', '/Storage/Shop/3/ImageAd/201411282106240437726.png', 'http://himall.kuaidiantong.cn/Product/Detail/225', '2', '0', null);
INSERT INTO `Himall_SlideAds` VALUES ('28', '4', '/Storage/Shop/4/ImageAd/201411282119195436206.png', 'http://himall.kuaidiantong.cn/Product/Detail/233', '2', '0', null);

-- ----------------------------
-- Table structure for Himall_SpecificationValues
-- ----------------------------
DROP TABLE IF EXISTS `Himall_SpecificationValues`;
CREATE TABLE `Himall_SpecificationValues` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Specification` int(11) NOT NULL,
  `TypeId` bigint(20) NOT NULL,
  `Value` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Type_SpecificationValue` (`TypeId`) USING BTREE,
  CONSTRAINT `himall_specificationvalues_ibfk_1` FOREIGN KEY (`TypeId`) REFERENCES `Himall_Types` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=580 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_SpecificationValues
-- ----------------------------
INSERT INTO `Himall_SpecificationValues` VALUES ('1', '1', '19', '天蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('2', '1', '19', '枚红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('3', '1', '19', '宝蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('4', '1', '19', '卡其色');
INSERT INTO `Himall_SpecificationValues` VALUES ('5', '1', '19', '蝴蝶结');
INSERT INTO `Himall_SpecificationValues` VALUES ('6', '1', '20', '蓝白');
INSERT INTO `Himall_SpecificationValues` VALUES ('7', '1', '20', '红白');
INSERT INTO `Himall_SpecificationValues` VALUES ('8', '1', '20', '黑白');
INSERT INTO `Himall_SpecificationValues` VALUES ('9', '1', '20', '绿黑');
INSERT INTO `Himall_SpecificationValues` VALUES ('10', '1', '20', '白紫');
INSERT INTO `Himall_SpecificationValues` VALUES ('11', '2', '20', '120');
INSERT INTO `Himall_SpecificationValues` VALUES ('12', '2', '20', '130');
INSERT INTO `Himall_SpecificationValues` VALUES ('13', '2', '20', '140');
INSERT INTO `Himall_SpecificationValues` VALUES ('14', '2', '20', '150');
INSERT INTO `Himall_SpecificationValues` VALUES ('15', '1', '21', '卡其');
INSERT INTO `Himall_SpecificationValues` VALUES ('16', '1', '21', '军绿');
INSERT INTO `Himall_SpecificationValues` VALUES ('17', '2', '21', 'M');
INSERT INTO `Himall_SpecificationValues` VALUES ('18', '2', '21', 'L');
INSERT INTO `Himall_SpecificationValues` VALUES ('19', '2', '21', 'XL');
INSERT INTO `Himall_SpecificationValues` VALUES ('20', '2', '21', 'XXL');
INSERT INTO `Himall_SpecificationValues` VALUES ('21', '1', '3', '琥珀色');
INSERT INTO `Himall_SpecificationValues` VALUES ('22', '1', '3', '白色');
INSERT INTO `Himall_SpecificationValues` VALUES ('23', '1', '3', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('24', '1', '3', '棕花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('25', '2', '3', 'S');
INSERT INTO `Himall_SpecificationValues` VALUES ('26', '2', '3', 'M');
INSERT INTO `Himall_SpecificationValues` VALUES ('27', '2', '3', 'L');
INSERT INTO `Himall_SpecificationValues` VALUES ('28', '1', '17', '土黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('29', '1', '17', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('30', '1', '17', '米色');
INSERT INTO `Himall_SpecificationValues` VALUES ('31', '1', '17', '棕色');
INSERT INTO `Himall_SpecificationValues` VALUES ('32', '1', '17', '白色');
INSERT INTO `Himall_SpecificationValues` VALUES ('33', '1', '17', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('34', '1', '17', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('35', '2', '17', '38');
INSERT INTO `Himall_SpecificationValues` VALUES ('36', '2', '17', '39');
INSERT INTO `Himall_SpecificationValues` VALUES ('37', '2', '17', '40');
INSERT INTO `Himall_SpecificationValues` VALUES ('38', '2', '17', '41');
INSERT INTO `Himall_SpecificationValues` VALUES ('39', '2', '17', '37');
INSERT INTO `Himall_SpecificationValues` VALUES ('40', '3', '13', '官方标配');
INSERT INTO `Himall_SpecificationValues` VALUES ('41', '3', '13', '套餐一');
INSERT INTO `Himall_SpecificationValues` VALUES ('42', '3', '13', '套餐二');
INSERT INTO `Himall_SpecificationValues` VALUES ('57', '1', '12', '银色');
INSERT INTO `Himall_SpecificationValues` VALUES ('58', '1', '12', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('59', '1', '12', '金色');
INSERT INTO `Himall_SpecificationValues` VALUES ('60', '1', '12', '灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('61', '1', '12', '白色');
INSERT INTO `Himall_SpecificationValues` VALUES ('62', '1', '12', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('63', '3', '12', '非合约机');
INSERT INTO `Himall_SpecificationValues` VALUES ('64', '3', '12', '合约机');
INSERT INTO `Himall_SpecificationValues` VALUES ('65', '1', '13', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('66', '1', '13', '白色');
INSERT INTO `Himall_SpecificationValues` VALUES ('67', '1', '13', '灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('68', '3', '24', '套餐2');
INSERT INTO `Himall_SpecificationValues` VALUES ('69', '3', '24', '套餐1');
INSERT INTO `Himall_SpecificationValues` VALUES ('70', '3', '24', '标配');
INSERT INTO `Himall_SpecificationValues` VALUES ('71', '1', '24', '银灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('72', '1', '24', '白色');
INSERT INTO `Himall_SpecificationValues` VALUES ('73', '2', '25', '10.1寸');
INSERT INTO `Himall_SpecificationValues` VALUES ('74', '2', '25', '12寸');
INSERT INTO `Himall_SpecificationValues` VALUES ('75', '2', '25', '14寸');
INSERT INTO `Himall_SpecificationValues` VALUES ('76', '3', '25', 'i3 CPU');
INSERT INTO `Himall_SpecificationValues` VALUES ('77', '3', '25', 'i5 CPU/独显');
INSERT INTO `Himall_SpecificationValues` VALUES ('78', '3', '25', 'i7 CPU/独显');
INSERT INTO `Himall_SpecificationValues` VALUES ('79', '1', '5', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('80', '1', '5', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('81', '1', '5', '白色');
INSERT INTO `Himall_SpecificationValues` VALUES ('82', '1', '5', '粉色');
INSERT INTO `Himall_SpecificationValues` VALUES ('83', '1', '5', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('84', '1', '5', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('85', '1', '5', '橙色');
INSERT INTO `Himall_SpecificationValues` VALUES ('86', '1', '26', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('87', '1', '26', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('88', '1', '26', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('89', '1', '26', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('90', '1', '26', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('91', '1', '26', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('92', '1', '26', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('93', '1', '26', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('94', '1', '26', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('95', '1', '26', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('96', '1', '26', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('97', '1', '26', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('98', '1', '26', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('99', '3', '26', '1米');
INSERT INTO `Himall_SpecificationValues` VALUES ('100', '3', '26', '1.2米');
INSERT INTO `Himall_SpecificationValues` VALUES ('101', '3', '26', '1.5米');
INSERT INTO `Himall_SpecificationValues` VALUES ('102', '1', '27', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('103', '1', '27', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('104', '1', '27', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('105', '1', '27', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('106', '1', '27', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('107', '1', '27', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('108', '1', '27', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('109', '1', '27', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('110', '1', '27', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('111', '1', '27', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('112', '1', '27', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('113', '1', '27', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('114', '1', '27', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('115', '1', '28', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('116', '1', '28', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('117', '1', '28', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('118', '1', '28', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('119', '1', '28', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('120', '1', '28', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('121', '1', '28', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('122', '1', '28', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('123', '1', '28', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('124', '1', '28', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('125', '1', '28', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('126', '1', '28', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('127', '1', '28', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('128', '2', '21', 'S');
INSERT INTO `Himall_SpecificationValues` VALUES ('129', '1', '21', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('130', '1', '21', '灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('131', '1', '21', '白色');
INSERT INTO `Himall_SpecificationValues` VALUES ('132', '1', '1', '白');
INSERT INTO `Himall_SpecificationValues` VALUES ('133', '1', '1', '灰');
INSERT INTO `Himall_SpecificationValues` VALUES ('134', '1', '1', '黑');
INSERT INTO `Himall_SpecificationValues` VALUES ('135', '1', '1', '蓝');
INSERT INTO `Himall_SpecificationValues` VALUES ('136', '1', '29', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('137', '1', '29', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('138', '1', '29', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('139', '1', '29', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('140', '1', '29', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('141', '1', '29', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('142', '1', '29', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('143', '1', '29', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('144', '1', '29', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('145', '1', '29', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('146', '1', '29', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('147', '1', '29', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('148', '1', '29', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('149', '1', '16', '白色');
INSERT INTO `Himall_SpecificationValues` VALUES ('150', '1', '16', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('151', '1', '30', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('152', '1', '30', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('153', '1', '30', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('154', '1', '30', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('155', '1', '30', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('156', '1', '30', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('157', '1', '30', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('158', '1', '30', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('159', '1', '30', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('160', '1', '30', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('161', '1', '30', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('162', '1', '30', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('163', '1', '30', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('164', '1', '31', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('165', '1', '31', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('166', '1', '31', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('167', '1', '31', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('168', '1', '31', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('169', '1', '31', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('170', '1', '31', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('171', '1', '31', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('172', '1', '31', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('173', '1', '31', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('174', '1', '31', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('175', '1', '31', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('176', '1', '31', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('177', '1', '32', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('178', '1', '32', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('179', '1', '32', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('180', '1', '32', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('181', '1', '32', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('182', '1', '32', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('183', '1', '32', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('184', '1', '32', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('185', '1', '32', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('186', '1', '32', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('187', '1', '32', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('188', '1', '32', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('189', '1', '32', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('190', '3', '33', '版本1');
INSERT INTO `Himall_SpecificationValues` VALUES ('191', '3', '33', '版本2');
INSERT INTO `Himall_SpecificationValues` VALUES ('192', '3', '33', '版本3');
INSERT INTO `Himall_SpecificationValues` VALUES ('193', '3', '33', '版本4');
INSERT INTO `Himall_SpecificationValues` VALUES ('194', '3', '33', '版本5');
INSERT INTO `Himall_SpecificationValues` VALUES ('200', '1', '35', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('201', '1', '35', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('202', '1', '35', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('203', '1', '35', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('204', '1', '35', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('205', '1', '35', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('206', '1', '35', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('207', '1', '35', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('208', '1', '35', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('209', '1', '35', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('210', '1', '35', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('211', '1', '35', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('212', '1', '35', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('213', '1', '36', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('214', '1', '36', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('215', '1', '36', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('216', '1', '36', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('217', '1', '36', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('218', '1', '36', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('219', '1', '36', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('220', '1', '36', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('221', '1', '36', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('222', '1', '36', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('223', '1', '36', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('224', '1', '36', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('225', '1', '36', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('226', '1', '37', '紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('227', '1', '37', '红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('228', '1', '37', '绿色');
INSERT INTO `Himall_SpecificationValues` VALUES ('229', '1', '37', '花色');
INSERT INTO `Himall_SpecificationValues` VALUES ('230', '1', '37', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('231', '1', '37', '褐色');
INSERT INTO `Himall_SpecificationValues` VALUES ('232', '1', '37', '透明');
INSERT INTO `Himall_SpecificationValues` VALUES ('233', '1', '37', '酒红色');
INSERT INTO `Himall_SpecificationValues` VALUES ('234', '1', '37', '黄色');
INSERT INTO `Himall_SpecificationValues` VALUES ('235', '1', '37', '黑色');
INSERT INTO `Himall_SpecificationValues` VALUES ('236', '1', '37', '深灰色');
INSERT INTO `Himall_SpecificationValues` VALUES ('237', '1', '37', '深紫色');
INSERT INTO `Himall_SpecificationValues` VALUES ('238', '1', '37', '深蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('239', '3', '9', '深层净化');
INSERT INTO `Himall_SpecificationValues` VALUES ('240', '3', '9', '秋冬滋润');
INSERT INTO `Himall_SpecificationValues` VALUES ('241', '3', '9', '劲能套餐');
INSERT INTO `Himall_SpecificationValues` VALUES ('242', '3', '9', '型男霜');
INSERT INTO `Himall_SpecificationValues` VALUES ('243', '3', '9', '控油套餐');
INSERT INTO `Himall_SpecificationValues` VALUES ('244', '1', '12', '蓝色');
INSERT INTO `Himall_SpecificationValues` VALUES ('245', '1', '13', '黑色');

-- ----------------------------
-- Table structure for Himall_StatisticOrderComments
-- ----------------------------
DROP TABLE IF EXISTS `Himall_StatisticOrderComments`;
CREATE TABLE `Himall_StatisticOrderComments` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `CommentKey` int(11) NOT NULL,
  `CommentValue` decimal(10,4) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `himall_statisticordercomments_ibfk_1` (`ShopId`) USING BTREE,
  CONSTRAINT `himall_statisticordercomments_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='订单评价统计表';

-- ----------------------------
-- Records of Himall_StatisticOrderComments
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_TopicModules
-- ----------------------------
DROP TABLE IF EXISTS `Himall_TopicModules`;
CREATE TABLE `Himall_TopicModules` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TopicId` bigint(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Topic_TopicModule` (`TopicId`) USING BTREE,
  CONSTRAINT `himall_topicmodules_ibfk_1` FOREIGN KEY (`TopicId`) REFERENCES `Himall_Topics` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_TopicModules
-- ----------------------------
INSERT INTO `Himall_TopicModules` VALUES ('16', '2', '热卖');
INSERT INTO `Himall_TopicModules` VALUES ('17', '2', '畅销');
INSERT INTO `Himall_TopicModules` VALUES ('18', '2', '新品');
INSERT INTO `Himall_TopicModules` VALUES ('19', '2', '特价');
INSERT INTO `Himall_TopicModules` VALUES ('36', '3', '男装');
INSERT INTO `Himall_TopicModules` VALUES ('37', '3', '女装');
INSERT INTO `Himall_TopicModules` VALUES ('40', '4', '户外');
INSERT INTO `Himall_TopicModules` VALUES ('43', '5', '新品相机');
INSERT INTO `Himall_TopicModules` VALUES ('44', '5', '新款手机');
INSERT INTO `Himall_TopicModules` VALUES ('45', '5', '周边配件');
INSERT INTO `Himall_TopicModules` VALUES ('46', '5', '热卖精品');
INSERT INTO `Himall_TopicModules` VALUES ('48', '7', '新品');
INSERT INTO `Himall_TopicModules` VALUES ('49', '7', '热卖');
INSERT INTO `Himall_TopicModules` VALUES ('50', '7', '畅销');
INSERT INTO `Himall_TopicModules` VALUES ('51', '7', '时尚');
INSERT INTO `Himall_TopicModules` VALUES ('58', '6', '护发系列');
INSERT INTO `Himall_TopicModules` VALUES ('59', '6', '魅力染发');
INSERT INTO `Himall_TopicModules` VALUES ('60', '6', '洗发精品');
INSERT INTO `Himall_TopicModules` VALUES ('61', '8', '新品');
INSERT INTO `Himall_TopicModules` VALUES ('62', '8', '时尚');
INSERT INTO `Himall_TopicModules` VALUES ('63', '8', '畅销');
INSERT INTO `Himall_TopicModules` VALUES ('64', '8', '热销');
INSERT INTO `Himall_TopicModules` VALUES ('68', '9', '手足护理');
INSERT INTO `Himall_TopicModules` VALUES ('69', '9', '润肤系列');
INSERT INTO `Himall_TopicModules` VALUES ('70', '9', '清凉沐浴');
INSERT INTO `Himall_TopicModules` VALUES ('71', '10', '专属自己');
INSERT INTO `Himall_TopicModules` VALUES ('72', '10', '轻松护垫');
INSERT INTO `Himall_TopicModules` VALUES ('73', '10', '保护自己');
INSERT INTO `Himall_TopicModules` VALUES ('74', '11', '清新口气');
INSERT INTO `Himall_TopicModules` VALUES ('75', '11', '专业护牙');
INSERT INTO `Himall_TopicModules` VALUES ('76', '11', '个性牙刷');
INSERT INTO `Himall_TopicModules` VALUES ('83', '12', '面部清洁');
INSERT INTO `Himall_TopicModules` VALUES ('84', '12', '清爽面膜');
INSERT INTO `Himall_TopicModules` VALUES ('85', '12', '养肤护肤');
INSERT INTO `Himall_TopicModules` VALUES ('86', '13', '护理套装');
INSERT INTO `Himall_TopicModules` VALUES ('87', '13', '专业护发');
INSERT INTO `Himall_TopicModules` VALUES ('88', '13', '专业护肤');
INSERT INTO `Himall_TopicModules` VALUES ('89', '13', '清新口腔');

-- ----------------------------
-- Table structure for Himall_Topics
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Topics`;
CREATE TABLE `Himall_Topics` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `FrontCoverImage` varchar(100) DEFAULT NULL,
  `TopImage` varchar(100) NOT NULL,
  `BackgroundImage` varchar(100) NOT NULL,
  `PlatForm` int(11) NOT NULL DEFAULT '0',
  `Tags` varchar(100) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Topics
-- ----------------------------
INSERT INTO `Himall_Topics` VALUES ('2', '相机简单购', null, '/Storage/Plat/Topic/2/201411281731336145557.jpg', '/Storage/Plat/Topic/2/201411281731366014812.jpg', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('3', '平台自营商店专题', null, '/Storage/Plat/Topic/3/201411281738495644504.jpg', '/Storage/Plat/Topic/3/201411281752127699721.png', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('4', '平台自营店专题', null, '/Storage/Plat/Topic/4/201411281753348639574.jpg', '/Storage/Plat/Topic/4/201411281751134554207.png', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('5', '新品首发', null, '/Storage/Plat/Topic/5/201411281750336942024.jpg', '/Storage/Plat/Topic/5/201411281750345167137.jpg', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('6', '洗发护发', null, '/Storage/Plat/Topic/6/201411281803321585529.jpg', '/Storage/Plat/Topic/6/201411281803356119642.jpg', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('7', '手机世界', null, '/Storage/Plat/Topic/7/201411281756413549235.jpg', '/Storage/Plat/Topic/7/201411281756441522248.jpg', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('8', '热卖配件', null, '/Storage/Plat/Topic/8/201411281803457345649.jpg', '/Storage/Plat/Topic/8/201411281803466657032.jpg', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('9', '身体护理', null, '/Storage/Plat/Topic/9/201411281820130007699.jpg', '/Storage/Plat/Topic/9/201411281820485451344.jpg', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('10', '女性护理', null, '/Storage/Plat/Topic/10/201411281828049926906.jpg', '/Storage/Plat/Topic/10/201411281828080117917.jpg', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('11', '口腔护理', null, '/Storage/Plat/Topic/11/201411281836286221947.jpg', '/Storage/Plat/Topic/11/201411281836316847943.jpg', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('12', '面部护肤', null, '/Storage/Plat/Topic/12/201411281841299107863.jpg', '/Storage/Plat/Topic/12/201411281843564546626.jpg', '0', null, '0');
INSERT INTO `Himall_Topics` VALUES ('13', '礼品套装', null, '/Storage/Plat/Topic/13/201411281850159661287.jpg', '/Storage/Plat/Topic/13/201411281850187404772.jpg', '0', null, '0');

-- ----------------------------
-- Table structure for Himall_TypeBrands
-- ----------------------------
DROP TABLE IF EXISTS `Himall_TypeBrands`;
CREATE TABLE `Himall_TypeBrands` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TypeId` bigint(20) NOT NULL,
  `BrandId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Brand_TypeBrand` (`BrandId`) USING BTREE,
  KEY `FK_Type_TypeBrand` (`TypeId`) USING BTREE,
  CONSTRAINT `himall_typebrands_ibfk_1` FOREIGN KEY (`BrandId`) REFERENCES `Himall_Brands` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `himall_typebrands_ibfk_2` FOREIGN KEY (`TypeId`) REFERENCES `Himall_Types` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1475 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_TypeBrands
-- ----------------------------
INSERT INTO `Himall_TypeBrands` VALUES ('32', '26', '28');
INSERT INTO `Himall_TypeBrands` VALUES ('33', '26', '56');
INSERT INTO `Himall_TypeBrands` VALUES ('34', '26', '54');
INSERT INTO `Himall_TypeBrands` VALUES ('35', '26', '50');
INSERT INTO `Himall_TypeBrands` VALUES ('40', '1', '51');
INSERT INTO `Himall_TypeBrands` VALUES ('41', '17', '35');
INSERT INTO `Himall_TypeBrands` VALUES ('42', '17', '34');
INSERT INTO `Himall_TypeBrands` VALUES ('43', '17', '39');
INSERT INTO `Himall_TypeBrands` VALUES ('44', '17', '43');
INSERT INTO `Himall_TypeBrands` VALUES ('45', '17', '63');
INSERT INTO `Himall_TypeBrands` VALUES ('48', '30', '40');
INSERT INTO `Himall_TypeBrands` VALUES ('52', '32', '35');
INSERT INTO `Himall_TypeBrands` VALUES ('53', '36', '59');
INSERT INTO `Himall_TypeBrands` VALUES ('54', '36', '61');
INSERT INTO `Himall_TypeBrands` VALUES ('55', '36', '65');
INSERT INTO `Himall_TypeBrands` VALUES ('56', '36', '68');
INSERT INTO `Himall_TypeBrands` VALUES ('57', '37', '61');
INSERT INTO `Himall_TypeBrands` VALUES ('84', '41', '74');
INSERT INTO `Himall_TypeBrands` VALUES ('85', '41', '72');
INSERT INTO `Himall_TypeBrands` VALUES ('86', '41', '75');
INSERT INTO `Himall_TypeBrands` VALUES ('87', '41', '73');
INSERT INTO `Himall_TypeBrands` VALUES ('88', '41', '76');
INSERT INTO `Himall_TypeBrands` VALUES ('89', '41', '69');
INSERT INTO `Himall_TypeBrands` VALUES ('90', '41', '70');
INSERT INTO `Himall_TypeBrands` VALUES ('91', '41', '78');
INSERT INTO `Himall_TypeBrands` VALUES ('92', '41', '77');
INSERT INTO `Himall_TypeBrands` VALUES ('93', '16', '35');
INSERT INTO `Himall_TypeBrands` VALUES ('94', '16', '38');
INSERT INTO `Himall_TypeBrands` VALUES ('95', '16', '86');
INSERT INTO `Himall_TypeBrands` VALUES ('96', '16', '85');
INSERT INTO `Himall_TypeBrands` VALUES ('97', '16', '84');
INSERT INTO `Himall_TypeBrands` VALUES ('98', '16', '83');
INSERT INTO `Himall_TypeBrands` VALUES ('99', '16', '82');
INSERT INTO `Himall_TypeBrands` VALUES ('409', '25', '12');
INSERT INTO `Himall_TypeBrands` VALUES ('410', '25', '16');
INSERT INTO `Himall_TypeBrands` VALUES ('411', '25', '18');
INSERT INTO `Himall_TypeBrands` VALUES ('412', '25', '19');
INSERT INTO `Himall_TypeBrands` VALUES ('413', '25', '21');
INSERT INTO `Himall_TypeBrands` VALUES ('414', '25', '22');
INSERT INTO `Himall_TypeBrands` VALUES ('952', '9', '95');
INSERT INTO `Himall_TypeBrands` VALUES ('953', '9', '98');
INSERT INTO `Himall_TypeBrands` VALUES ('954', '9', '101');
INSERT INTO `Himall_TypeBrands` VALUES ('955', '9', '44');
INSERT INTO `Himall_TypeBrands` VALUES ('956', '9', '53');
INSERT INTO `Himall_TypeBrands` VALUES ('957', '9', '61');
INSERT INTO `Himall_TypeBrands` VALUES ('958', '9', '68');
INSERT INTO `Himall_TypeBrands` VALUES ('959', '9', '83');
INSERT INTO `Himall_TypeBrands` VALUES ('960', '9', '84');
INSERT INTO `Himall_TypeBrands` VALUES ('961', '9', '85');
INSERT INTO `Himall_TypeBrands` VALUES ('962', '9', '86');
INSERT INTO `Himall_TypeBrands` VALUES ('963', '9', '152');
INSERT INTO `Himall_TypeBrands` VALUES ('964', '9', '92');
INSERT INTO `Himall_TypeBrands` VALUES ('965', '9', '96');
INSERT INTO `Himall_TypeBrands` VALUES ('966', '9', '99');
INSERT INTO `Himall_TypeBrands` VALUES ('967', '9', '104');
INSERT INTO `Himall_TypeBrands` VALUES ('968', '9', '107');
INSERT INTO `Himall_TypeBrands` VALUES ('969', '9', '109');
INSERT INTO `Himall_TypeBrands` VALUES ('970', '9', '111');
INSERT INTO `Himall_TypeBrands` VALUES ('971', '9', '113');
INSERT INTO `Himall_TypeBrands` VALUES ('972', '9', '116');
INSERT INTO `Himall_TypeBrands` VALUES ('973', '9', '117');
INSERT INTO `Himall_TypeBrands` VALUES ('974', '9', '118');
INSERT INTO `Himall_TypeBrands` VALUES ('975', '9', '119');
INSERT INTO `Himall_TypeBrands` VALUES ('976', '9', '121');
INSERT INTO `Himall_TypeBrands` VALUES ('977', '9', '125');
INSERT INTO `Himall_TypeBrands` VALUES ('978', '9', '126');
INSERT INTO `Himall_TypeBrands` VALUES ('979', '9', '128');
INSERT INTO `Himall_TypeBrands` VALUES ('980', '9', '129');
INSERT INTO `Himall_TypeBrands` VALUES ('981', '9', '115');
INSERT INTO `Himall_TypeBrands` VALUES ('982', '9', '122');
INSERT INTO `Himall_TypeBrands` VALUES ('983', '9', '123');
INSERT INTO `Himall_TypeBrands` VALUES ('984', '9', '124');
INSERT INTO `Himall_TypeBrands` VALUES ('985', '9', '132');
INSERT INTO `Himall_TypeBrands` VALUES ('986', '9', '134');
INSERT INTO `Himall_TypeBrands` VALUES ('987', '9', '135');
INSERT INTO `Himall_TypeBrands` VALUES ('988', '9', '136');
INSERT INTO `Himall_TypeBrands` VALUES ('989', '9', '140');
INSERT INTO `Himall_TypeBrands` VALUES ('990', '9', '143');
INSERT INTO `Himall_TypeBrands` VALUES ('991', '9', '144');
INSERT INTO `Himall_TypeBrands` VALUES ('992', '9', '149');
INSERT INTO `Himall_TypeBrands` VALUES ('993', '9', '142');
INSERT INTO `Himall_TypeBrands` VALUES ('994', '9', '145');
INSERT INTO `Himall_TypeBrands` VALUES ('995', '9', '151');
INSERT INTO `Himall_TypeBrands` VALUES ('996', '9', '131');
INSERT INTO `Himall_TypeBrands` VALUES ('997', '9', '133');
INSERT INTO `Himall_TypeBrands` VALUES ('998', '9', '146');
INSERT INTO `Himall_TypeBrands` VALUES ('999', '9', '137');
INSERT INTO `Himall_TypeBrands` VALUES ('1000', '9', '138');
INSERT INTO `Himall_TypeBrands` VALUES ('1001', '9', '139');
INSERT INTO `Himall_TypeBrands` VALUES ('1002', '9', '141');
INSERT INTO `Himall_TypeBrands` VALUES ('1003', '9', '148');
INSERT INTO `Himall_TypeBrands` VALUES ('1004', '9', '150');
INSERT INTO `Himall_TypeBrands` VALUES ('1011', '13', '14');
INSERT INTO `Himall_TypeBrands` VALUES ('1012', '13', '153');
INSERT INTO `Himall_TypeBrands` VALUES ('1013', '13', '120');
INSERT INTO `Himall_TypeBrands` VALUES ('1014', '13', '3');
INSERT INTO `Himall_TypeBrands` VALUES ('1015', '24', '4');
INSERT INTO `Himall_TypeBrands` VALUES ('1016', '24', '5');
INSERT INTO `Himall_TypeBrands` VALUES ('1017', '24', '6');
INSERT INTO `Himall_TypeBrands` VALUES ('1018', '24', '7');
INSERT INTO `Himall_TypeBrands` VALUES ('1019', '24', '8');
INSERT INTO `Himall_TypeBrands` VALUES ('1020', '24', '9');
INSERT INTO `Himall_TypeBrands` VALUES ('1021', '24', '10');
INSERT INTO `Himall_TypeBrands` VALUES ('1022', '24', '11');
INSERT INTO `Himall_TypeBrands` VALUES ('1023', '24', '12');
INSERT INTO `Himall_TypeBrands` VALUES ('1024', '24', '26');
INSERT INTO `Himall_TypeBrands` VALUES ('1057', '21', '29');
INSERT INTO `Himall_TypeBrands` VALUES ('1058', '21', '31');
INSERT INTO `Himall_TypeBrands` VALUES ('1059', '21', '36');
INSERT INTO `Himall_TypeBrands` VALUES ('1060', '21', '37');
INSERT INTO `Himall_TypeBrands` VALUES ('1061', '21', '38');
INSERT INTO `Himall_TypeBrands` VALUES ('1062', '21', '82');
INSERT INTO `Himall_TypeBrands` VALUES ('1063', '21', '35');
INSERT INTO `Himall_TypeBrands` VALUES ('1064', '21', '67');
INSERT INTO `Himall_TypeBrands` VALUES ('1065', '12', '4');
INSERT INTO `Himall_TypeBrands` VALUES ('1066', '12', '3');
INSERT INTO `Himall_TypeBrands` VALUES ('1067', '12', '9');
INSERT INTO `Himall_TypeBrands` VALUES ('1068', '12', '10');
INSERT INTO `Himall_TypeBrands` VALUES ('1069', '12', '11');
INSERT INTO `Himall_TypeBrands` VALUES ('1070', '12', '12');
INSERT INTO `Himall_TypeBrands` VALUES ('1071', '12', '15');
INSERT INTO `Himall_TypeBrands` VALUES ('1072', '12', '93');
INSERT INTO `Himall_TypeBrands` VALUES ('1073', '12', '112');
INSERT INTO `Himall_TypeBrands` VALUES ('1074', '12', '120');
INSERT INTO `Himall_TypeBrands` VALUES ('1075', '12', '147');
INSERT INTO `Himall_TypeBrands` VALUES ('1076', '12', '154');
INSERT INTO `Himall_TypeBrands` VALUES ('1077', '20', '35');
INSERT INTO `Himall_TypeBrands` VALUES ('1078', '20', '57');
INSERT INTO `Himall_TypeBrands` VALUES ('1079', '20', '30');
INSERT INTO `Himall_TypeBrands` VALUES ('1080', '20', '33');
INSERT INTO `Himall_TypeBrands` VALUES ('1081', '20', '36');
INSERT INTO `Himall_TypeBrands` VALUES ('1082', '20', '37');
INSERT INTO `Himall_TypeBrands` VALUES ('1083', '20', '38');
INSERT INTO `Himall_TypeBrands` VALUES ('1084', '20', '42');
INSERT INTO `Himall_TypeBrands` VALUES ('1085', '20', '48');
INSERT INTO `Himall_TypeBrands` VALUES ('1086', '20', '155');
INSERT INTO `Himall_TypeBrands` VALUES ('1087', '38', '156');
INSERT INTO `Himall_TypeBrands` VALUES ('1088', '38', '93');

-- ----------------------------
-- Table structure for Himall_Types
-- ----------------------------
DROP TABLE IF EXISTS `Himall_Types`;
CREATE TABLE `Himall_Types` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `IsSupportColor` tinyint(1) NOT NULL,
  `IsSupportSize` tinyint(1) NOT NULL,
  `IsSupportVersion` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_Types
-- ----------------------------
INSERT INTO `Himall_Types` VALUES ('1', '内衣', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('3', '连衣裙', '1', '1', '0');
INSERT INTO `Himall_Types` VALUES ('4', '被子', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('5', '家居', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('6', '图书', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('7', '童书', '1', '1', '1');
INSERT INTO `Himall_Types` VALUES ('8', '彩妆', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('9', '个护化妆', '0', '0', '1');
INSERT INTO `Himall_Types` VALUES ('10', '进口食品', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('11', '特产果蔬', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('12', '手机', '1', '0', '1');
INSERT INTO `Himall_Types` VALUES ('13', '数码', '1', '0', '1');
INSERT INTO `Himall_Types` VALUES ('14', '手包', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('15', '斜跨包', '1', '1', '1');
INSERT INTO `Himall_Types` VALUES ('16', '箱包', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('17', '鞋靴', '1', '1', '0');
INSERT INTO `Himall_Types` VALUES ('18', '女鞋', '1', '1', '1');
INSERT INTO `Himall_Types` VALUES ('19', '帽子', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('20', '女装', '1', '1', '0');
INSERT INTO `Himall_Types` VALUES ('21', '男装', '1', '1', '0');
INSERT INTO `Himall_Types` VALUES ('22', '裤子', '1', '1', '1');
INSERT INTO `Himall_Types` VALUES ('24', '家用电器', '1', '0', '1');
INSERT INTO `Himall_Types` VALUES ('25', '电脑、办公', '0', '1', '1');
INSERT INTO `Himall_Types` VALUES ('26', '家具', '1', '0', '1');
INSERT INTO `Himall_Types` VALUES ('27', '家装', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('28', '厨具', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('29', '珠宝', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('30', '钟表', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('31', '奢侈品', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('32', '运动户外', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('33', '整车', '0', '0', '1');
INSERT INTO `Himall_Types` VALUES ('35', '汽车用品', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('36', '母婴', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('37', '玩具乐器', '1', '0', '0');
INSERT INTO `Himall_Types` VALUES ('38', '食品饮料', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('39', '酒类', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('40', '生鲜', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('41', '营养保健', '0', '0', '0');
INSERT INTO `Himall_Types` VALUES ('42', '音像', '0', '0', '0');

-- ----------------------------
-- Table structure for Himall_VShop
-- ----------------------------
DROP TABLE IF EXISTS `Himall_VShop`;
CREATE TABLE `Himall_VShop` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) DEFAULT NULL,
  `ShopId` bigint(20) NOT NULL,
  `CreateTime` datetime NOT NULL,
  `VisitNum` int(11) NOT NULL,
  `buyNum` int(11) NOT NULL,
  `State` int(11) NOT NULL,
  `Logo` varchar(200) DEFAULT NULL,
  `BackgroundImage` varchar(200) DEFAULT NULL,
  `Description` varchar(30) DEFAULT NULL,
  `Tags` varchar(100) DEFAULT NULL,
  `HomePageTitle` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_vshop_shopinfo` (`ShopId`) USING BTREE,
  CONSTRAINT `himall_vshop_ibfk_1` FOREIGN KEY (`ShopId`) REFERENCES `Himall_Shops` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_VShop
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_VShopExtend
-- ----------------------------
DROP TABLE IF EXISTS `Himall_VShopExtend`;
CREATE TABLE `Himall_VShopExtend` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `VShopId` bigint(20) NOT NULL,
  `Sequence` int(11) DEFAULT NULL,
  `Type` int(11) NOT NULL,
  `AddTime` datetime NOT NULL,
  `State` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_vshopextend_vshop` (`VShopId`) USING BTREE,
  CONSTRAINT `himall_vshopextend_ibfk_1` FOREIGN KEY (`VShopId`) REFERENCES `Himall_VShop` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_VShopExtend
-- ----------------------------

-- ----------------------------
-- Table structure for Himall_WXshop
-- ----------------------------
DROP TABLE IF EXISTS `Himall_WXshop`;
CREATE TABLE `Himall_WXshop` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ShopId` bigint(20) NOT NULL,
  `AppId` varchar(30) NOT NULL,
  `AppSecret` varchar(35) NOT NULL,
  `Token` varchar(30) NOT NULL,
  `FollowUrl` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Himall_WXshop
-- ----------------------------

-- ----------------------------
-- Procedure structure for sp_InsertProduct_proc
-- ----------------------------
DROP PROCEDURE IF EXISTS `sp_InsertProduct_proc`;
DELIMITER ;;
CREATE DEFINER=`himaller`@`%` PROCEDURE `sp_InsertProduct_proc`(
IN $shopName VARCHAR(100),/*店铺名称*/
IN $CategoryId BIGINT,/*分类ID*/
IN $ProductName VARCHAR(100),/*产品名称*/
IN $ProductPath VARCHAR(100),/*产品路径*/
IN $MarketPrice DECIMAL(8,2),/*市场价格*/
IN $MinsalePrice DECIMAL(8,2),/*销售价格*/
IN $MeasureUnit varchar(20),/*单位*/
IN $KeyWords varchar(1000),/*关键字*/
In $SaleCount int,/*销售数量*/
IN $ShortDescription  varchar(4000),/*简短描述*/
IN $Description Text,/*描述*/
IN $RegionId int, /*地区模板的ID*/
IN $CompanyRegionId int,/*公司地区模板的ID*/
IN $CompanyName VARCHAR(100),/*公司名称*/
IN $CompanyPhone VARCHAR(20), /*公司电话*/
OUT $p_sqlcode   INT,  
OUT $p_status_message  VARCHAR(100) 
)
BEGIN
DECLARE t_ShopID bigint DEFAULT -1;
DECLARE t_ProductId BIGINT  DEFAULT -1;
DECLARE t_CategoryId BIGINT  DEFAULT -1;
DECLARE t_TypeId BIGINT DEFAULT 1;
DECLARE t_CategoryPath VARCHAR(100) DEFAULT '1';
DECLARE t_RegionId INT default 0;
DECLARE t_FreightTemplateId int DEFAULT 0;
DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN  
        SET $p_sqlcode=1;  
        SET $p_status_message=CONCAT('店铺名:',$shopName,',产品名:',$ProductName,',插入错误');  
    END;  
/*插入店铺信息*/
SELECT Id into t_ShopID from Himall_Shops where shopName = $shopName LIMIT 1;
IF(t_ShopID=-1) THEN
 insert into Himall_Shops(shopName,gradeId,IsSelf,shopStatus,createDate,EndDate,CompanyRegionId,CompanyEmployeeCount,CompanyRegisteredCapital,BusinessLicenceNumberPhoto,
BusinessLicenceRegionId,BankRegionId,FreeFreight,Freight,Stage,CompanyName,CompanyPhone) 
values($shopName,0,0,7,'2000-01-01 00:00:00','2999-01-01 00:00:00',$CompanyRegionId,0,0,"",0,0,0,0,6,$CompanyName,$CompanyPhone);
set t_ShopID=last_insert_id();
end if;

SELECT SourceAddress,Id into t_RegionId,t_FreightTemplateId from Himall_FreightTemplate where ShopID=t_ShopID and SourceAddress=$RegionId LIMIT 1;
if(t_RegionId=0) THEN
INSERT INTO `Himall_FreightTemplate`(`Id`,`Name`,`SourceAddress`,`SendTime`,`IsFree`,`ValuationMethod`,`ShippingMethod`, `ShopID`) 
 VALUES (0,'默认运费模板', $RegionId, null, '1', '0', null, t_ShopID);
set t_FreightTemplateId=last_insert_id();
END IF;
/*分类信息*/
select Id,Path,TypeId into t_CategoryId,t_CategoryPath,t_TypeId from Himall_Categories where Id=$CategoryId LIMIT 1;
if(t_CategoryId>0) THEN
/*插入产品信息*/
SELECT Id  into t_ProductId from Himall_Products where ProductName = $ProductName  and ShopId=t_ShopID and CategoryId=$CategoryId LIMIT 1;
end if;
if(t_productId=-1) then
/*set @pid=(SELECT ifnull(Max(Id)+1,1)  from Himall_Products);*/
insert into Himall_Products(productName,ImagePath,brandId,ShopId,CategoryId,CategoryPath,TypeId,AddedDate,DisplaySequence,MarketPrice,MinSalePrice,HasSKU,MeasureUnit,FreightTemplateId,VistiCounts,SaleCounts,SaleStatus,AuditStatus,shortDescription) 
values($productName,$ProductPath,0,t_ShopID,t_CategoryId,t_CategoryPath,t_TypeId,'2000-01-01 00:00:00',1,$MarketPrice,$MinsalePrice,0,$MeasureUnit,t_FreightTemplateId,126,$SaleCount,1,2,$ShortDescription);
/*set t_ProductId=last_insert_id();*/
set t_productId=last_insert_id();
INSERT into Himall_ProductDescriptions(Id,ProductId,Meta_Keywords,Description,DescriptionPrefixId,DescriptiondSuffixId)
 values(0,t_ProductId,$KeyWords,$Description,0,0);
set @sku=CONCAT(t_ProductId,"_0_0_0");
INSERT INTO `Himall_SKUs` VALUES (@sku, t_ProductId, '', '', '', '', 199,$MarketPrice,$MinsalePrice);
end if;
END
;;
DELIMITER ;
